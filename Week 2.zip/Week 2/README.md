# Imarat Builders Mall CRUD & E-Commerce System

A full-stack web application for managing Categories, Brands, Products, Users, Orders, Cart, and Reviews for Imarat Builders Mall. Built with Node.js, Express, PostgreSQL, and Bootstrap 5.

## 🏗️ Architecture

- **Backend**: Node.js with Express.js
- **Database**: PostgreSQL with proper foreign key relationships
- **Frontend**: HTML5, Bootstrap 5, Vanilla JavaScript (modular)
- **API**: RESTful endpoints with JSON responses

## 📋 Features

### Core Functionality
- ✅ **Authentication & Authorization**: JWT-based login, registration, logout, access/refresh tokens, role-based access (admin/user)
- ✅ **User Management**: Register, login, profile, role-based UI
- ✅ **Category, Brand, Product Management**: Full CRUD for all entities
- ✅ **Product Grid**: Browse, search, and filter products
- ✅ **Cart**: Add to cart, update quantity, remove, clear, per-user cart
- ✅ **Checkout**: Place order, create order_items, clear cart
- ✅ **Order History**: View past orders and order details
- ✅ **Product Reviews**: Add/edit/delete reviews, 1-5 star rating, average rating per product
- ✅ **Admin Dashboard**: View total users, orders, revenue, top-selling products, and sales charts
- ✅ **Role-Based Navigation**: UI adapts to user/admin role
- ✅ **Frontend Feedback**: Toast notifications for all actions, form validation, error handling
- ✅ **Responsive Design**: Mobile-friendly Bootstrap 5 interface

### Database Schema
```
Category (1) → (Many) Brand (1) → (Many) Product
User (1) → (Many) CartItem
User (1) → (Many) Order (1) → (Many) OrderItem
User (1) → (Many) Review (per Product)
```

### Security Features
- ✅ Parameterized SQL queries to prevent injection
- ✅ Input validation and sanitization
- ✅ Foreign key constraints with cascade delete
- ✅ JWT authentication and role-based access
- ✅ Error handling and user feedback

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd imarat-builders-mall-crud
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure database and environment**
   - Create a PostgreSQL database named `imarat_mall`
   - Update `config.env` with your database credentials and JWT secrets:
   ```env
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=imarat_mall
   DB_USER=your_username
   DB_PASSWORD=your_password
   PORT=3000
   NODE_ENV=development
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRES_IN=1h
   JWT_REFRESH_SECRET=your_refresh_secret
   JWT_REFRESH_EXPIRES_IN=7d
   ```

4. **Initialize database**
   ```bash
   npm run init-db
   ```

5. **Start the application**
   ```bash
   # Development mode with auto-reload
   npm run dev
   
   # Production mode
   npm start
   ```

6. **Access the application**
   - Open your browser and navigate to `http://localhost:3000`
   - The API will be available at `http://localhost:3000/api`

## 📁 Project Structure

```
imarat-builders-mall-crud/
├── database/
│   ├── connection.js      # Database connection pool
│   └── init.js           # Database initialization script
├── models/
│   ├── Category.js       # Category model
│   ├── Brand.js          # Brand model
│   ├── Product.js        # Product model
│   ├── User.js           # User model
│   ├── CartItem.js       # Cart model
│   ├── Order.js          # Order model
│   ├── OrderItem.js      # Order item model
│   └── Review.js         # Review model
├── controllers/
│   ├── categoryController.js
│   ├── brandController.js
│   ├── productController.js
│   ├── userController.js
│   ├── cartController.js
│   ├── orderController.js
│   └── reviewController.js
├── routes/
│   ├── categoryRoutes.js
│   ├── brandRoutes.js
│   ├── productRoutes.js
│   ├── userRoutes.js
│   ├── cartRoutes.js
│   ├── orderRoutes.js
│   └── reviewRoutes.js
├── middleware/
│   ├── auth.js           # JWT auth middleware
│   └── roleCheck.js      # Role-based access middleware
├── utils/
│   └── token.js          # JWT token utilities
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── app.js        # Main frontend logic
│   │   ├── auth.js       # Auth state/token management
│   │   └── review.js     # Product review logic
│   ├── index.html        # Main app page
│   ├── login.html        # Login page
│   ├── register.html     # Register page
│   ├── cart.html         # Cart page
│   ├── orders.html       # Order history
│   ├── admin.html        # Admin dashboard
│   └── 404.html          # 404 error page
├── server.js             # Express server setup
├── package.json          # Dependencies & scripts
├── config.env            # Environment configuration
├── setup.sh              # Setup script
└── README.md             # This file
```

## 🔌 API Endpoints

### Auth & Users
- `POST /api/users/register` - Register new user
- `POST /api/users/login` - Login (returns tokens)
- `GET /api/users/profile` - Get current user profile
- `GET /api/users/all` - List all users (admin)
- `GET /api/users/stats` - User stats (admin)

### Cart
- `GET /api/cart` - Get current user's cart
- `POST /api/cart/add` - Add/update cart item
- `POST /api/cart/remove` - Remove item from cart
- `POST /api/cart/clear` - Clear cart

### Orders
- `POST /api/orders/place` - Place order
- `GET /api/orders/my` - Get current user's orders
- `GET /api/orders/all` - Get all orders (admin)
- `GET /api/orders/stats` - Order stats (admin)
- `GET /api/orders/:id` - Get order details

### Reviews
- `GET /api/reviews/product/:product_id` - Get reviews for product
- `GET /api/reviews/product/:product_id/average` - Get average rating
- `GET /api/reviews/my` - Get current user's reviews
- `POST /api/reviews/add` - Add/update review
- `POST /api/reviews/delete` - Delete review

### Categories, Brands, Products
- `GET /api/categories`, `POST /api/categories`, etc. (see original docs)
- `GET /api/brands`, `POST /api/brands`, etc.
- `GET /api/products`, `POST /api/products`, etc.

### Health Check
- `GET /api/health` - API health status

## 🎨 Frontend Usage

### Login & Registration
- Go to `/login.html` or `/register.html`
- Register as a new user or login as admin/user
- Tokens are stored in localStorage

### Product Grid & Cart
- Browse products on the main page
- Click "Add to Cart" to add products
- Go to `/cart.html` to view/update your cart and checkout

### Orders
- Go to `/orders.html` to view your order history

### Product Reviews
- On product detail modal, see average rating and reviews
- Logged-in users can add/edit/delete their review

### Admin Dashboard
- Go to `/admin.html` (admin only)
- View stats, revenue, top products, and sales charts

### Toast Notifications & Feedback
- All actions (login, add to cart, checkout, review, CRUD) show toast notifications for success/failure
- Form validation and error handling throughout

## 🛠️ Deployment

### Environment Variables
Set the following in `config.env` (or your deployment platform):
- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`
- `PORT`, `NODE_ENV`
- `JWT_SECRET`, `JWT_EXPIRES_IN`, `JWT_REFRESH_SECRET`, `JWT_REFRESH_EXPIRES_IN`

### Production Considerations
- Use HTTPS and secure cookies
- Set strong JWT secrets
- Set up database backups
- Use a process manager (PM2, etc.)
- Configure CORS as needed

## 📝 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the API documentation at `/api/health`
- Review the console logs for debugging information

---

**Built with ❤️ for Imarat Builders Mall** 