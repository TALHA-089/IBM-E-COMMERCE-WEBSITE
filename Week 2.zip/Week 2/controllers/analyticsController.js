const pool = require('../database/connection');

// Get delivery analytics overview
exports.getDeliveryAnalytics = async (req, res) => {
    try {
        const { timeframe = '30' } = req.query; // days
        const days = parseInt(timeframe);

        // Delivery statistics
        const deliveryStatsQuery = `
            SELECT 
                COUNT(*) as total_deliveries,
                COUNT(CASE WHEN actual_delivery_date IS NOT NULL THEN 1 END) as completed_deliveries,
                COUNT(CASE WHEN estimated_delivery_date < CURRENT_DATE AND actual_delivery_date IS NULL THEN 1 END) as overdue_deliveries,
                AVG(CASE WHEN actual_delivery_date IS NOT NULL 
                    THEN EXTRACT(DAY FROM actual_delivery_date - created_at) 
                    END) as avg_delivery_time,
                SUM(shipping_cost) as total_shipping_revenue
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
        `;

        // Delivery status breakdown
        const statusBreakdownQuery = `
            SELECT 
                ds.status,
                ds.description,
                COUNT(DISTINCT d.id) as count,
                ROUND(COUNT(DISTINCT d.id) * 100.0 / 
                    (SELECT COUNT(*) FROM deliveries WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'), 2) as percentage
            FROM delivery_statuses ds
            LEFT JOIN tracking_events te ON ds.id = te.status_id
            LEFT JOIN deliveries d ON te.delivery_id = d.id AND d.created_at >= CURRENT_DATE - INTERVAL '${days} days'
            WHERE te.id IN (
                SELECT MAX(te2.id) 
                FROM tracking_events te2 
                JOIN deliveries d2 ON te2.delivery_id = d2.id 
                WHERE d2.created_at >= CURRENT_DATE - INTERVAL '${days} days'
                GROUP BY te2.delivery_id
            ) OR d.id IS NULL
            GROUP BY ds.id, ds.status, ds.description
            ORDER BY count DESC
        `;

        // Delivery method performance
        const methodPerformanceQuery = `
            SELECT 
                delivery_method,
                COUNT(*) as total_orders,
                AVG(shipping_cost) as avg_cost,
                AVG(CASE WHEN actual_delivery_date IS NOT NULL 
                    THEN EXTRACT(DAY FROM actual_delivery_date - created_at) 
                    END) as avg_delivery_days,
                COUNT(CASE WHEN actual_delivery_date <= estimated_delivery_date THEN 1 END) as on_time_deliveries,
                ROUND(COUNT(CASE WHEN actual_delivery_date <= estimated_delivery_date THEN 1 END) * 100.0 / 
                    COUNT(CASE WHEN actual_delivery_date IS NOT NULL THEN 1 END), 2) as on_time_percentage
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            GROUP BY delivery_method
            ORDER BY total_orders DESC
        `;

        // Daily delivery trends
        const dailyTrendsQuery = `
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as deliveries_created,
                COUNT(CASE WHEN actual_delivery_date::date = DATE(created_at) THEN 1 END) as deliveries_completed,
                SUM(shipping_cost) as daily_shipping_revenue
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            GROUP BY DATE(created_at)
            ORDER BY date DESC
            LIMIT 30
        `;

        // Top delivery locations
        const topLocationsQuery = `
            SELECT 
                COALESCE(
                    (shipping_address->>'city'), 
                    SUBSTRING(delivery_address FROM 'city["\s]*:["\s]*([^"]*)')
                ) as city,
                COALESCE(
                    (shipping_address->>'state'), 
                    SUBSTRING(delivery_address FROM 'state["\s]*:["\s]*([^"]*)')
                ) as state,
                COUNT(*) as delivery_count,
                AVG(shipping_cost) as avg_shipping_cost
            FROM deliveries d
            LEFT JOIN orders o ON d.order_id = o.id
            WHERE d.created_at >= CURRENT_DATE - INTERVAL '${days} days'
            GROUP BY city, state
            HAVING city IS NOT NULL AND city != ''
            ORDER BY delivery_count DESC
            LIMIT 10
        `;

        const [
            deliveryStats,
            statusBreakdown,
            methodPerformance,
            dailyTrends,
            topLocations
        ] = await Promise.all([
            pool.query(deliveryStatsQuery),
            pool.query(statusBreakdownQuery),
            pool.query(methodPerformanceQuery),
            pool.query(dailyTrendsQuery),
            pool.query(topLocationsQuery)
        ]);

        res.json({
            success: true,
            data: {
                overview: deliveryStats.rows[0],
                statusBreakdown: statusBreakdown.rows,
                methodPerformance: methodPerformance.rows,
                dailyTrends: dailyTrends.rows.reverse(),
                topLocations: topLocations.rows,
                timeframe: `${days} days`
            }
        });

    } catch (error) {
        console.error('Delivery analytics error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get delivery analytics',
            error: error.message
        });
    }
};

// Get carrier performance analytics
exports.getCarrierPerformance = async (req, res) => {
    try {
        const { timeframe = '30' } = req.query;
        const days = parseInt(timeframe);

        const carrierQuery = `
            SELECT 
                carrier,
                COUNT(*) as total_shipments,
                AVG(shipping_cost) as avg_cost,
                AVG(CASE WHEN actual_delivery_date IS NOT NULL 
                    THEN EXTRACT(DAY FROM actual_delivery_date - created_at) 
                    END) as avg_delivery_time,
                COUNT(CASE WHEN actual_delivery_date <= estimated_delivery_date THEN 1 END) as on_time_count,
                COUNT(CASE WHEN actual_delivery_date > estimated_delivery_date THEN 1 END) as late_count,
                ROUND(COUNT(CASE WHEN actual_delivery_date <= estimated_delivery_date THEN 1 END) * 100.0 / 
                    COUNT(CASE WHEN actual_delivery_date IS NOT NULL THEN 1 END), 2) as on_time_percentage
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            AND carrier IS NOT NULL
            GROUP BY carrier
            ORDER BY total_shipments DESC
        `;

        const result = await pool.query(carrierQuery);

        res.json({
            success: true,
            data: result.rows
        });

    } catch (error) {
        console.error('Carrier performance error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get carrier performance',
            error: error.message
        });
    }
};

// Get customer satisfaction metrics
exports.getCustomerSatisfaction = async (req, res) => {
    try {
        const { timeframe = '30' } = req.query;
        const days = parseInt(timeframe);

        // Customer satisfaction based on delivery performance
        const satisfactionQuery = `
            SELECT 
                CASE 
                    WHEN actual_delivery_date <= estimated_delivery_date THEN 'On Time'
                    WHEN actual_delivery_date <= estimated_delivery_date + INTERVAL '1 day' THEN '1 Day Late'
                    WHEN actual_delivery_date <= estimated_delivery_date + INTERVAL '3 days' THEN '2-3 Days Late'
                    ELSE 'More than 3 Days Late'
                END as delivery_performance,
                COUNT(*) as count,
                ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 2) as percentage
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            AND actual_delivery_date IS NOT NULL
            GROUP BY 
                CASE 
                    WHEN actual_delivery_date <= estimated_delivery_date THEN 'On Time'
                    WHEN actual_delivery_date <= estimated_delivery_date + INTERVAL '1 day' THEN '1 Day Late'
                    WHEN actual_delivery_date <= estimated_delivery_date + INTERVAL '3 days' THEN '2-3 Days Late'
                    ELSE 'More than 3 Days Late'
                END
            ORDER BY count DESC
        `;

        // Failed delivery analysis
        const failedDeliveryQuery = `
            SELECT 
                COUNT(*) as total_failed,
                COUNT(CASE WHEN te.notes ILIKE '%address%' THEN 1 END) as address_issues,
                COUNT(CASE WHEN te.notes ILIKE '%not home%' OR te.notes ILIKE '%unavailable%' THEN 1 END) as unavailable_customer,
                COUNT(CASE WHEN te.notes ILIKE '%damaged%' THEN 1 END) as damaged_package,
                COUNT(CASE WHEN te.notes ILIKE '%weather%' THEN 1 END) as weather_issues
            FROM tracking_events te
            JOIN delivery_statuses ds ON te.status_id = ds.id
            WHERE ds.status = 'failed_delivery'
            AND te.event_timestamp >= CURRENT_DATE - INTERVAL '${days} days'
        `;

        const [satisfaction, failedDeliveries] = await Promise.all([
            pool.query(satisfactionQuery),
            pool.query(failedDeliveryQuery)
        ]);

        res.json({
            success: true,
            data: {
                deliveryPerformance: satisfaction.rows,
                failedDeliveryAnalysis: failedDeliveries.rows[0]
            }
        });

    } catch (error) {
        console.error('Customer satisfaction error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get customer satisfaction metrics',
            error: error.message
        });
    }
};

// Get cost analysis
exports.getCostAnalysis = async (req, res) => {
    try {
        const { timeframe = '30' } = req.query;
        const days = parseInt(timeframe);

        const costQuery = `
            SELECT 
                delivery_method,
                COUNT(*) as shipment_count,
                SUM(shipping_cost) as total_cost,
                AVG(shipping_cost) as avg_cost,
                MIN(shipping_cost) as min_cost,
                MAX(shipping_cost) as max_cost,
                SUM(shipping_cost) / COUNT(*) as cost_per_shipment
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            AND shipping_cost > 0
            GROUP BY delivery_method
            ORDER BY total_cost DESC
        `;

        // Cost trends over time
        const costTrendsQuery = `
            SELECT 
                DATE(created_at) as date,
                SUM(shipping_cost) as daily_shipping_cost,
                COUNT(*) as daily_shipments,
                AVG(shipping_cost) as avg_daily_cost
            FROM deliveries 
            WHERE created_at >= CURRENT_DATE - INTERVAL '${days} days'
            GROUP BY DATE(created_at)
            ORDER BY date DESC
            LIMIT 30
        `;

        const [costAnalysis, costTrends] = await Promise.all([
            pool.query(costQuery),
            pool.query(costTrendsQuery)
        ]);

        res.json({
            success: true,
            data: {
                costByMethod: costAnalysis.rows,
                costTrends: costTrends.rows.reverse()
            }
        });

    } catch (error) {
        console.error('Cost analysis error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get cost analysis',
            error: error.message
        });
    }
};
