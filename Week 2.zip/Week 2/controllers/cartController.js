const CartItem = require('../models/CartItem');
const Product = require('../models/Product');

exports.getCart = async (req, res) => {
  try {
    const cart = await CartItem.getCartByUser(req.user.id);
    res.json({ success: true, cart });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.addOrUpdate = async (req, res) => {
  try {
    const { product_id, quantity } = req.body;
    if (!product_id || !quantity || quantity < 1) {
      return res.status(400).json({ success: false, message: 'Product and valid quantity required.' });
    }
    // check stock
    const product = await Product.getById(product_id);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }
    if (product.stock < quantity) {
      return res.status(400).json({ success: false, message: 'Requested quantity exceeds available stock.' });
    }
    const item = await CartItem.addOrUpdate(req.user.id, product_id, quantity);
    res.json({ success: true, item });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.remove = async (req, res) => {
  try {
    const { product_id } = req.body;
    if (!product_id) {
      return res.status(400).json({ success: false, message: 'Product required.' });
    }
    await CartItem.remove(req.user.id, product_id);
    res.json({ success: true, message: 'Item removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.clearCart = async (req, res) => {
  try {
    await CartItem.clearCart(req.user.id);
    res.json({ success: true, message: 'Cart cleared.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
}; 