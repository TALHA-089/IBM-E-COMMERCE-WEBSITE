const Delivery = require('../models/Delivery');
const Order = require('../models/Order');
const notificationService = require('../utils/notificationService');

// Create delivery for an order
exports.createDelivery = async (req, res) => {
    try {
        const { order_id } = req.params;
        const {
            delivery_method = 'standard',
            delivery_address,
            delivery_instructions,
            weight_kg,
            dimensions,
            shipping_cost
        } = req.body;

        // Verify order exists and belongs to user (if not admin)
        const order = await Order.findById(order_id);
        if (!order) {
            return res.status(404).json({ success: false, message: 'Order not found' });
        }

        // Check if delivery already exists for this order
        const existingDelivery = await Delivery.getByOrderId(order_id);
        if (existingDelivery) {
            return res.status(400).json({ 
                success: false, 
                message: 'Delivery already exists for this order',
                tracking_number: existingDelivery.tracking_number
            });
        }

        // Calculate estimated delivery date based on method
        const estimatedDays = {
            'standard': 5,
            'express': 3,
            'overnight': 1,
            'pickup': 0
        };

        const estimated_delivery_date = new Date();
        estimated_delivery_date.setDate(estimated_delivery_date.getDate() + estimatedDays[delivery_method]);

        const deliveryData = {
            order_id: parseInt(order_id),
            delivery_method,
            delivery_address: delivery_address || order.shipping_address,
            delivery_instructions,
            estimated_delivery_date: estimated_delivery_date.toISOString().split('T')[0],
            weight_kg,
            dimensions,
            shipping_cost
        };

        const result = await Delivery.create(deliveryData);

        // Send notification for delivery creation
        await notificationService.sendDeliveryStatusNotification(
            order_id, 
            'order_confirmed', 
            'Warehouse', 
            'Your order has been confirmed and is being prepared for shipment'
        );

        res.json({
            success: true,
            message: 'Delivery created successfully',
            data: {
                delivery_id: result.id,
                tracking_number: result.tracking_number,
                estimated_delivery: estimated_delivery_date
            }
        });

    } catch (error) {
        console.error('Create delivery error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to create delivery',
            error: error.message 
        });
    }
};

// Get tracking information
exports.getTracking = async (req, res) => {
    try {
        const { tracking_number } = req.params;

        const trackingInfo = await Delivery.getFullTrackingInfo(tracking_number);
        
        if (!trackingInfo) {
            return res.status(404).json({ 
                success: false, 
                message: 'Tracking number not found' 
            });
        }

        res.json({
            success: true,
            data: trackingInfo
        });

    } catch (error) {
        console.error('Get tracking error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to get tracking information',
            error: error.message 
        });
    }
};

// Update delivery status
exports.updateDeliveryStatus = async (req, res) => {
    try {
        const { delivery_id } = req.params;
        const { status_id, location, notes, notify_customer = true } = req.body;
        const created_by = req.user?.email || 'admin';

        await Delivery.updateStatus(delivery_id, status_id, location, notes, created_by);

        // Get delivery info for notifications
        const deliveryInfo = await Delivery.getById(delivery_id);
        if (deliveryInfo && notify_customer) {
            // Map status_id to status key for notification
            const statusMapping = {
                1: 'order_confirmed',
                2: 'processing', 
                3: 'shipped',
                4: 'out_for_delivery',
                5: 'delivered',
                6: 'failed_delivery',
                7: 'returned'
            };
            
            const statusKey = statusMapping[status_id];
            if (statusKey) {
                await notificationService.sendDeliveryStatusNotification(
                    deliveryInfo.order_id,
                    statusKey,
                    location,
                    notes
                );
            }
        }

        // Update order delivery_status as well
        if (deliveryInfo) {
            const deliveryStatusMapping = {
                1: 'pending',
                2: 'processing',
                3: 'shipped',
                4: 'out_for_delivery',
                5: 'delivered',
                6: 'failed_delivery',
                7: 'returned'
            };
            
            const orderStatus = deliveryStatusMapping[status_id];
            if (orderStatus) {
                await Order.updateDeliveryStatus(deliveryInfo.order_id, orderStatus);
            }
        }

        res.json({
            success: true,
            message: 'Delivery status updated successfully'
        });

    } catch (error) {
        console.error('Update delivery status error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to update delivery status',
            error: error.message 
        });
    }
};

// Get delivery statuses
exports.getDeliveryStatuses = async (req, res) => {
    try {
        const statuses = await Delivery.getDeliveryStatuses();
        
        res.json({
            success: true,
            data: statuses
        });

    } catch (error) {
        console.error('Get delivery statuses error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to get delivery statuses',
            error: error.message 
        });
    }
};

// Get user's deliveries
exports.getUserDeliveries = async (req, res) => {
    try {
        const user_id = req.user.id;
        
        const deliveries = await Delivery.getByUserId(user_id);
        
        res.json({
            success: true,
            data: deliveries
        });

    } catch (error) {
        console.error('Get user deliveries error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to get deliveries',
            error: error.message 
        });
    }
};

// Get order tracking (for customers)
exports.getOrderTracking = async (req, res) => {
    try {
        const { order_id } = req.params;
        const user_id = req.user.id;

        // Verify order belongs to user
        const order = await Order.findById(order_id);
        if (!order || order.user_id !== user_id) {
            return res.status(404).json({ 
                success: false, 
                message: 'Order not found' 
            });
        }

        const delivery = await Delivery.getByOrderId(order_id);
        if (!delivery) {
            return res.json({
                success: true,
                data: {
                    order_id,
                    status: 'Order confirmed, preparing for shipment',
                    tracking_number: null,
                    tracking_history: []
                }
            });
        }

        const trackingHistory = await Delivery.getTrackingHistory(delivery.tracking_number);

        res.json({
            success: true,
            data: {
                order_id,
                tracking_number: delivery.tracking_number,
                delivery_method: delivery.delivery_method,
                estimated_delivery: delivery.estimated_delivery_date,
                actual_delivery: delivery.actual_delivery_date,
                tracking_history: trackingHistory,
                current_status: trackingHistory[trackingHistory.length - 1] || null
            }
        });

    } catch (error) {
        console.error('Get order tracking error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Failed to get order tracking',
            error: error.message 
        });
    }
};
