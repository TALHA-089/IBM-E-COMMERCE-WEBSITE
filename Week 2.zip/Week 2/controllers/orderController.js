const Order = require('../models/Order');
const OrderItem = require('../models/OrderItem');
const pool = require('../database/connection');

exports.placeOrder = async (req, res) => {
  try {
    const { 
      items, 
      total_amount, 
      shipping_address, 
      payment_method, 
      subtotal, 
      shipping_cost, 
      tax_amount 
    } = req.body;
    
    const totalNum = parseFloat(total_amount);
    if (!items || !Array.isArray(items) || items.length === 0 || isNaN(totalNum)) {
      return res.status(400).json({ success: false, message: 'Order items and total amount required.' });
    }
    

    const orderData = {
      user_id: req.user.id,
      items,
      total_amount: totalNum,
      shipping_address: shipping_address || {},
      payment_method: payment_method || 'cash',
      subtotal: parseFloat(subtotal || totalNum),
      shipping_cost: parseFloat(shipping_cost || 0),
      tax_amount: parseFloat(tax_amount || 0),
      status: 'pending'
    };
    
    const order = await Order.create(orderData);
    
    // Clear user's cart after successful order
    try {
      const Cart = require('../models/Cart');
      await Cart.clearByUser(req.user.id);
    } catch (cartError) {
      console.warn('Failed to clear cart:', cartError.message);
    }
    
    res.status(201).json({ success: true, order });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getMyOrders = async (req, res) => {
  try {
        res.set('Cache-Control', 'no-store');
    const orders = await Order.getByUser(req.user.id);
    console.log('Orders from DB:', JSON.stringify(orders, null, 2));
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getAllOrders = async (req, res) => {
  try {
    let orders = await Order.getAll();
    // populate items for each order (needed for charts)
    const populated = [];
    for(const order of orders){
      const itemsRes = await pool.query(`SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=$1`,[order.id]);
      populated.push({...order, items: itemsRes.rows});
    }
    res.json({ success: true, orders: populated });
  } catch (err) {
    console.error('getAllOrders error',err.message);
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    const order = await Order.getById(id);
    res.json({ success: true, order });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const stats = await Order.getStats();
    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.cancelOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const order = await Order.getById(id);
    
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }
    
    // Check if user owns this order (non-admin users can only cancel their own orders)
    if (req.user.role !== 'admin' && order.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }
    
    // Check if order can be cancelled
    if (!['pending', 'confirmed'].includes(order.status)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Order cannot be cancelled in current status' 
      });
    }
    
    const updatedOrder = await Order.updateStatus(id, 'cancelled');
    res.json({ success: true, order: updatedOrder });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
}; 