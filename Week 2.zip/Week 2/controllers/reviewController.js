const Review = require('../models/Review');

exports.getByProduct = async (req, res) => {
  try {
    const { product_id } = req.params;
    const reviews = await Review.getByProduct(product_id);
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getByUser = async (req, res) => {
  try {
    const reviews = await Review.getByUser(req.user.id);
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.addOrUpdate = async (req, res) => {
  try {
    const { product_id, rating, comment } = req.body;
    if (!product_id || !rating) {
      return res.status(400).json({ success: false, message: 'Product and rating required.' });
    }
    const review = await Review.addOrUpdate(req.user.id, product_id, rating, comment);
    res.json({ success: true, review });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const { product_id } = req.body;
    if (!product_id) {
      return res.status(400).json({ success: false, message: 'Product required.' });
    }
    await Review.delete(req.user.id, product_id);
    res.json({ success: true, message: 'Review deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getAverageRating = async (req, res) => {
  try {
    const { product_id } = req.params;
    const avg = await Review.getAverageRating(product_id);
    res.json({ success: true, avg });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
}; 