const shippingService = require('../utils/shippingService');
const Order = require('../models/Order');

// Get shipping rates for checkout
exports.getShippingRates = async (req, res) => {
    try {
        const { 
            origin = { postalCode: '10001', country: 'US' },
            destination,
            packages,
            serviceType = 'standard'
        } = req.body;

        if (!destination || !destination.postalCode) {
            return res.status(400).json({
                success: false,
                message: 'Destination postal code is required'
            });
        }

        const shipment = {
            origin,
            destination,
            packages: packages || [{ weight: 1, length: 12, width: 12, height: 6 }],
            serviceType
        };

        const rates = await shippingService.getShippingRates(shipment);

        res.json({
            success: true,
            data: {
                rates,
                origin,
                destination
            }
        });

    } catch (error) {
        console.error('Get shipping rates error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get shipping rates',
            error: error.message
        });
    }
};

// Create shipment for order
exports.createShipment = async (req, res) => {
    try {
        const { order_id } = req.params;
        const { delivery_method = 'standard', carrier_preference } = req.body;

        // Verify order exists
        const order = await Order.findById(order_id);
        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order not found'
            });
        }

        // Create shipment with external carrier
        const shipmentData = {
            order_id: order.id,
            customer: {
                name: order.customer_name || 'Customer',
                email: order.customer_email,
                phone: order.customer_phone
            },
            shipping_address: order.shipping_address,
            items: order.items || [],
            delivery_method,
            carrier_preference
        };

        const shipment = await shippingService.createShipment(shipmentData, delivery_method);

        res.json({
            success: true,
            message: 'Shipment created successfully',
            data: {
                tracking_number: shipment.trackingNumber,
                carrier: shipment.carrier,
                service: shipment.service,
                estimated_delivery: shipment.estimatedDelivery
            }
        });

    } catch (error) {
        console.error('Create shipment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create shipment',
            error: error.message
        });
    }
};

// Track external shipment
exports.trackExternalShipment = async (req, res) => {
    try {
        const { tracking_number } = req.params;
        const { carrier = 'auto' } = req.query;

        const trackingInfo = await shippingService.trackShipment(tracking_number, carrier);

        if (!trackingInfo) {
            return res.status(404).json({
                success: false,
                message: 'External tracking information not available'
            });
        }

        res.json({
            success: true,
            data: trackingInfo
        });

    } catch (error) {
        console.error('Track external shipment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to track external shipment',
            error: error.message
        });
    }
};

// Get supported carriers and services
exports.getCarriers = async (req, res) => {
    try {
        const carriers = [
            {
                code: 'internal',
                name: 'In-House Delivery',
                services: [
                    { code: 'standard', name: 'Standard (5-7 days)', days: 5 },
                    { code: 'express', name: 'Express (2-3 days)', days: 3 },
                    { code: 'overnight', name: 'Overnight', days: 1 },
                    { code: 'pickup', name: 'Store Pickup', days: 0 }
                ]
            },
            {
                code: 'fedex',
                name: 'FedEx',
                services: [
                    { code: 'FEDEX_GROUND', name: 'FedEx Ground', days: 5 },
                    { code: 'FEDEX_2_DAY', name: 'FedEx 2Day', days: 2 },
                    { code: 'STANDARD_OVERNIGHT', name: 'FedEx Standard Overnight', days: 1 }
                ]
            },
            {
                code: 'ups',
                name: 'UPS',
                services: [
                    { code: 'ups_ground', name: 'UPS Ground', days: 5 },
                    { code: 'ups_2day', name: 'UPS 2nd Day Air', days: 2 },
                    { code: 'ups_overnight', name: 'UPS Next Day Air', days: 1 }
                ]
            }
        ];

        res.json({
            success: true,
            data: carriers
        });

    } catch (error) {
        console.error('Get carriers error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get carriers',
            error: error.message
        });
    }
};
