const User = require('../models/User');
const AdditionalInfo = require('../models/AdditionalInfo');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
require('dotenv').config({ path: './config.env' });

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
},
{
  logger: true,       // log to console
  debug: true         // include SMTP traffic
});

// verify connection once at startup
transporter.verify((err, success) => {
  if (err) {
    console.error('SMTP verify failed:', err);
  } else {
    console.log('✓ Gmail SMTP ready to send emails');
  }
});

async function sendVerificationEmail(email, token) {
  const verifyUrl = `http://localhost:${process.env.PORT || 3000}/verify-email?token=${token}&email=${encodeURIComponent(email)}`;
  const mailOptions = {
    from: `No Reply <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Verify your email address',
    html: `<p>Please verify your email by clicking the link: <a href="${verifyUrl}">${verifyUrl}</a></p>`
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email accepted by Gmail, id:', info.messageId);
  } catch (err) {
    console.error('sendMail failed');
    console.error('code:', err.code);
    console.error('response:', err.response);
    console.error(err);
    throw err;
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1h';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'refreshsecret';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}
function signRefreshToken(user) {
  return jwt.sign({ id: user.id, role: user.role }, JWT_REFRESH_SECRET, { expiresIn: JWT_REFRESH_EXPIRES_IN });
}

exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }
    const existing = await User.findByEmail(email);
    if (existing) {
      return res.status(400).json({ success: false, message: 'Email already registered.' });
    }
    const verification_token = crypto.randomBytes(32).toString('hex');
    await User.create({ name, email, password, verification_token });

    // send email (async but awaited to catch errors)
    try {
      await sendVerificationEmail(email, verification_token);
    } catch (mailErr) {
      console.error('Email send error:', mailErr);
    }
    res.status(201).json({ success: true, message: 'Registration successful. Please check your inbox to verify your email.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password required.' });
    }
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }
    if (!user.is_verified) {
      return res.status(403).json({ success: false, message: 'Please verify your email before logging in.' });
    }
    const valid = await User.comparePassword(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }
    const accessToken = signToken(user);
    const refreshToken = signRefreshToken(user);
    res.json({
      success: true,
      message: 'Login successful.',
      accessToken,
      refreshToken,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.verifyEmail = async (req, res) => {
  try {
    const { token, email } = req.query;
    if (!token || !email) return res.status(400).send('Invalid link');
    const user = await User.verifyEmail(token, email);
    if (!user) return res.status(400).send('Verification link is invalid or expired');
    res.send('Email verified successfully! You may now log in.');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    const pool = require('../database/connection');
    let additional = null;
    try {
      additional = await AdditionalInfo.getByUserId(user.id);
    } catch(err){
      console.error('Error fetching additional info', err.message);
    }
    // stats
    let stats={};
    try{
      const ordersRes = await pool.query('SELECT COUNT(*) AS cnt, MIN(created_at) AS first_order FROM orders WHERE user_id=$1',[user.id]);
      stats.orders = parseInt(ordersRes.rows[0].cnt) || 0;
      stats.memberSince = ordersRes.rows[0].first_order ? new Date(ordersRes.rows[0].first_order).getFullYear() : '';
      const wishRes = await pool.query('SELECT COUNT(*) FROM wishlist_items WHERE user_id=$1',[user.id]);
      stats.wishlist = parseInt(wishRes.rows[0].count) || 0;
    }catch(err){console.error('stats query error',err.message);}

    res.json({ success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role, additional }, stats });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.logout = async (req,res)=>{
  try{
    // in future we could blacklist refresh tokens etc.
    res.json({success:true,message:'Logged out'});
  }catch(err){res.status(500).json({success:false,message:err.message});}
};

exports.updateAdditionalInfo = async (req, res) => {
  try {
    const { phone, address, bio, photo_base64, dob, gender } = req.body;
    const updated = await AdditionalInfo.upsert({ user_id: req.user.id, phone, address, bio, photo_base64, dob, gender });
    res.json({ success: true, additional: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.getAll();
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const stats = await User.getStats();
    res.json({ success: true, stats });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
}; 