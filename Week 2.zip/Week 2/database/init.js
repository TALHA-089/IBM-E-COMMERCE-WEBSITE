const { Pool } = require('pg');
require('dotenv').config({ path: './config.env' });

const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
});

async function initializeDatabase() {
  try {
    console.log('Connecting to PostgreSQL...');
    
    // Create tables with proper foreign key relationships
    const createTablesQuery = `
      -- Create Categories table
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Create Brands table with foreign key to Categories
      CREATE TABLE IF NOT EXISTS brands (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(name, category_id)
      );

      -- Create Products table with foreign key to Brands
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        brand_id INTEGER NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
        price DECIMAL(10,2) NOT NULL CHECK (price > 0),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Create indexes for better performance
      CREATE INDEX IF NOT EXISTS idx_brands_category_id ON brands(category_id);
      CREATE INDEX IF NOT EXISTS idx_products_brand_id ON products(brand_id);
    `;

    await pool.query(createTablesQuery);
    console.log('✅ Database tables created successfully!');

    // Insert sample data
    const insertSampleData = `
      -- Insert sample categories
      INSERT INTO categories (name) VALUES 
        ('Electronics'),
        ('Fashion'),
        ('Home & Garden'),
        ('Sports & Outdoors')
      ON CONFLICT (name) DO NOTHING;

      -- Insert sample brands
      INSERT INTO brands (name, category_id) VALUES 
        ('Apple', (SELECT id FROM categories WHERE name = 'Electronics')),
        ('Samsung', (SELECT id FROM categories WHERE name = 'Electronics')),
        ('Nike', (SELECT id FROM categories WHERE name = 'Sports & Outdoors')),
        ('Adidas', (SELECT id FROM categories WHERE name = 'Sports & Outdoors')),
        ('Zara', (SELECT id FROM categories WHERE name = 'Fashion')),
        ('IKEA', (SELECT id FROM categories WHERE name = 'Home & Garden'))
      ON CONFLICT (name, category_id) DO NOTHING;

      -- Insert sample products
      INSERT INTO products (name, brand_id, price, description) VALUES 
        ('iPhone 15 Pro', (SELECT id FROM brands WHERE name = 'Apple'), 999.99, 'Latest iPhone with advanced features'),
        ('Galaxy S24', (SELECT id FROM brands WHERE name = 'Samsung'), 899.99, 'Premium Android smartphone'),
        ('Air Max 270', (SELECT id FROM brands WHERE name = 'Nike'), 150.00, 'Comfortable running shoes'),
        ('Ultraboost 22', (SELECT id FROM brands WHERE name = 'Adidas'), 180.00, 'High-performance running shoes'),
        ('Summer Dress', (SELECT id FROM brands WHERE name = 'Zara'), 89.99, 'Elegant summer collection dress'),
        ('Billy Bookcase', (SELECT id FROM brands WHERE name = 'IKEA'), 79.99, 'Classic bookcase for home organization')
      ON CONFLICT DO NOTHING;
    `;

    await pool.query(insertSampleData);
    console.log('✅ Sample data inserted successfully!');

    // --- NEW TABLES FOR ADVANCED FEATURES ---
    const createAdvancedTablesQuery = `
      -- Users table
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Cart Items table
      CREATE TABLE IF NOT EXISTS cart_items (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, product_id)
      );

      -- Orders table
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        total_amount DECIMAL(10,2) NOT NULL CHECK (total_amount >= 0),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Order Items table
      CREATE TABLE IF NOT EXISTS order_items (
        id SERIAL PRIMARY KEY,
        order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );

      -- Reviews table
      CREATE TABLE IF NOT EXISTS reviews (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
        rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
        comment TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, product_id)
      );
    `;
    await pool.query(createAdvancedTablesQuery);
    console.log('✅ Advanced tables created successfully!');

    // Insert sample users (admin and user)
    const bcrypt = require('bcryptjs');
    const adminHash = await bcrypt.hash('admin123', 10);
    const userHash = await bcrypt.hash('user123', 10);
    const insertUsers = `
      INSERT INTO users (name, email, password_hash, role) VALUES
        ('Admin', 'admin@imarat.com', $1, 'admin'),
        ('User', 'user@imarat.com', $2, 'user')
      ON CONFLICT (email) DO NOTHING;
    `;
    await pool.query(insertUsers, [adminHash, userHash]);
    console.log('✅ Sample users inserted (admin/user)');

  } catch (error) {
    console.error('❌ Error initializing database:', error);
  } finally {
    await pool.end();
  }
}

initializeDatabase(); 