-- Enhance orders table for checkout process
ALTER TABLE orders 
    ADD COLUMN IF NOT EXISTS shipping_address JSONB,
    ADD COLUMN IF NOT EXISTS payment_method VARCHAR(50) DEFAULT 'cash',
    ADD COLUMN IF NOT EXISTS subtotal NUMERIC(10,2),
    ADD COLUMN IF NOT EXISTS shipping_cost NUMERIC(10,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS tax_amount NUMERIC(10,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'pending',
    ADD COLUMN IF NOT EXISTS notes TEXT;
