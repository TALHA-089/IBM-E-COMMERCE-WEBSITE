-- Delivery System Database Schema Migration
-- Phase 1: Core delivery and tracking tables (PostgreSQL)

-- 1. Delivery status lookup table
CREATE TABLE delivery_statuses (
    id SERIAL PRIMARY KEY,
    status VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default delivery statuses
INSERT INTO delivery_statuses (status, description, sort_order) VALUES
('order_confirmed', 'Order has been confirmed and is being prepared', 1),
('processing', 'Order is being processed and packed', 2),
('shipped', 'Order has been shipped and is in transit', 3),
('out_for_delivery', 'Order is out for delivery', 4),
('delivered', 'Order has been successfully delivered', 5),
('failed_delivery', 'Delivery attempt failed', 6),
('returned', 'Order has been returned to sender', 7);

-- 2. Create delivery method type
CREATE TYPE delivery_method_type AS ENUM ('standard', 'express', 'overnight', 'pickup');

-- 3. Create delivery status type
CREATE TYPE delivery_status_type AS ENUM (
    'pending', 'processing', 'shipped', 'out_for_delivery', 
    'delivered', 'failed_delivery', 'returned'
);

-- 4. Delivery assignments table
CREATE TABLE deliveries (
    id SERIAL PRIMARY KEY,
    order_id INT NOT NULL,
    tracking_number VARCHAR(20) UNIQUE NOT NULL,
    delivery_method delivery_method_type DEFAULT 'standard',
    estimated_delivery_date DATE,
    actual_delivery_date TIMESTAMP,
    delivery_address TEXT NOT NULL,
    delivery_instructions TEXT,
    driver_id INT,
    carrier VARCHAR(100) DEFAULT 'In-House',
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    weight_kg DECIMAL(8,2),
    dimensions VARCHAR(50), -- Format: "L x W x H cm"
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- 5. Tracking events table for detailed history
CREATE TABLE tracking_events (
    id SERIAL PRIMARY KEY,
    delivery_id INT NOT NULL,
    status_id INT NOT NULL,
    location VARCHAR(255),
    notes TEXT,
    event_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    FOREIGN KEY (delivery_id) REFERENCES deliveries(id) ON DELETE CASCADE,
    FOREIGN KEY (status_id) REFERENCES delivery_statuses(id)
);

-- 6. Enhance orders table with delivery status
ALTER TABLE orders 
ADD COLUMN delivery_status delivery_status_type DEFAULT 'pending';

-- 5. Create indexes for better performance
CREATE INDEX idx_deliveries_order_id ON deliveries(order_id);
CREATE INDEX idx_deliveries_tracking_number ON deliveries(tracking_number);
CREATE INDEX idx_tracking_events_delivery_id ON tracking_events(delivery_id);
CREATE INDEX idx_tracking_events_timestamp ON tracking_events(event_timestamp);
CREATE INDEX idx_orders_delivery_status ON orders(delivery_status);

-- 6. Create a view for easy tracking information
CREATE VIEW order_tracking_view AS
SELECT 
    o.id as order_id,
    o.user_id,
    o.total_amount,
    o.status as order_status,
    o.delivery_status,
    d.tracking_number,
    d.delivery_method,
    d.estimated_delivery_date,
    d.actual_delivery_date,
    d.carrier,
    ds.status as current_status,
    ds.description as status_description,
    te.location as current_location,
    te.notes as latest_notes,
    te.event_timestamp as last_update
FROM orders o
LEFT JOIN deliveries d ON o.id = d.order_id
LEFT JOIN tracking_events te ON d.id = te.delivery_id
LEFT JOIN delivery_statuses ds ON te.status_id = ds.id
WHERE te.id = (
    SELECT MAX(te2.id) 
    FROM tracking_events te2 
    WHERE te2.delivery_id = d.id
)
OR d.id IS NULL;
