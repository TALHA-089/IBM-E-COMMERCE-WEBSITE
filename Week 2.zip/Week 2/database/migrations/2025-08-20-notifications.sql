-- Notifications System Database Schema
-- Phase 3: Real-time notifications and preferences

-- 1. Notifications table for storing notification history
CREATE TABLE notifications (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    data JSONB,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 2. Add notification preferences to users table
ALTER TABLE users 
ADD COLUMN notification_preferences JSONB DEFAULT '{"email": true, "push": true, "delivery_updates": true, "order_confirmations": true, "promotional": false}';

-- 3. Create indexes for better performance
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);
CREATE INDEX idx_notifications_read_at ON notifications(read_at);

-- 4. Create notification types lookup (optional)
CREATE TABLE notification_types (
    id SERIAL PRIMARY KEY,
    type VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    default_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default notification types
INSERT INTO notification_types (type, description, default_enabled) VALUES
('order_confirmation', 'Order confirmation notifications', true),
('delivery_status_update', 'Delivery status update notifications', true),
('order_shipped', 'Order shipped notifications', true),
('order_delivered', 'Order delivered notifications', true),
('promotional', 'Promotional and marketing notifications', false),
('system_alert', 'System alerts and maintenance notifications', true);
