-- Add tracking number to orders table and update existing orders
-- This migration ensures all orders have tracking information

-- Add tracking number column to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS tracking_number VARCHAR(20) UNIQUE;

-- Create index for tracking number lookups
CREATE INDEX IF NOT EXISTS idx_orders_tracking_number ON orders(tracking_number);

-- Function to generate tracking number
CREATE OR REPLACE FUNCTION generate_tracking_number() 
RETURNS VARCHAR(20) AS $$
DECLARE
    tracking_num VARCHAR(20);
    counter INTEGER := 0;
BEGIN
    LOOP
        -- Generate tracking number: TRK + timestamp + random 4 digits
        tracking_num := 'TRK' || TO_CHAR(NOW(), 'YYYYMMDD') || LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
        
        -- Check if it already exists
        IF NOT EXISTS (SELECT 1 FROM orders WHERE tracking_number = tracking_num) AND
           NOT EXISTS (SELECT 1 FROM deliveries WHERE tracking_number = tracking_num) THEN
            RETURN tracking_num;
        END IF;
        
        counter := counter + 1;
        IF counter > 100 THEN
            RAISE EXCEPTION 'Unable to generate unique tracking number after 100 attempts';
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Update existing orders without tracking numbers
UPDATE orders 
SET tracking_number = generate_tracking_number()
WHERE tracking_number IS NULL;

-- Create delivery records for existing orders that don't have them
INSERT INTO deliveries (
    order_id, 
    tracking_number, 
    delivery_method, 
    estimated_delivery_date,
    delivery_address,
    carrier,
    shipping_cost
)
SELECT 
    o.id,
    o.tracking_number,
    'standard'::delivery_method_type,
    (o.created_at + INTERVAL '5 days')::DATE,
    COALESCE(o.shipping_address->>'address', 'Address not provided'),
    'In-House',
    COALESCE(o.shipping_cost, 9.99)
FROM orders o
LEFT JOIN deliveries d ON o.id = d.order_id
WHERE d.id IS NULL AND o.tracking_number IS NOT NULL;

-- Create initial tracking events for existing orders
INSERT INTO tracking_events (delivery_id, status_id, location, notes, event_timestamp)
SELECT 
    d.id,
    (SELECT id FROM delivery_statuses WHERE status = 'order_confirmed'),
    'Processing Center',
    'Order confirmed and being prepared for shipment',
    o.created_at
FROM orders o
JOIN deliveries d ON o.id = d.order_id
LEFT JOIN tracking_events te ON d.id = te.delivery_id
WHERE te.id IS NULL;

-- Add processing event for orders older than 1 day
INSERT INTO tracking_events (delivery_id, status_id, location, notes, event_timestamp)
SELECT 
    d.id,
    (SELECT id FROM delivery_statuses WHERE status = 'processing'),
    'Warehouse',
    'Order is being processed and packed',
    o.created_at + INTERVAL '4 hours'
FROM orders o
JOIN deliveries d ON o.id = d.order_id
WHERE o.created_at < NOW() - INTERVAL '1 day'
AND NOT EXISTS (
    SELECT 1 FROM tracking_events te2 
    WHERE te2.delivery_id = d.id 
    AND te2.status_id = (SELECT id FROM delivery_statuses WHERE status = 'processing')
);

-- Add shipped event for orders older than 2 days
INSERT INTO tracking_events (delivery_id, status_id, location, notes, event_timestamp)
SELECT 
    d.id,
    (SELECT id FROM delivery_statuses WHERE status = 'shipped'),
    'Distribution Center',
    'Package has been shipped and is in transit',
    o.created_at + INTERVAL '1 day'
FROM orders o
JOIN deliveries d ON o.id = d.order_id
WHERE o.created_at < NOW() - INTERVAL '2 days'
AND NOT EXISTS (
    SELECT 1 FROM tracking_events te2 
    WHERE te2.delivery_id = d.id 
    AND te2.status_id = (SELECT id FROM delivery_statuses WHERE status = 'shipped')
);

-- Update delivery status in orders table based on latest tracking events
UPDATE orders 
SET delivery_status = (
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM deliveries d
            JOIN tracking_events te ON d.id = te.delivery_id
            JOIN delivery_statuses ds ON te.status_id = ds.id
            WHERE d.order_id = orders.id AND ds.status = 'delivered'
        ) THEN 'delivered'::delivery_status_type
        WHEN EXISTS (
            SELECT 1 FROM deliveries d
            JOIN tracking_events te ON d.id = te.delivery_id
            JOIN delivery_statuses ds ON te.status_id = ds.id
            WHERE d.order_id = orders.id AND ds.status = 'shipped'
        ) THEN 'shipped'::delivery_status_type
        WHEN EXISTS (
            SELECT 1 FROM deliveries d
            JOIN tracking_events te ON d.id = te.delivery_id
            JOIN delivery_statuses ds ON te.status_id = ds.id
            WHERE d.order_id = orders.id AND ds.status = 'processing'
        ) THEN 'processing'::delivery_status_type
        ELSE 'pending'::delivery_status_type
    END
)
WHERE delivery_status IS NULL OR delivery_status = 'pending';
