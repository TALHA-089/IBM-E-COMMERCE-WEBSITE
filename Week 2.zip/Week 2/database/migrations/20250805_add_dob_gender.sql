-- Migration: add dob and gender columns
ALTER TABLE additional_user_info
  ADD COLUMN IF NOT EXISTS dob DATE,
  ADD COLUMN IF NOT EXISTS gender CHAR(1);
