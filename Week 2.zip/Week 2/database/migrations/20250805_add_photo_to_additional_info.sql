-- Migration: add photo_base64 column
ALTER TABLE additional_user_info ADD COLUMN IF NOT EXISTS photo_base64 TEXT;
