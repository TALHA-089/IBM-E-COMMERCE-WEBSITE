const pool = require('../database/connection');

/**
 * Additional user information that can be edited by the user (non-admin).
 * Fields are optional and are stored in a separate table linked by user_id.
 * Schema (PostgreSQL):
 *   CREATE TABLE additional_user_info (
 *       id SERIAL PRIMARY KEY,
 *       user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
 *       phone VARCHAR(32),
 *       address TEXT,
 *       bio TEXT,
 *       photo_base64 TEXT,
 *       created_at TIMESTAMPTZ DEFAULT NOW(),
 *       updated_at TIMESTAMPTZ DEFAULT NOW()
 *   );
 */
class AdditionalInfo {
  static async getByUserId(user_id) {
    const { rows } = await pool.query(
      'SELECT user_id, phone, address, bio, photo_base64, dob, gender FROM additional_user_info WHERE user_id = $1',
      [user_id]
    );
    return rows[0] || null;
  }

  /**
   * Insert or update additional info for a user. Performs an UPSERT using ON CONFLICT.
   */
  static async upsert({ user_id, phone, address, bio, photo_base64, dob, gender }) {
    const query = `
      INSERT INTO additional_user_info (user_id, phone, address, bio, photo_base64, dob, gender)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (user_id) DO UPDATE
      SET phone = EXCLUDED.phone,
          address = EXCLUDED.address,
          bio = EXCLUDED.bio,
          photo_base64 = EXCLUDED.photo_base64,
          dob = EXCLUDED.dob,
          gender = EXCLUDED.gender,
          
          updated_at = NOW()
      RETURNING user_id, phone, address, bio, photo_base64, dob, gender`;
    const { rows } = await pool.query(query, [user_id, phone, address, bio, photo_base64, dob, gender]);
    return rows[0];
  }
}

module.exports = AdditionalInfo;
