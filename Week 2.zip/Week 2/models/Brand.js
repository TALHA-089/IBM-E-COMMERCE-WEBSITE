const pool = require('../database/connection');

class Brand {
  // Get all brands with category information
  static async getAll() {
    try {
      const query = `
        SELECT b.*, c.name as category_name 
        FROM brands b 
        JOIN categories c ON b.category_id = c.id 
        ORDER BY b.name
      `;
      const result = await pool.query(query);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching brands: ${error.message}`);
    }
  }

  // Get brand by ID with category information
  static async getById(id) {
    try {
      const query = `
        SELECT b.*, c.name as category_name 
        FROM brands b 
        JOIN categories c ON b.category_id = c.id 
        WHERE b.id = $1
      `;
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching brand: ${error.message}`);
    }
  }

  // Get brands by category ID
  static async getByCategoryId(categoryId) {
    try {
      const query = 'SELECT * FROM brands WHERE category_id = $1 ORDER BY name';
      const result = await pool.query(query, [categoryId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching brands by category: ${error.message}`);
    }
  }

  // Create new brand
  static async create(name, categoryId) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Brand name is required');
      }
      if (!categoryId) {
        throw new Error('Category is required');
      }

      // Check if category exists
      const categoryCheck = await pool.query('SELECT id FROM categories WHERE id = $1', [categoryId]);
      if (categoryCheck.rows.length === 0) {
        throw new Error('Category not found');
      }

      const query = 'INSERT INTO brands (name, category_id) VALUES ($1, $2) RETURNING *';
      const result = await pool.query(query, [name.trim(), categoryId]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') { // Unique violation
        throw new Error('Brand name already exists in this category');
      }
      throw new Error(`Error creating brand: ${error.message}`);
    }
  }

  // Update brand
  static async update(id, name, categoryId) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Brand name is required');
      }
      if (!categoryId) {
        throw new Error('Category is required');
      }

      // Check if category exists
      const categoryCheck = await pool.query('SELECT id FROM categories WHERE id = $1', [categoryId]);
      if (categoryCheck.rows.length === 0) {
        throw new Error('Category not found');
      }

      const query = 'UPDATE brands SET name = $1, category_id = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3 RETURNING *';
      const result = await pool.query(query, [name.trim(), categoryId, id]);
      
      if (result.rows.length === 0) {
        throw new Error('Brand not found');
      }
      
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') { // Unique violation
        throw new Error('Brand name already exists in this category');
      }
      throw new Error(`Error updating brand: ${error.message}`);
    }
  }

  // Delete brand
  static async delete(id) {
    try {
      // Check if brand has associated products
      const checkQuery = 'SELECT COUNT(*) FROM products WHERE brand_id = $1';
      const checkResult = await pool.query(checkQuery, [id]);
      
      if (parseInt(checkResult.rows[0].count) > 0) {
        throw new Error('Cannot delete brand: It has associated products');
      }

      const query = 'DELETE FROM brands WHERE id = $1 RETURNING *';
      const result = await pool.query(query, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Brand not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting brand: ${error.message}`);
    }
  }

  // Get brand with product count
  static async getWithProductCount() {
    try {
      const query = `
        SELECT b.*, c.name as category_name, COUNT(p.id) as product_count 
        FROM brands b 
        JOIN categories c ON b.category_id = c.id 
        LEFT JOIN products p ON b.id = p.brand_id 
        GROUP BY b.id, c.name 
        ORDER BY b.name
      `;
      const result = await pool.query(query);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching brands with product count: ${error.message}`);
    }
  }
}

module.exports = Brand; 