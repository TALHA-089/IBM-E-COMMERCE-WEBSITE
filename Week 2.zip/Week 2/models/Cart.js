const pool = require('../database/connection');

class Cart {
  static async clearByUser(user_id) {
    await pool.query('DELETE FROM cart_items WHERE user_id = $1', [user_id]);
  }
}

module.exports = Cart;
