const pool = require('../database/connection');

class CartItem {
  static async getCartByUser(user_id) {
    const query = `
      SELECT ci.*, p.name as product_name, p.price, p.description, p.brand_id
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = $1
      ORDER BY ci.created_at DESC
    `;
    const result = await pool.query(query, [user_id]);
    return result.rows;
  }

  static async addOrUpdate(user_id, product_id, quantity) {
    const query = `
      INSERT INTO cart_items (user_id, product_id, quantity)
      VALUES ($1, $2, $3)
      ON CONFLICT (user_id, product_id)
      DO UPDATE SET quantity = $3, created_at = CURRENT_TIMESTAMP
      RETURNING *
    `;
    const result = await pool.query(query, [user_id, product_id, quantity]);
    return result.rows[0];
  }

  static async remove(user_id, product_id) {
    const query = `DELETE FROM cart_items WHERE user_id = $1 AND product_id = $2 RETURNING *`;
    const result = await pool.query(query, [user_id, product_id]);
    return result.rows[0];
  }

  static async clearCart(user_id) {
    const query = `DELETE FROM cart_items WHERE user_id = $1`;
    await pool.query(query, [user_id]);
  }

  static async getCount(user_id) {
    const query = `SELECT COUNT(*) FROM cart_items WHERE user_id = $1`;
    const result = await pool.query(query, [user_id]);
    return result.rows[0].count;
  }
}

module.exports = CartItem; 