const pool = require('../database/connection');

class Category {
  // Get all categories
  static async getAll() {
    try {
      const query = 'SELECT * FROM categories ORDER BY name';
      const result = await pool.query(query);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching categories: ${error.message}`);
    }
  }

  // Get category by ID
  static async getById(id) {
    try {
      const query = 'SELECT * FROM categories WHERE id = $1';
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching category: ${error.message}`);
    }
  }

  // Create new category
  static async create(name) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Category name is required');
      }

      const query = 'INSERT INTO categories (name) VALUES ($1) RETURNING *';
      const result = await pool.query(query, [name.trim()]);
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') { // Unique violation
        throw new Error('Category name already exists');
      }
      throw new Error(`Error creating category: ${error.message}`);
    }
  }

  // Update category
  static async update(id, name) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Category name is required');
      }

      const query = 'UPDATE categories SET name = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *';
      const result = await pool.query(query, [name.trim(), id]);
      
      if (result.rows.length === 0) {
        throw new Error('Category not found');
      }
      
      return result.rows[0];
    } catch (error) {
      if (error.code === '23505') { // Unique violation
        throw new Error('Category name already exists');
      }
      throw new Error(`Error updating category: ${error.message}`);
    }
  }

  // Delete category
  static async delete(id) {
    try {
      // Check if category has associated brands
      const checkQuery = 'SELECT COUNT(*) FROM brands WHERE category_id = $1';
      const checkResult = await pool.query(checkQuery, [id]);
      
      if (parseInt(checkResult.rows[0].count) > 0) {
        throw new Error('Cannot delete category: It has associated brands');
      }

      const query = 'DELETE FROM categories WHERE id = $1 RETURNING *';
      const result = await pool.query(query, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Category not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting category: ${error.message}`);
    }
  }

  // Get category with brand count
  static async getWithBrandCount() {
    try {
      const query = `
        SELECT c.*, COUNT(b.id) as brand_count 
        FROM categories c 
        LEFT JOIN brands b ON c.id = b.category_id 
        GROUP BY c.id 
        ORDER BY c.name
      `;
      const result = await pool.query(query);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching categories with brand count: ${error.message}`);
    }
  }
}

module.exports = Category; 