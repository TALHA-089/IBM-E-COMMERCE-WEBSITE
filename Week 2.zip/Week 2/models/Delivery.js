const pool = require('../database/connection');

class Delivery {
    // Create a new delivery record
    static async create(deliveryData) {
        const {
            order_id,
            delivery_method = 'standard',
            delivery_address,
            delivery_instructions = '',
            estimated_delivery_date,
            weight_kg = 0,
            dimensions = '',
            shipping_cost = 0
        } = deliveryData;

        // Generate unique tracking number
        const tracking_number = this.generateTrackingNumber();

        const query = `
            INSERT INTO deliveries (
                order_id, tracking_number, delivery_method, delivery_address,
                delivery_instructions, estimated_delivery_date, weight_kg,
                dimensions, shipping_cost
            ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id
        `;

        try {
            const result = await pool.query(query,[
                order_id, tracking_number, delivery_method, delivery_address,
                delivery_instructions, estimated_delivery_date, weight_kg,
                dimensions, shipping_cost
            ]);
            const deliveryId = result.rows[0].id;
            // initial tracking event
            await this.addTrackingEvent(deliveryId, 1, 'Warehouse', 'Order confirmed and ready for processing');
            return { id: deliveryId, tracking_number };
        } catch (error) {
            throw new Error(`Failed to create delivery: ${error.message}`);
        }
    }

    // Generate unique tracking number
    static generateTrackingNumber() {
        const prefix = 'TRK';
        const timestamp = Date.now().toString().slice(-8);
        const random = Math.random().toString(36).substr(2, 4).toUpperCase();
        return `${prefix}${timestamp}${random}`;
    }

    // Add tracking event
    static async addTrackingEvent(delivery_id, status_id, location = '', notes = '', created_by = 'system') {
        const query = `
            INSERT INTO tracking_events (delivery_id, status_id, location, notes, created_by)
            VALUES ($1,$2,$3,$4,$5)`;

        try {
            await pool.query(query,[delivery_id,status_id,location,notes,created_by]);
            
            // Update order delivery status based on the new tracking event
            await this.updateOrderDeliveryStatus(delivery_id, status_id);
            
            return true;
        } catch (error) {
            throw new Error(`Failed to add tracking event: ${error.message}`);
        }
    }

    // Update order delivery status
    static async updateOrderDeliveryStatus(delivery_id, status_id) {
        const statusMapping = {
            1: 'pending',      // order_confirmed
            2: 'processing',   // processing
            3: 'shipped',      // shipped
            4: 'out_for_delivery', // out_for_delivery
            5: 'delivered',    // delivered
            6: 'failed_delivery', // failed_delivery
            7: 'returned'      // returned
        };

        const delivery_status = statusMapping[status_id] || 'pending';

        const query = `
            UPDATE orders
            SET delivery_status = $1
            WHERE id = (SELECT order_id FROM deliveries WHERE id = $2)`;
        await pool.query(query,[delivery_status,delivery_id]);
    }

    // Get delivery by tracking number
    static async getByTrackingNumber(tracking_number) {
        const query = `
            SELECT d.*, o.user_id, o.total_amount, o.status as order_status
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE d.tracking_number = $1`;


        try {
            const result = await pool.query(query,[tracking_number]);
            return result.rows[0] || null;
        } catch (error) {
            throw new Error(`Failed to get delivery: ${error.message}`);
        }
    }

    // Get delivery by order ID
    static async getByOrderId(order_id) {
        const query = `SELECT * FROM deliveries WHERE order_id = $1`;

        try {
            const result = await pool.query(query,[order_id]);
            return result.rows[0] || null;
        } catch (error) {
            throw new Error(`Failed to get delivery: ${error.message}`);
        }
    }

    // Get tracking history
    static async getTrackingHistory(tracking_number) {
        const query = `
            SELECT 
                te.id,
                ds.status,
                ds.description,
                te.location,
                te.notes,
                te.event_timestamp,
                te.created_by
            FROM tracking_events te
            JOIN deliveries d ON te.delivery_id = d.id
            JOIN delivery_statuses ds ON te.status_id = ds.id
            WHERE d.tracking_number=$1
            ORDER BY te.event_timestamp ASC
        `;

        try {
            const result = await pool.query(query,[tracking_number]);
            return result.rows;
        } catch (error) {
            throw new Error(`Failed to get tracking history: ${error.message}`);
        }
    }

    // Get full tracking information
    static async getFullTrackingInfo(tracking_number) {
        try {
            const delivery = await this.getByTrackingNumber(tracking_number);
            if (!delivery) {
                return null;
            }

            const trackingHistory = await this.getTrackingHistory(tracking_number);
            
            return {
                delivery,
                tracking_history: trackingHistory,
                current_status: trackingHistory[trackingHistory.length - 1] || null
            };
        } catch (error) {
            throw new Error(`Failed to get full tracking info: ${error.message}`);
        }
    }

    // Update delivery status
    static async updateStatus(delivery_id, status_id, location = '', notes = '', created_by = 'system') {
        try {
            await this.addTrackingEvent(delivery_id, status_id, location, notes, created_by);
            
            // If delivered, update actual delivery date
            if (status_id === 5) { // delivered status
                const query = `UPDATE deliveries SET actual_delivery_date = NOW() WHERE id = $1`;
                await pool.query(query,[delivery_id]);
            }
            
            return true;
        } catch (error) {
            throw new Error(`Failed to update delivery status: ${error.message}`);
        }
    }

    // Get all delivery statuses
    static async getDeliveryStatuses() {
        const query = `SELECT * FROM delivery_statuses ORDER BY sort_order`;
        
        try {
            const result = await pool.query(query);
            const rows = result.rows;
            return rows;
        } catch (error) {
            throw new Error(`Failed to get delivery statuses: ${error.message}`);
        }
    }

    // Get deliveries for a user
    static async getByUserId(user_id) {
        const query = `SELECT d.*, o.total_amount, o.status as order_status
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE o.user_id = $1
            ORDER BY d.created_at DESC`;

        try {
            const result = await pool.query(query,[user_id]);
            return result.rows;
        } catch (error) {
            throw new Error(`Failed to get user deliveries: ${error.message}`);
        }
    }

    // Get delivery by ID
    static async getById(delivery_id) {
        const query = `SELECT * FROM deliveries WHERE id = $1`;
        
        try {
            const result = await pool.query(query, [delivery_id]);
            return result.rows[0] || null;
        } catch (error) {
            throw new Error(`Failed to get delivery by ID: ${error.message}`);
        }
    }
}

module.exports = Delivery;
