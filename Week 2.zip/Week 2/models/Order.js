const pool = require('../database/connection');

class Order {
  static async create(orderData) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      
      // Generate tracking number
      const trackingRes = await client.query('SELECT generate_tracking_number() as tracking_number');
      const trackingNumber = trackingRes.rows[0].tracking_number;
      
      // Verify stock availability for all items
      for (const item of orderData.items) {
        const stockRes = await client.query('SELECT stock FROM products WHERE id = $1 FOR UPDATE', [item.product_id]);
        if (stockRes.rows.length === 0) {
          throw new Error('Product not found');
        }
        const currentStock = parseInt(stockRes.rows[0].stock);
        if (currentStock < item.quantity) {
          throw new Error('Insufficient stock for one or more items');
        }
      }
      
      const insertOrderText = `
        INSERT INTO orders (user_id, total_amount, shipping_address, payment_method, subtotal, shipping_cost, tax_amount, status, tracking_number, delivery_status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`;
      const orderRes = await client.query(insertOrderText, [
        orderData.user_id,
        orderData.total_amount,
        orderData.shipping_address ? JSON.stringify(orderData.shipping_address) : null,
        orderData.payment_method,
        orderData.subtotal,
        orderData.shipping_cost,
        orderData.tax_amount,
        orderData.status || 'pending',
        trackingNumber,
        'pending'
      ]);
      const order = orderRes.rows[0];
      
      // Create delivery record
      const deliveryAddress = orderData.shipping_address ? 
        `${orderData.shipping_address.address || ''}, ${orderData.shipping_address.city || ''}, ${orderData.shipping_address.state || ''} ${orderData.shipping_address.zipCode || ''}`.trim() :
        'Address not provided';
        
      const deliveryRes = await client.query(`
        INSERT INTO deliveries (order_id, tracking_number, delivery_method, estimated_delivery_date, delivery_address, carrier, shipping_cost)
        VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
        [
          order.id,
          trackingNumber,
          'standard',
          new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
          deliveryAddress,
          'In-House',
          orderData.shipping_cost || 9.99
        ]
      );
      const delivery = deliveryRes.rows[0];
      
      // Create initial tracking event
      await client.query(`
        INSERT INTO tracking_events (delivery_id, status_id, location, notes, event_timestamp)
        VALUES ($1, (SELECT id FROM delivery_statuses WHERE status = 'order_confirmed'), $2, $3, CURRENT_TIMESTAMP)`,
        [delivery.id, 'Processing Center', 'Order confirmed and being prepared for shipment']
      );
      
      for (const item of orderData.items) {
        // deduct stock
        await client.query('UPDATE products SET stock = stock - $2 WHERE id = $1', [item.product_id, item.quantity]);
        await client.query(
          `INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1, $2, $3, $4)`,
          [order.id, item.product_id, item.quantity, item.price]
        );
      }
      
      await client.query('COMMIT');
      return order;
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
  }

  static async getByUser(user_id) {
    const ordersQuery = `
      SELECT o.*, d.tracking_number, d.estimated_delivery_date, d.delivery_method 
      FROM orders o 
      LEFT JOIN deliveries d ON o.id = d.order_id 
      WHERE o.user_id = $1 
      ORDER BY o.created_at DESC`;
    const ordersResult = await pool.query(ordersQuery, [user_id]);
    
    // Get items for each order
    const orders = [];
    for (const order of ordersResult.rows) {
      const itemsQuery = `
        SELECT oi.*, p.name as product_name, p.image_url, p.brand_id,
               b.name as brand_name
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.id 
        LEFT JOIN brands b ON p.brand_id = b.id
        WHERE oi.order_id = $1
      `;
      const itemsResult = await pool.query(itemsQuery, [order.id]);
      orders.push({ ...order, items: itemsResult.rows });
    }
    
    return orders;
  }

  static async getAll() {
    const ordersQuery = `SELECT o.*, u.name as user_name, u.email FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC`;
    const ordersResult = await pool.query(ordersQuery);
    const orders=[];
    for(const order of ordersResult.rows){
      const itemsRes = await pool.query(`SELECT oi.*, p.name as product_name FROM order_items oi JOIN products p ON oi.product_id=p.id WHERE oi.order_id=$1`,[order.id]);
      orders.push({...order, items: itemsRes.rows});
    }
    return orders;
  }

  static async findById(order_id){
    const res = await pool.query(`SELECT * FROM orders WHERE id = $1`,[order_id]);
    return res.rows[0] || null;
  }

  static async getById(order_id) {
    const orderRes = await pool.query(`SELECT * FROM orders WHERE id = $1`, [order_id]);
    if (!orderRes.rows.length) {
      return null;
    }
    const itemsRes = await pool.query(`SELECT * FROM order_items WHERE order_id = $1`, [order_id]);
    return { ...orderRes.rows[0], items: itemsRes.rows };
  }

  static async getStats() {
    const query = `
      SELECT COUNT(*) as total_orders,
             COALESCE(SUM(total_amount),0) as total_revenue,
             COALESCE(SUM(CASE WHEN DATE_TRUNC('month', created_at) = DATE_TRUNC('month', CURRENT_DATE) THEN total_amount ELSE 0 END),0) as revenue_this_month
      FROM orders
    `;
    const result = await pool.query(query);
    return result.rows[0];
  }

  static async updateStatus(order_id, status) {
    const query = `UPDATE orders SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`;
    const result = await pool.query(query, [status, order_id]);
    return result.rows[0];
  }

  static async updateDeliveryStatus(order_id, delivery_status) {
    const query = `UPDATE orders SET delivery_status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING *`;
    const result = await pool.query(query, [delivery_status, order_id]);
    return result.rows[0];
  }
}

module.exports = Order; 