const pool = require('../database/connection');

class OrderItem {
  static async getByOrderId(order_id) {
    const query = `
      SELECT oi.*, p.name as product_name, p.price as product_price
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = $1
    `;
    const result = await pool.query(query, [order_id]);
    return result.rows;
  }

  static async getTopSellingProducts(limit = 5) {
    const query = `
      SELECT p.id, p.name, SUM(oi.quantity) as total_sold
      FROM order_items oi
      JOIN products p ON oi.product_id = p.id
      GROUP BY p.id, p.name
      ORDER BY total_sold DESC
      LIMIT $1
    `;
    const result = await pool.query(query, [limit]);
    return result.rows;
  }
}

module.exports = OrderItem; 