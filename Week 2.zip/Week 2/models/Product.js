const pool = require('../database/connection');

class Product {
  // Get all products with brand and category information
  static async getAll() {
    try {
      const query = `
        SELECT p.*, b.name as brand_name, c.name as category_name, c.id as category_id
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        ORDER BY p.created_at DESC
      `;
      const result = await pool.query(query);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching products: ${error.message}`);
    }
  }

  // Get product by ID
  static async getById(id) {
    try {
      const query = `
        SELECT p.*, b.name as brand_name, c.name as category_name, c.id as category_id
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE p.id = $1
      `;
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error fetching product: ${error.message}`);
    }
  }

  // Get products by brand ID
  static async getByBrandId(brandId) {
    try {
      const query = `
        SELECT p.*, b.name as brand_name, c.name as category_name, c.id as category_id
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE p.brand_id = $1
        ORDER BY p.created_at DESC
      `;
      const result = await pool.query(query, [brandId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching products by brand: ${error.message}`);
    }
  }

  // Get products by category ID
  static async getByCategoryId(categoryId) {
    try {
      const query = `
        SELECT p.*, b.name as brand_name, c.name as category_name, c.id as category_id
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE c.id = $1
        ORDER BY p.created_at DESC
      `;
      const result = await pool.query(query, [categoryId]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error fetching products by category: ${error.message}`);
    }
  }

  // Create new product (with optional image_url)
  static async create(name, brandId, price, stock, description, imageUrl = null) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Product name is required');
      }
      if (!brandId) {
        throw new Error('Brand is required');
      }
      if (!price || price <= 0) {
        throw new Error('Price must be greater than 0');
      }
      if (stock == null || stock < 0) {
        throw new Error('Stock must be 0 or greater');
      }

      // Check if brand exists
      const brandCheck = await pool.query('SELECT id FROM brands WHERE id = $1', [brandId]);
      if (brandCheck.rows.length === 0) {
        throw new Error('Brand not found');
      }

      const query = 'INSERT INTO products (name, brand_id, price, stock, description, image_url) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *';
      const result = await pool.query(query, [name.trim(), brandId, price, stock, description || null, imageUrl]);
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error creating product: ${error.message}`);
    }
  }

  // Update product
  static async update(id, name, brandId, price, stock, description, imageUrl = null) {
    try {
      // Validate input
      if (!name || name.trim().length === 0) {
        throw new Error('Product name is required');
      }
      if (!brandId) {
        throw new Error('Brand is required');
      }
      if (!price || price <= 0) {
        throw new Error('Price must be greater than 0');
      }
      if (stock == null || stock < 0) {
        throw new Error('Stock must be 0 or greater');
      }

      // Check if brand exists
      const brandCheck = await pool.query('SELECT id FROM brands WHERE id = $1', [brandId]);
      if (brandCheck.rows.length === 0) {
        throw new Error('Brand not found');
      }

      const query = 'UPDATE products SET name = $1, brand_id = $2, price = $3, stock=$4, description = $5, image_url = $6, updated_at = CURRENT_TIMESTAMP WHERE id = $7 RETURNING *';
      const result = await pool.query(query, [name.trim(), brandId, price, stock, description || null, imageUrl, id]);
      
      if (result.rows.length === 0) {
        throw new Error('Product not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error updating product: ${error.message}`);
    }
  }

  // Delete product
  static async delete(id) {
    try {
      const query = 'DELETE FROM products WHERE id = $1 RETURNING *';
      const result = await pool.query(query, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Product not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Error deleting product: ${error.message}`);
    }
  }

  // Search products
  static async search(searchTerm) {
    try {
      const query = `
        SELECT p.*, b.name as brand_name, c.name as category_name, c.id as category_id
        FROM products p
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE p.name ILIKE $1 OR p.description ILIKE $1 OR b.name ILIKE $1 OR c.name ILIKE $1
        ORDER BY p.created_at DESC
      `;
      const result = await pool.query(query, [`%${searchTerm}%`]);
      return result.rows;
    } catch (error) {
      throw new Error(`Error searching products: ${error.message}`);
    }
  }

  // Get product statistics
  static async getStats() {
    try {
      const statsQuery = 'SELECT COUNT(*) as total_products, AVG(price) as avg_price FROM products';
      const statsResult = await pool.query(statsQuery);
      
      const categoryQuery = `
        SELECT c.name, COUNT(p.id) as count
        FROM categories c
        LEFT JOIN brands b ON c.id = b.category_id
        LEFT JOIN products p ON b.id = p.brand_id
        GROUP BY c.id, c.name
        ORDER BY count DESC
      `;
      const categoryResult = await pool.query(categoryQuery);
      
      return {
        total_products: parseInt(statsResult.rows[0].total_products),
        avg_price: statsResult.rows[0].avg_price,
        byCategory: categoryResult.rows
      };
    } catch (error) {
      throw new Error(`Error fetching product statistics: ${error.message}`);
    }
  }
}

module.exports = Product;
