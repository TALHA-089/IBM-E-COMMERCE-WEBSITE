const pool = require('../database/connection');

class Review {
  static async getByProduct(product_id) {
    const query = `
      SELECT r.*, u.name as user_name
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.product_id = $1
      ORDER BY r.created_at DESC
    `;
    const result = await pool.query(query, [product_id]);
    return result.rows;
  }

  static async getByUser(user_id) {
    const query = `
      SELECT r.*, p.name as product_name
      FROM reviews r
      JOIN products p ON r.product_id = p.id
      WHERE r.user_id = $1
      ORDER BY r.created_at DESC
    `;
    const result = await pool.query(query, [user_id]);
    return result.rows;
  }

  static async addOrUpdate(user_id, product_id, rating, comment) {
    const query = `
      INSERT INTO reviews (user_id, product_id, rating, comment)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (user_id, product_id)
      DO UPDATE SET rating = $3, comment = $4, created_at = CURRENT_TIMESTAMP
      RETURNING *
    `;
    const result = await pool.query(query, [user_id, product_id, rating, comment]);
    return result.rows[0];
  }

  static async delete(user_id, product_id) {
    const query = `DELETE FROM reviews WHERE user_id = $1 AND product_id = $2 RETURNING *`;
    const result = await pool.query(query, [user_id, product_id]);
    return result.rows[0];
  }

  static async getAverageRating(product_id) {
    const query = `SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM reviews WHERE product_id = $1`;
    const result = await pool.query(query, [product_id]);
    return result.rows[0];
  }
}

module.exports = Review; 