const pool = require('../database/connection');
const bcrypt = require('bcryptjs');

class User {
  static async create({ name, email, password, role = 'user', verification_token }) {
    const password_hash = await bcrypt.hash(password, 10);
    const query = `
      INSERT INTO users (name, email, password_hash, role, is_verified, verification_token)
      VALUES ($1, $2, $3, $4, false, $5)
      RETURNING *`;
    const result = await pool.query(query, [name, email, password_hash, role, verification_token]);
    return result.rows[0];
  }

  static async findByEmail(email) {
    const query = `SELECT * FROM users WHERE email = $1`;
    const result = await pool.query(query, [email]);
    return result.rows[0];
  }

  static async findById(id) {
    const query = `SELECT * FROM users WHERE id = $1`;
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async comparePassword(password, hash) {
    return bcrypt.compare(password, hash);
  }

  static async getAll() {
    const query = `SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC`;
    const result = await pool.query(query);
    return result.rows;
  }

  static async verifyEmail(token, email) {
    const query = `SELECT * FROM users WHERE email = $1`;
    const result = await pool.query(query, [email]);
    const user = result.rows[0];
    if (!user || user.verification_token !== token || user.is_verified) return null;
    await pool.query(`UPDATE users SET is_verified = true, verification_token = NULL WHERE id = $1`, [user.id]);
    return user;
  }

  static async getStats() {
    const query = `SELECT COUNT(*) as total_users FROM users`;
    const result = await pool.query(query);
    return result.rows[0];
  }
}

module.exports = User; 