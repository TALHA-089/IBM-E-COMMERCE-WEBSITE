// adminDashboard.js
// Handles admin-only dashboard stats, charts, etc.
import { getUser, getAccessToken, logout } from './auth.js';
import { safeDestroyChart, createChart } from './utils/chartUtils.js';

const user = getUser();
if (!(user && user.role === 'admin')) {
  // Guard: non-admins shouldn't run this module
  console.warn('adminDashboard imported for non-admin user, aborting.');
} else if (window.adminDashboardInitialized) {
  // Prevent multiple initialization
  console.log('adminDashboard already initialized, skipping.');
} else {
  window.adminDashboardInitialized = true;

// expose logout for navbar link (navbar HTML already sets window.logout)
window.logout = logout;

const token = getAccessToken();

async function fetchStats() {
  try {
    const [userStatsRes, orderStatsRes] = await Promise.all([
      fetch('/api/users/stats', { headers: { Authorization: 'Bearer ' + token } }),
      fetch('/api/orders/stats', { headers: { Authorization: 'Bearer ' + token } })
    ]);
    const userStats = await userStatsRes.json();
    const orderStats = await orderStatsRes.json();
    if (userStats.success && orderStats.success) {
      renderStats(userStats.stats, orderStats.stats);
    } else {
      showToast('Failed to load stats.', 'danger');
    }
  } catch (err) {
    console.error(err);
    showToast('Error loading stats', 'danger');
  }
}

function renderStats(userStats, orderStats) {
  const adminStatsEl = document.getElementById('adminStats');
  if (!adminStatsEl) return;
  adminStatsEl.innerHTML = `
        <div class='col-md-3 mb-3'><div class='card bg-primary text-white'><div class='card-body'><h4>${userStats.total_users}</h4><p class='mb-0'>Total Users</p></div></div></div>
        <div class='col-md-3 mb-3'><div class='card bg-success text-white'><div class='card-body'><h4>${orderStats.total_orders}</h4><p class='mb-0'>Total Orders</p></div></div></div>
        <div class='col-md-3 mb-3'><div class='card bg-warning text-white'><div class='card-body'><h4>$${parseFloat(orderStats.revenue_this_month).toFixed(2)}</h4><p class='mb-0'>Revenue This Month</p></div></div></div>
        <div class='col-md-3 mb-3'><div class='card bg-info text-white'><div class='card-body'><h4>$${parseFloat(orderStats.total_revenue).toFixed(2)}</h4><p class='mb-0'>Total Revenue</p></div></div></div>
      `;
  const quickEl = document.getElementById('quickStats');
  if (quickEl) {
    quickEl.innerHTML = `
        <div><strong>Users:</strong> ${userStats.total_users}</div>
        <div><strong>Orders:</strong> ${orderStats.total_orders}</div>
        <div><strong>Revenue (Month):</strong> $${parseFloat(orderStats.revenue_this_month).toFixed(2)}</div>
        <div><strong>Total Revenue:</strong> $${parseFloat(orderStats.total_revenue).toFixed(2)}</div>
      `;
  }
}

async function fetchTopProducts() {
  try {
    const res = await fetch('/api/orders/all', { headers: { Authorization: 'Bearer ' + token } });
    const data = await res.json();
    if (data.success) {
      const productMap = {};
      data.orders.forEach(order => {
        (order.items || []).forEach(item => {
          productMap[item.product_name] = (productMap[item.product_name] || 0) + item.quantity;
        });
      });
      const topProducts = Object.entries(productMap)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5);
      renderTopProducts(topProducts);
    } else {
      showToast('Failed to load top products.', 'danger');
    }
  } catch (err) {
    console.error(err);
    showToast('Error loading top products', 'danger');
  }
}

// Initialize chart reference
let topProductsChart = null;

function renderTopProducts(topProducts) {
  const canvas = document.getElementById('topProductsChart');
  if (!canvas) return;
  
  // Safely destroy existing chart if it exists
  topProductsChart = safeDestroyChart(topProductsChart);
  
  // Create new chart instance with error handling
  topProductsChart = createChart(canvas, {
    type: 'bar',
    data: {
      labels: topProducts.map(p => p[0]),
      datasets: [{ label: 'Units Sold', data: topProducts.map(p => p[1]), backgroundColor: '#667eea' }]
    },
    options: { responsive: true, plugins: { legend: { display: false } } }
  });
  const listEl = document.getElementById('topProductsList');
  if (listEl) {
    listEl.innerHTML = topProducts
      .map(p => `<li class='list-group-item d-flex justify-content-between align-items-center'>${p[0]}<span class='badge bg-primary'>${p[1]}</span></li>`) // prettier-ignore
      .join('');
  }
}

function showToast(message, type) {
  const toastContainer = document.getElementById('toastContainer');
  if (!toastContainer) return;
  toastContainer.innerHTML = `<div class='alert alert-${type} alert-dismissible fade show mt-3' role='alert'>${message}<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>`;
  setTimeout(() => {
    toastContainer.innerHTML = '';
  }, 4000);
}

// Kick off initial loads
fetchStats();
fetchTopProducts();
}
