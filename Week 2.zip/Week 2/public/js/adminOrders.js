// Admin Orders Management JavaScript
import { getAccessToken, isLoggedIn, authFetch } from './auth.js';

// Check authentication and admin role
if (!isLoggedIn()) {
    window.location.href = 'login.html';
}

// Global variables
let allOrders = [];
let filteredOrders = [];
let socket = null;

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
    await loadUserInfo();
    await loadOrderStats();
    await loadOrders();
    setupEventListeners();
    initializeWebSocket();
    
    // Auto-refresh every 30 seconds
    setInterval(refreshOrders, 30000);
});

// Load user info for navbar
async function loadUserInfo() {
    try {
        const { getUser } = await import('./auth.js');
        const navbarUser = document.getElementById('navbarUser');
        const user = getUser();
        
        if (user) {
            navbarUser.innerHTML = `
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i>${user.name}
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#" onclick="logout()">Logout</a></li>
                    </ul>
                </li>
            `;
        }
    } catch (error) {
        console.error('Error loading user info:', error);
    }
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    document.getElementById('searchInput').addEventListener('input', debounce(filterOrders, 300));
    
    // Filter selects
    document.getElementById('statusFilter').addEventListener('change', filterOrders);
    document.getElementById('dateFilter').addEventListener('change', filterOrders);
}

// Initialize WebSocket for real-time updates
function initializeWebSocket() {
    socket = io();
    
    socket.on('connect', () => {
        console.log('Connected to admin notification server');
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
            socket.emit('join_user_room', user.id);
        }
    });
    
    socket.on('orderStatusUpdate', (data) => {
        console.log('Order status update received:', data);
        showToast(`Order #${data.order_id} status updated to: ${data.status}`, 'info');
        refreshOrders();
    });
    
    socket.on('newOrder', (data) => {
        console.log('New order received:', data);
        showToast(`New order #${data.order_id} received!`, 'success');
        refreshOrders();
    });
}

// Load order statistics
async function loadOrderStats() {
    try {
        const response = await authFetch('/api/orders/stats');
        const data = await response.json();
        
        if (data.success) {
            // Get detailed stats
            const ordersResponse = await authFetch('/api/orders/all');
            const ordersData = await ordersResponse.json();
            
            if (ordersData.success) {
                const orders = ordersData.orders;
                const stats = {
                    total: orders.length,
                    pending: orders.filter(o => o.delivery_status === 'pending').length,
                    shipped: orders.filter(o => o.delivery_status === 'shipped').length,
                    delivered: orders.filter(o => o.delivery_status === 'delivered').length
                };
                
                document.getElementById('totalOrders').textContent = stats.total;
                document.getElementById('pendingOrders').textContent = stats.pending;
                document.getElementById('shippedOrders').textContent = stats.shipped;
                document.getElementById('deliveredOrders').textContent = stats.delivered;
            }
        }
    } catch (error) {
        console.error('Error loading order stats:', error);
    }
}

// Load orders
async function loadOrders() {
    showLoading(true);
    
    try {
        const response = await authFetch('/api/orders/all');
        const data = await response.json();
        
        if (data.success) {
            allOrders = data.orders;
            filteredOrders = [...allOrders];
            renderOrders();
        } else {
            showToast('Failed to load orders', 'danger');
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        showToast('Error loading orders', 'danger');
    } finally {
        showLoading(false);
    }
}

// Filter orders
function filterOrders() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const dateFilter = document.getElementById('dateFilter').value;
    
    filteredOrders = allOrders.filter(order => {
        // Search filter
        const searchMatch = !searchTerm || 
            order.id.toString().includes(searchTerm) ||
            order.user_name?.toLowerCase().includes(searchTerm) ||
            order.tracking_number?.toLowerCase().includes(searchTerm) ||
            order.email?.toLowerCase().includes(searchTerm);
        
        // Status filter
        const statusMatch = !statusFilter || order.delivery_status === statusFilter;
        
        // Date filter
        let dateMatch = true;
        if (dateFilter) {
            const orderDate = new Date(order.created_at);
            const now = new Date();
            
            switch (dateFilter) {
                case 'today':
                    dateMatch = orderDate.toDateString() === now.toDateString();
                    break;
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    dateMatch = orderDate >= weekAgo;
                    break;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    dateMatch = orderDate >= monthAgo;
                    break;
            }
        }
        
        return searchMatch && statusMatch && dateMatch;
    });
    
    renderOrders();
}

// Render orders
function renderOrders() {
    const container = document.getElementById('ordersContainer');
    const noOrders = document.getElementById('noOrders');
    
    if (filteredOrders.length === 0) {
        container.innerHTML = '';
        noOrders.classList.remove('d-none');
        return;
    }
    
    noOrders.classList.add('d-none');
    
    const ordersHtml = filteredOrders.map(order => {
        const statusClass = `status-${order.delivery_status || 'pending'}`;
        const statusBadge = getStatusBadge(order.delivery_status || 'pending');
        const orderDate = new Date(order.created_at).toLocaleDateString();
        const orderTime = new Date(order.created_at).toLocaleTimeString();
        
        return `
            <div class="card order-card ${statusClass} mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-2">
                            <h6 class="mb-1">Order #${order.id}</h6>
                            <small class="text-muted">${orderDate}<br>${orderTime}</small>
                        </div>
                        <div class="col-md-2">
                            <strong>${order.user_name || 'Unknown'}</strong>
                            <br><small class="text-muted">${order.email || ''}</small>
                        </div>
                        <div class="col-md-2">
                            <span class="font-monospace small">${order.tracking_number || 'Not assigned'}</span>
                        </div>
                        <div class="col-md-2">
                            <h6 class="mb-0">$${parseFloat(order.total_amount).toFixed(2)}</h6>
                            <small class="text-muted">${order.items?.length || 0} items</small>
                        </div>
                        <div class="col-md-2">
                            ${statusBadge}
                        </div>
                        <div class="col-md-2">
                            <div class="quick-actions">
                                <button class="btn btn-sm btn-outline-primary" onclick="viewOrderDetails(${order.id})" title="View Details">
                                    <i class="bi bi-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-success" onclick="updateStatusModal(${order.id})" title="Update Status">
                                    <i class="bi bi-arrow-up-circle"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-info" onclick="trackOrder('${order.tracking_number}')" title="Track">
                                    <i class="bi bi-geo-alt"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    container.innerHTML = ordersHtml;
}

// Get status badge HTML
function getStatusBadge(status) {
    const badges = {
        'pending': '<span class="badge bg-warning status-badge">Pending</span>',
        'processing': '<span class="badge bg-info status-badge">Processing</span>',
        'shipped': '<span class="badge bg-primary status-badge">Shipped</span>',
        'out_for_delivery': '<span class="badge bg-warning status-badge">Out for Delivery</span>',
        'delivered': '<span class="badge bg-success status-badge">Delivered</span>',
        'failed_delivery': '<span class="badge bg-danger status-badge">Failed</span>',
        'returned': '<span class="badge bg-secondary status-badge">Returned</span>'
    };
    return badges[status] || badges['pending'];
}

// View order details
async function viewOrderDetails(orderId) {
    try {
        const response = await authFetch(`/api/orders/${orderId}`);
        const data = await response.json();
        
        if (data.success) {
            const order = data.order;
            const trackingResponse = await authFetch(`/api/deliveries/order/${orderId}/tracking`);
            const trackingData = await trackingResponse.json();
            
            let trackingHistory = [];
            if (trackingData.success) {
                trackingHistory = trackingData.data.tracking_history || [];
            }
            
            const modalContent = `
                <div class="row">
                    <div class="col-md-6">
                        <h6>Order Information</h6>
                        <table class="table table-sm">
                            <tr><td><strong>Order ID:</strong></td><td>#${order.id}</td></tr>
                            <tr><td><strong>Customer:</strong></td><td>${order.user_name || 'Unknown'}</td></tr>
                            <tr><td><strong>Email:</strong></td><td>${order.email || 'N/A'}</td></tr>
                            <tr><td><strong>Total:</strong></td><td>$${parseFloat(order.total_amount).toFixed(2)}</td></tr>
                            <tr><td><strong>Status:</strong></td><td>${getStatusBadge(order.delivery_status)}</td></tr>
                            <tr><td><strong>Tracking:</strong></td><td class="font-monospace">${order.tracking_number || 'Not assigned'}</td></tr>
                            <tr><td><strong>Created:</strong></td><td>${new Date(order.created_at).toLocaleString()}</td></tr>
                        </table>
                        
                        <h6 class="mt-4">Order Items</h6>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${order.items?.map(item => `
                                        <tr>
                                            <td>${item.product_name}</td>
                                            <td>${item.quantity}</td>
                                            <td>$${parseFloat(item.price).toFixed(2)}</td>
                                            <td>$${(parseFloat(item.price) * item.quantity).toFixed(2)}</td>
                                        </tr>
                                    `).join('') || '<tr><td colspan="4">No items found</td></tr>'}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6>Tracking History</h6>
                        <div class="timeline">
                            ${trackingHistory.length > 0 ? trackingHistory.map((event, index) => `
                                <div class="timeline-item ${index === 0 ? 'active' : ''}">
                                    <div class="d-flex justify-content-between">
                                        <strong>${event.description}</strong>
                                        <small class="text-muted">${new Date(event.event_timestamp).toLocaleString()}</small>
                                    </div>
                                    ${event.location ? `<div class="text-muted small">📍 ${event.location}</div>` : ''}
                                    ${event.notes ? `<div class="text-muted small">${event.notes}</div>` : ''}
                                </div>
                            `).join('') : '<p class="text-muted">No tracking events yet</p>'}
                        </div>
                        
                        <div class="mt-4">
                            <button class="btn btn-primary btn-sm" onclick="updateStatusModal(${order.id})">
                                <i class="bi bi-arrow-up-circle me-1"></i>Update Status
                            </button>
                            <button class="btn btn-outline-info btn-sm" onclick="trackOrder('${order.tracking_number}')">
                                <i class="bi bi-geo-alt me-1"></i>Track Package
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('orderDetailContent').innerHTML = modalContent;
            new bootstrap.Modal(document.getElementById('orderDetailModal')).show();
        }
    } catch (error) {
        console.error('Error loading order details:', error);
        showToast('Error loading order details', 'danger');
    }
}

// Update status modal
async function updateStatusModal(orderId) {
    try {
        // Get delivery info for this order
        const response = await authFetch(`/api/deliveries/order/${orderId}/tracking`);
        const data = await response.json();
        
        document.getElementById('updateOrderId').value = orderId;
        
        if (data.success && data.data.tracking_number) {
            // Get delivery ID from deliveries table
            const deliveryResponse = await authFetch(`/api/deliveries/track/${data.data.tracking_number}`);
            const deliveryData = await deliveryResponse.json();
            
            if (deliveryData.success) {
                document.getElementById('updateDeliveryId').value = deliveryData.data.delivery.id;
            }
        }
        
        // Reset form
        document.getElementById('statusUpdateForm').reset();
        document.getElementById('updateOrderId').value = orderId;
        
        new bootstrap.Modal(document.getElementById('statusUpdateModal')).show();
    } catch (error) {
        console.error('Error preparing status update:', error);
        showToast('Error preparing status update', 'danger');
    }
}

// Update order status
async function updateOrderStatus() {
    try {
        const orderId = document.getElementById('updateOrderId').value;
        const deliveryId = document.getElementById('updateDeliveryId').value;
        const statusId = document.getElementById('newStatus').value;
        const location = document.getElementById('statusLocation').value;
        const notes = document.getElementById('statusNotes').value;
        const notifyCustomer = document.getElementById('notifyCustomer').checked;
        
        if (!statusId) {
            showToast('Please select a status', 'warning');
            return;
        }
        
        // Update delivery status
        const response = await authFetch(`/api/deliveries/${deliveryId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status_id: parseInt(statusId),
                location: location || null,
                notes: notes || null,
                notify_customer: notifyCustomer
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('Order status updated successfully', 'success');
            bootstrap.Modal.getInstance(document.getElementById('statusUpdateModal')).hide();
            refreshOrders();
        } else {
            showToast(data.message || 'Failed to update status', 'danger');
        }
    } catch (error) {
        console.error('Error updating order status:', error);
        showToast('Error updating order status', 'danger');
    }
}

// Track order
function trackOrder(trackingNumber) {
    if (trackingNumber && trackingNumber !== 'Not assigned') {
        window.open(`track-order.html?tracking=${trackingNumber}`, '_blank');
    } else {
        showToast('No tracking number available', 'warning');
    }
}

// Refresh orders
async function refreshOrders() {
    await loadOrderStats();
    await loadOrders();
}

// Export orders
function exportOrders() {
    const csvContent = "data:text/csv;charset=utf-8," + 
        "Order ID,Customer,Email,Total,Status,Tracking,Created\n" +
        filteredOrders.map(order => 
            `${order.id},"${order.user_name || ''}","${order.email || ''}",${order.total_amount},${order.delivery_status || 'pending'},"${order.tracking_number || ''}","${order.created_at}"`
        ).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `orders_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Utility functions
function showLoading(show) {
    document.getElementById('loadingState').classList.toggle('d-none', !show);
}

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    const toastId = 'toast-' + Date.now();
    
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement);
    toast.show();
    
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Global functions
window.viewOrderDetails = viewOrderDetails;
window.updateStatusModal = updateStatusModal;
window.updateOrderStatus = updateOrderStatus;
window.trackOrder = trackOrder;
window.refreshOrders = refreshOrders;
window.exportOrders = exportOrders;
