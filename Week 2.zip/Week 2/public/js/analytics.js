// analytics.js - Delivery Analytics Dashboard
import { getAccessToken, logout } from './auth.js';

let currentTimeframe = 30;
let dailyTrendsChart = null;
let statusChart = null;

// Initialize analytics dashboard
document.addEventListener('DOMContentLoaded', async () => {
    await loadAnalytics();
});

// Set timeframe and reload data
window.setTimeframe = async (days) => {
    currentTimeframe = days;
    
    // Update active button
    document.querySelectorAll('.btn-group .btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    await loadAnalytics();
};

// Load all analytics data
async function loadAnalytics() {
    try {
        showLoading();
        
        const token = getAccessToken();
        const headers = { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };

        // Fetch all analytics data
        const [
            deliveryResponse,
            carrierResponse,
            satisfactionResponse,
            costResponse
        ] = await Promise.all([
            fetch(`/api/analytics/delivery?timeframe=${currentTimeframe}`, { headers }),
            fetch(`/api/analytics/carrier-performance?timeframe=${currentTimeframe}`, { headers }),
            fetch(`/api/analytics/customer-satisfaction?timeframe=${currentTimeframe}`, { headers }),
            fetch(`/api/analytics/cost-analysis?timeframe=${currentTimeframe}`, { headers })
        ]);

        const deliveryData = await deliveryResponse.json();
        const carrierData = await carrierResponse.json();
        const satisfactionData = await satisfactionResponse.json();
        const costData = await costResponse.json();

        if (deliveryData.success) {
            renderOverviewCards(deliveryData.data.overview);
            renderDailyTrendsChart(deliveryData.data.dailyTrends);
            renderStatusChart(deliveryData.data.statusBreakdown);
            renderMethodPerformanceTable(deliveryData.data.methodPerformance);
            renderTopLocationsTable(deliveryData.data.topLocations);
        }

        if (carrierData.success) {
            renderCarrierPerformanceTable(carrierData.data);
        }

        hideLoading();

    } catch (error) {
        console.error('Analytics loading error:', error);
        hideLoading();
        showAlert('Failed to load analytics data', 'danger');
    }
}

// Render overview cards
function renderOverviewCards(overview) {
    document.getElementById('totalDeliveries').textContent = overview.total_deliveries || '0';
    document.getElementById('completedDeliveries').textContent = overview.completed_deliveries || '0';
    document.getElementById('avgDeliveryTime').textContent = overview.avg_delivery_time ? 
        `${Math.round(overview.avg_delivery_time)} days` : 'N/A';
    document.getElementById('shippingRevenue').textContent = overview.total_shipping_revenue ? 
        `$${parseFloat(overview.total_shipping_revenue).toFixed(2)}` : '$0.00';
}

// Render daily trends chart
function renderDailyTrendsChart(dailyTrends) {
    const ctx = document.getElementById('dailyTrendsChart').getContext('2d');
    
    if (dailyTrendsChart) {
        dailyTrendsChart.destroy();
    }

    const labels = dailyTrends.map(d => new Date(d.date).toLocaleDateString());
    const deliveriesData = dailyTrends.map(d => d.deliveries_created);
    const completedData = dailyTrends.map(d => d.deliveries_completed);

    dailyTrendsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Deliveries Created',
                    data: deliveriesData,
                    borderColor: 'rgb(54, 162, 235)',
                    backgroundColor: 'rgba(54, 162, 235, 0.1)',
                    tension: 0.1
                },
                {
                    label: 'Deliveries Completed',
                    data: completedData,
                    borderColor: 'rgb(75, 192, 192)',
                    backgroundColor: 'rgba(75, 192, 192, 0.1)',
                    tension: 0.1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Render status breakdown chart
function renderStatusChart(statusBreakdown) {
    const ctx = document.getElementById('statusChart').getContext('2d');
    
    if (statusChart) {
        statusChart.destroy();
    }

    const labels = statusBreakdown.map(s => s.status.replace(/_/g, ' '));
    const data = statusBreakdown.map(s => s.count);
    const colors = [
        '#28a745', '#17a2b8', '#ffc107', '#fd7e14', 
        '#dc3545', '#6f42c1', '#20c997', '#6c757d'
    ];

    statusChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors.slice(0, data.length),
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Render method performance table
function renderMethodPerformanceTable(methodPerformance) {
    const tbody = document.getElementById('methodPerformanceTable');
    
    if (!methodPerformance.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">No data available</td></tr>';
        return;
    }

    tbody.innerHTML = methodPerformance.map(method => `
        <tr>
            <td><span class="badge bg-secondary">${method.delivery_method}</span></td>
            <td>${method.total_orders}</td>
            <td>$${parseFloat(method.avg_cost || 0).toFixed(2)}</td>
            <td>
                <div class="d-flex align-items-center">
                    <span class="me-2">${method.on_time_percentage || 0}%</span>
                    <div class="progress flex-grow-1" style="height: 6px;">
                        <div class="progress-bar ${getPerformanceColor(method.on_time_percentage)}" 
                             style="width: ${method.on_time_percentage || 0}%"></div>
                    </div>
                </div>
            </td>
        </tr>
    `).join('');
}

// Render top locations table
function renderTopLocationsTable(topLocations) {
    const tbody = document.getElementById('topLocationsTable');
    
    if (!topLocations.length) {
        tbody.innerHTML = '<tr><td colspan="3" class="text-center">No data available</td></tr>';
        return;
    }

    tbody.innerHTML = topLocations.map(location => `
        <tr>
            <td>
                <i class="bi bi-geo-alt text-primary"></i>
                ${location.city || 'Unknown'}, ${location.state || 'N/A'}
            </td>
            <td>${location.delivery_count}</td>
            <td>$${parseFloat(location.avg_shipping_cost || 0).toFixed(2)}</td>
        </tr>
    `).join('');
}

// Render carrier performance table
function renderCarrierPerformanceTable(carrierData) {
    const tbody = document.getElementById('carrierPerformanceTable');
    
    if (!carrierData.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No carrier data available</td></tr>';
        return;
    }

    tbody.innerHTML = carrierData.map(carrier => `
        <tr>
            <td>
                <div class="d-flex align-items-center">
                    <i class="bi bi-truck me-2"></i>
                    <strong>${carrier.carrier || 'Unknown'}</strong>
                </div>
            </td>
            <td>${carrier.total_shipments}</td>
            <td>$${parseFloat(carrier.avg_cost || 0).toFixed(2)}</td>
            <td>${Math.round(carrier.avg_delivery_time || 0)} days</td>
            <td>
                <div class="d-flex align-items-center">
                    <span class="me-2">${carrier.on_time_percentage || 0}%</span>
                    <div class="progress flex-grow-1" style="height: 6px;">
                        <div class="progress-bar ${getPerformanceColor(carrier.on_time_percentage)}" 
                             style="width: ${carrier.on_time_percentage || 0}%"></div>
                    </div>
                </div>
            </td>
            <td>
                <span class="badge bg-${carrier.late_count > 0 ? 'warning' : 'success'}">
                    ${carrier.late_count || 0}
                </span>
            </td>
        </tr>
    `).join('');
}

// Helper functions
function getPerformanceColor(percentage) {
    if (percentage >= 90) return 'bg-success';
    if (percentage >= 75) return 'bg-warning';
    return 'bg-danger';
}

function showLoading() {
    // Add loading indicators to tables
    const tables = ['methodPerformanceTable', 'topLocationsTable', 'carrierPerformanceTable'];
    tables.forEach(tableId => {
        const tbody = document.getElementById(tableId);
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center"><div class="spinner-border spinner-border-sm"></div> Loading...</td></tr>';
        }
    });
}

function hideLoading() {
    // Loading is hidden when data is rendered
}

function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    alertDiv.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.parentNode.removeChild(alertDiv);
        }
    }, 5000);
}

// Export logout for navbar
window.logout = logout;
