// Imarat Builders Mall CRUD System - Main JavaScript File

// Global variables
let currentSection = 'products';

// User & role helpers
const authFetch = window.authFetch || ((url, options={})=>fetch(url, options));
const isLoggedIn = window.isLoggedIn || (()=> !!localStorage.getItem('accessToken'));
const getUser = window.getUser || (()=>{try{return JSON.parse(localStorage.getItem('user'));}catch{return null;}});
const currentUser = getUser();
const isAdminUser = currentUser && currentUser.role === 'admin';

let categories = [];
let brands = [];
let products = [];

// API Base URL
const API_BASE_URL = '/api';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is admin to determine default section
    const currentUser = getUser();
    const isAdminUser = currentUser && currentUser.role === 'admin';
    
    if (isAdminUser) {
        showSection('dashboard');
    } else {
        showSection('products');
    }
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Product search input
    const productSearch = document.getElementById('productSearch');
    if (productSearch) {
        productSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });
    }
}

// Navigation functions
function showSection(section) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(el => {
        el.style.display = 'none';
    });
    
    // Show selected section
    const secEl = document.getElementById(`${section}-section`);
    if (!secEl) return; // if section not present on this page (e.g., product.html), do nothing
    secEl.style.display = 'block';

    // Toggle admin-only panels visibility
    const adminPanel = document.getElementById('admin-only-panels');
    if (adminPanel) {
        if (section === 'dashboard' && isAdminUser) {
            adminPanel.classList.remove('d-none');
        } else {
            adminPanel.classList.add('d-none');
        }
    }
    
    // Initialize my orders section for non-admin users
    if (section === 'my-orders' && !isAdminUser) {
        import('./myOrders.js').then(({ initMyOrders }) => {
            initMyOrders();
        }).catch(err => {
            console.error('Failed to load my orders module:', err);
        });
    }
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(el => {
        el.classList.remove('active');
    });
    
    // Set active based on section, not event target
    const targetLink = document.querySelector(`[onclick="showSection('${section}')"]`);
    if (targetLink) {
        targetLink.classList.add('active');
    }
    
    currentSection = section;
    
    // Load section data
    switch(section) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'categories':
            loadCategories();
            break;
        case 'brands':
            loadBrands();
            break;
        case 'products':
            loadProducts();
            break;
        case 'my-orders':
            console.log('Loading my-orders section');
            // Direct load and call
            if (!window.myOrdersLoaded) {
                const script = document.createElement('script');
                script.type = 'module';
                script.src = 'js/myOrders.js';
                script.onload = () => {
                    console.log('myOrders.js loaded, calling init');
                    window.myOrdersLoaded = true;
                    if (window.initMyOrders) {
                        window.initMyOrders();
                    } else {
                        console.error('initMyOrders not found on window');
                    }
                };
                script.onerror = (e) => console.error('Failed to load myOrders.js', e);
                document.head.appendChild(script);
            } else if (window.initMyOrders) {
                console.log('myOrders already loaded, calling init');
                window.initMyOrders();
            }
            break;
    }
}

// Dashboard functions
async function loadDashboard() {
    try {
        // Load statistics
        await Promise.all([
            loadCategoriesStats(),
            loadBrandsStats(),
            loadProductsStats(),
            loadRecentItems()
        ]);
    } catch (error) {
        showAlert('Error loading dashboard data', 'danger');
    }
}

async function loadCategoriesStats() {
    const response = await fetch(`${API_BASE_URL}/categories/stats`);
    const data = await response.json();
    if (data.success) {
        const totalCategories = data.data.length;
        document.getElementById('totalCategories').textContent = totalCategories;
    }
}

async function loadBrandsStats() {
    const response = await fetch(`${API_BASE_URL}/brands/stats`);
    const data = await response.json();
    if (data.success) {
        const totalBrands = data.data.length;
        document.getElementById('totalBrands').textContent = totalBrands;
    }
}

async function loadProductsStats() {
    const response = await fetch(`${API_BASE_URL}/products/stats`);
    const data = await response.json();
    if (data.success) {
        const stats = data.data;
        document.getElementById('totalProducts').textContent = stats.total_products ?? 0;
        document.getElementById('avgPrice').textContent = stats.avg_price !== null ? `$${parseFloat(stats.avg_price).toFixed(2)}` : '$0.00';
    }
}

async function loadRecentItems() {
    try {
        // Load recent categories
        const categoriesResponse = await fetch(`${API_BASE_URL}/categories`);
        const categoriesData = await categoriesResponse.json();
        if (categoriesData.success) {
            displayRecentCategories(categoriesData.data.slice(0, 5));
        }

        // Load recent products
        const productsResponse = await fetch(`${API_BASE_URL}/products`);
        const productsData = await productsResponse.json();
        if (productsData.success) {
            displayRecentProducts(productsData.data.slice(0, 5));
        }
    } catch (error) {
        console.error('Error loading recent items:', error);
    }
}

function displayRecentCategories(categories) {
    const container = document.getElementById('recentCategories');
    if (categories.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-tags"></i><p>No categories found</p></div>';
        return;
    }
    
    container.innerHTML = categories.map(category => `
        <div class="list-group-item d-flex justify-content-between align-items-center">
            <div>
                <strong>${category.name}</strong>
                <br><small class="text-muted">${new Date(category.created_at).toLocaleDateString()}</small>
            </div>
            <span class="badge bg-primary rounded-pill">${category.brand_count || 0} brands</span>
        </div>
    `).join('');
}

function displayRecentProducts(products) {
    const container = document.getElementById('recentProducts');
    if (products.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-box"></i><p>No products found</p></div>';
        return;
    }
    
    container.innerHTML = products.map(product => `
        <div class="list-group-item d-flex justify-content-between align-items-center">
            <div>
                <strong>${product.name}</strong>
                <br><small class="text-muted">${product.brand_name} • ${product.category_name}</small>
            </div>
            <span class="price">$${parseFloat(product.price).toFixed(2)}</span>
        </div>
    `).join('');
}

// Category functions
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories/stats`);
        const data = await response.json();
        if (data.success) {
            categories = data.data;
            displayCategories(categories);
        }
    } catch (error) {
        showAlert('Error loading categories', 'danger');
    }
}

function displayCategories(categories) {
    const tbody = document.getElementById('categoriesTableBody');
    if (categories.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No categories found</td></tr>';
        return;
    }
    
    tbody.innerHTML = categories.map(category => `
        <tr>
            <td>${category.id}</td>
            <td><strong>${category.name}</strong></td>
            <td><span class="badge bg-primary">${category.brand_count || 0}</span></td>
            <td>${new Date(category.created_at).toLocaleDateString()}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-warning" onclick="editCategory(${category.id})">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteCategory(${category.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function showCategoryForm(categoryId = null) {
    const modal = new bootstrap.Modal(document.getElementById('categoryModal'));
    const title = document.getElementById('categoryModalTitle');
    const nameInput = document.getElementById('categoryName');
    const idInput = document.getElementById('categoryId');
    
    if (categoryId) {
        title.textContent = 'Edit Category';
        const category = categories.find(c => c.id === categoryId);
        if (category) {
            nameInput.value = category.name;
            idInput.value = category.id;
        }
    } else {
        title.textContent = 'Add Category';
        nameInput.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function saveCategory() {
    const nameInput = document.getElementById('categoryName');
    const idInput = document.getElementById('categoryId');
    const name = nameInput.value.trim();
    
    if (!name) {
        showAlert('Category name is required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/categories/${idInput.value}` : 
            `${API_BASE_URL}/categories`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('categoryModal')).hide();
            loadCategories();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving category', 'danger');
    }
}

async function editCategory(id) {
    showCategoryForm(id);
}

async function deleteCategory(id) {
    if (!confirm('Are you sure you want to delete this category?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/categories/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadCategories();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting category', 'danger');
    }
}

// Brand functions
async function loadBrands() {
    try {
        const response = await fetch(`${API_BASE_URL}/brands/stats`);
        const data = await response.json();
        if (data.success) {
            brands = data.data;
            displayBrands(brands);
        }
    } catch (error) {
        showAlert('Error loading brands', 'danger');
    }
}

function displayBrands(brands) {
    const tbody = document.getElementById('brandsTableBody');
    if (brands.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No brands found</td></tr>';
        return;
    }
    
    tbody.innerHTML = brands.map(brand => `
        <tr>
            <td>${brand.id}</td>
            <td><strong>${brand.name}</strong></td>
            <td><span class="badge bg-secondary">${brand.category_name}</span></td>
            <td><span class="badge bg-success">${brand.product_count || 0}</span></td>
            <td>${new Date(brand.created_at).toLocaleDateString()}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-warning" onclick="editBrand(${brand.id})">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteBrand(${brand.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function showBrandForm(brandId = null) {
    // Load categories for dropdown
    await loadCategoriesForDropdown();
    
    const modal = new bootstrap.Modal(document.getElementById('brandModal'));
    const title = document.getElementById('brandModalTitle');
    const nameInput = document.getElementById('brandName');
    const categorySelect = document.getElementById('brandCategory');
    const idInput = document.getElementById('brandId');
    
    if (brandId) {
        title.textContent = 'Edit Brand';
        const brand = brands.find(b => b.id === brandId);
        if (brand) {
            nameInput.value = brand.name;
            categorySelect.value = brand.category_id;
            idInput.value = brand.id;
        }
    } else {
        title.textContent = 'Add Brand';
        nameInput.value = '';
        categorySelect.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function loadCategoriesForDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        const data = await response.json();
        if (data.success) {
            const categorySelect = document.getElementById('brandCategory');
            categorySelect.innerHTML = '<option value="">Select Category</option>' +
                data.data.map(category => 
                    `<option value="${category.id}">${category.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function saveBrand() {
    const nameInput = document.getElementById('brandName');
    const categorySelect = document.getElementById('brandCategory');
    const idInput = document.getElementById('brandId');
    const name = nameInput.value.trim();
    const categoryId = categorySelect.value;
    
    if (!name || !categoryId) {
        showAlert('Brand name and category are required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/brands/${idInput.value}` : 
            `${API_BASE_URL}/brands`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                name, 
                category_id: parseInt(categoryId) 
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('brandModal')).hide();
            loadBrands();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving brand', 'danger');
    }
}

async function editBrand(id) {
    showBrandForm(id);
}

async function deleteBrand(id) {
    if (!confirm('Are you sure you want to delete this brand?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/brands/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadBrands();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting brand', 'danger');
    }
}

// Product functions
async function loadProducts() {
    try {
        // Show loading spinner inside products grid
        showLoading('productsGrid');
        const response = await fetch(`${API_BASE_URL}/products`);
        const data = await response.json();
        hideLoading('productsGrid');
        if (data.success) {
            products = data.data;
            populateProductFilterOptions(products);
            displayProducts(products);
        } else {
            showAlert('Failed to load products.', 'danger');
        }
    } catch (error) {
        hideLoading('productsGrid');
        showAlert('Error loading products', 'danger');
    }
}

function displayProducts(products) {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    const wishlistButton = (id) => !isAdminUser ? `<button type="button" class="btn btn-sm btn-outline-danger wishlist-btn flex-fill" onclick="event.stopPropagation(); toggleWishlist(${id}, this)"><i class="bi bi-heart"></i></button>` : '';

    const adminButtons = (id) => isAdminUser ? `
        <button class="btn btn-sm btn-warning flex-fill" onclick="event.stopPropagation(); editProduct(${id})"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-danger flex-fill" onclick="event.stopPropagation(); deleteProduct(${id})"><i class="bi bi-trash"></i></button>` : '';

    if (products.length === 0) {
        grid.innerHTML = '<p class="text-center">No products found</p>';
        return;
    }

    grid.innerHTML = products.map(product => `
        <div class="col">
            <div class="card h-100 shadow-sm product-card" role="button" onclick="viewProduct(${product.id})">
                <img src="${product.image_url || 'https://via.placeholder.com/300x200?text=No+Image'}" class="card-img-top" alt="${product.name}" onerror="this.src='https://via.placeholder.com/300x200?text=Image+Unavailable';">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title mb-1">${product.name}</h5>
                    <p class="card-text small text-muted mb-2">${product.brand_name} • ${product.category_name}</p>
                    <p class="card-text fw-bold text-primary mb-2">$${parseFloat(product.price).toFixed(2)}</p>
                    <p class="card-text small flex-grow-1">${product.description || ''}</p>
                    <div class="d-flex gap-2 mt-2">
                        ${wishlistButton(product.id)}
                        ${adminButtons(product.id)}
                        ${(!isAdminUser && product.stock>0) ? `<button type=\"button\" class=\"btn btn-sm btn-success flex-fill\" onclick=\"event.stopPropagation(); addToCart(${product.id})\"><i class=\"bi bi-cart-plus\"></i></button>`:''}
                    </div>
                </div>
            </div>
         </div>
     `).join('');
}

function populateProductFilterOptions(prodList) {
    const catSel = document.getElementById('filterCategory');
    const brandSel = document.getElementById('filterBrand');
    if (!catSel || !brandSel) return;
    const categories = [...new Set(prodList.map(p => p.category_name))].sort();
    const brands = [...new Set(prodList.map(p => p.brand_name))].sort();
    catSel.innerHTML = '<option value="">All Categories</option>' + categories.map(c => `<option value="${c}">${c}</option>`).join('');
    brandSel.innerHTML = '<option value="">All Brands</option>' + brands.map(b => `<option value="${b}">${b}</option>`).join('');
}

function applyProductFilters() {
    const cat = document.getElementById('filterCategory')?.value || '';
    const brand = document.getElementById('filterBrand')?.value || '';
    const minPriceVal = document.getElementById('filterMinPrice')?.value;
    const maxPriceVal = document.getElementById('filterMaxPrice')?.value;
    const minPrice = minPriceVal ? parseFloat(minPriceVal) : 0;
    const maxPrice = maxPriceVal ? parseFloat(maxPriceVal) : Infinity;
    let filtered = products.filter(p =>
        (!cat || p.category_name === cat) &&
        (!brand || p.brand_name === brand) &&
        (isNaN(minPrice) || p.price >= minPrice) &&
        (isNaN(maxPrice) || p.price <= maxPrice)
    );
    
    // Apply sorting
    const sortVal = document.getElementById('sortSelect')?.value || '';
    switch (sortVal) {
        case 'price_asc':
            filtered = filtered.sort((a,b)=>a.price - b.price);
            break;
        case 'price_desc':
            filtered = filtered.sort((a,b)=>b.price - a.price);
            break;
        case 'name_asc':
            filtered = filtered.sort((a,b)=>a.name.localeCompare(b.name));
            break;
        case 'name_desc':
            filtered = filtered.sort((a,b)=>b.name.localeCompare(a.name));
            break;
        default:
            break;
    }
    displayProducts(filtered);
}

function clearProductFilters() {
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterBrand').value = '';
    document.getElementById('filterMinPrice').value = '';
    document.getElementById('filterMaxPrice').value = '';
    displayProducts(products);
}

async function showProductForm(productId = null) {
    // Load categories and brands for dropdowns
    await Promise.all([
        loadCategoriesForProductDropdown(),
        loadBrandsForProductDropdown()
    ]);
    
    const modal = new bootstrap.Modal(document.getElementById('productModal'));
    const title = document.getElementById('productModalTitle');
    const nameInput = document.getElementById('productName');
    const brandSelect = document.getElementById('productBrand');
    const categorySelect = document.getElementById('productCategory');
    const priceInput = document.getElementById('productPrice');
    const imageInput = document.getElementById('productImage');
    const descriptionInput = document.getElementById('productDescription');
    const stockInput = document.getElementById('productStock');
    const idInput = document.getElementById('productId');
    
    if (productId) {
        title.textContent = 'Edit Product';
        const product = products.find(p => p.id === productId);
        if (product) {
            nameInput.value = product.name;
            brandSelect.value = product.brand_id;
            priceInput.value = product.price;
            stockInput.value = product.stock;
            imageInput.value = product.image_url || ''; // set image URL
            descriptionInput.value = product.description || '';
            imageInput.value = product.image_url || ''; // set image URL
            idInput.value = product.id;
            
            // Set category based on brand
            const brand = brands.find(b => b.id === product.brand_id);
            if (brand) {
                categorySelect.value = brand.category_id;
            }
        }
    } else {
        title.textContent = 'Add Product';
        nameInput.value = '';
        brandSelect.value = '';
        categorySelect.value = '';
        priceInput.value = '';
        descriptionInput.value = '';
        imageInput.value = '';
         stockInput.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function loadCategoriesForProductDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        const data = await response.json();
        if (data.success) {
            const categorySelect = document.getElementById('productCategory');
            categorySelect.innerHTML = '<option value="">Select Category</option>' +
                data.data.map(category => 
                    `<option value="${category.id}">${category.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadBrandsForProductDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/brands`);
        const data = await response.json();
        if (data.success) {
            const brandSelect = document.getElementById('productBrand');
            brandSelect.innerHTML = '<option value="">Select Brand</option>' +
                data.data.map(brand => 
                    `<option value="${brand.id}">${brand.name} (${brand.category_name})</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading brands:', error);
    }
}

async function loadBrandsByCategory() {
    const categorySelect = document.getElementById('productCategory');
    const brandSelect = document.getElementById('productBrand');
    const categoryId = categorySelect.value;
    
    if (!categoryId) {
        brandSelect.innerHTML = '<option value="">Select Brand</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/brands/category/${categoryId}`);
        const data = await response.json();
        if (data.success) {
            brandSelect.innerHTML = '<option value="">Select Brand</option>' +
                data.data.map(brand => 
                    `<option value="${brand.id}">${brand.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading brands by category:', error);
    }
}

async function saveProduct() {
    const nameInput = document.getElementById('productName');
    const brandSelect = document.getElementById('productBrand');
    const priceInput = document.getElementById('productPrice');
    const imageInput = document.getElementById('productImage');
    const descriptionInput = document.getElementById('productDescription');
    const stockInput = document.getElementById('productStock');
    const idInput = document.getElementById('productId');
    
    const name = nameInput.value.trim();
    const brandId = brandSelect.value;
    const price = parseFloat(priceInput.value);
    const description = descriptionInput.value.trim();
    const stock = parseInt(stockInput.value);
    const image_url = imageInput.value.trim();
    
    if (!name || !brandId || !price || price <= 0 || stock<0 || isNaN(stock)) {
        showAlert('Product name, brand, and valid price are required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/products/${idInput.value}` : 
            `${API_BASE_URL}/products`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                name, 
                brand_id: parseInt(brandId),
                price,
                description: description || null,
                image_url: image_url || null,
                 stock
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('productModal')).hide();
            loadProducts();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving product', 'danger');
    }
}

async function editProduct(id) {
    showProductForm(id);
}

async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    try {
        const response = await authFetch(`${API_BASE_URL}/products/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadProducts();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting product', 'danger');
    }
}

async function searchProducts() {
    const searchInput = document.getElementById('productSearch');
    const searchTerm = searchInput.value.trim();
    
    if (!searchTerm) {
        loadProducts();
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/products/search?q=${encodeURIComponent(searchTerm)}`);
        const data = await response.json();
        if (data.success) {
            displayProducts(data.data);
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error searching products', 'danger');
    }
}

// Utility functions
function showAlert(message, type) {
    const alertContainer = document.getElementById('alertContainer');
    const alertId = 'alert-' + Date.now();
    
    const alertHtml = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    alertContainer.innerHTML = alertHtml;
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

// Loading spinner utility
function showLoading(targetId = 'alertContainer') {
    const el = document.getElementById(targetId);
    if (el) {
        el.innerHTML = '<div class="d-flex justify-content-center my-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
    }
}
function hideLoading(targetId = 'alertContainer') {
    const el = document.getElementById(targetId);
    if (el) el.innerHTML = '';
}



document.addEventListener('DOMContentLoaded', () => {
  // Toggle admin-only UI blocks
  document.querySelectorAll('.admin-only').forEach(el => {
    el.classList.toggle('d-none', !isAdminUser);
  });
  if (isAdminUser) {
    import('./adminDashboard.js');
  }
  // Hide admin links for non-admins
  if (!isAdminUser) {
    document.querySelectorAll('.nav-item-admin').forEach(el => el.style.display = 'none');
    // Hide add buttons in products header
    const addBtn = document.getElementById('addProductBtn');
  }
});

// Add to Cart function
function addToCart(productId) {
    if (!isLoggedIn()) {
      window.location.href = 'login.html';
      return;
    }
    showLoading();
    authFetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: productId, quantity: 1 })
    })
      .then(res => res.json())
      .then(data => {
        hideLoading();
        if (data.success) {
          showAlert('Added to cart!', 'success');
          const cartIcon = document.querySelector('.bi-cart3');
          if (cartIcon){
            cartIcon.classList.add('cart-shake');
            setTimeout(()=>cartIcon.classList.remove('cart-shake'),400);
          }
        } else {
          showAlert(data.message || 'Failed to add to cart.', 'danger');
        }
      })
      .catch(() => {
        hideLoading();
        showAlert('Server error. Please try again.', 'danger');
      });
  }
  
  // Load product details & reviews
  function showProductDetails(productId) {
    import('./review.js').then(({ loadReviews, loadAverageRating }) => {
      loadReviews(productId);
      loadAverageRating(productId);
    });
  }
  

// Global functions for onclick handlers
// Attach all global functions to window for HTML access
window.showSection = showSection;
window.showCategoryForm = showCategoryForm;
window.saveCategory = saveCategory;
window.editCategory = editCategory;
window.deleteCategory = deleteCategory;
window.showBrandForm = showBrandForm;
window.saveBrand = saveBrand;
window.editBrand = editBrand;
window.deleteBrand = deleteBrand;
window.showProductForm = showProductForm;
window.saveProduct = saveProduct;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.searchProducts = searchProducts;
window.loadBrandsByCategory = loadBrandsByCategory;
function toggleWishlist(productId, btn) {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }
    let list = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const idx = list.indexOf(productId);
    if (idx === -1) {
        list.push(productId);
        if (btn) btn.querySelector('i').classList.add('bi-heart-fill');
        showAlert('Added to wishlist!', 'success');
    } else {
        list.splice(idx, 1);
        if (btn) btn.querySelector('i').classList.remove('bi-heart-fill');
        showAlert('Removed from wishlist', 'info');
    }
    localStorage.setItem('wishlist', JSON.stringify(list));
}

window.toggleWishlist = toggleWishlist;
window.addToCart = addToCart;
function viewProduct(id){
    window.location.href = `product.html?id=${id}`;
}
window.viewProduct = viewProduct;
async function loadCart() {
    if (!isLoggedIn() || isAdminUser) {
        if (isAdminUser) {
            showAlert('Cart is available only for customer accounts.', 'info');
            return;
        }
        window.location.href = 'login.html';
        return;
    }
    try {
        const res = await authFetch('/api/cart');
        const data = await res.json();
        if (data.success) {
            renderCart(data.cart || []);
            const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
            cartModal.show();
        } else {
            showAlert(data.message || 'Failed to load cart', 'danger');
        }
    } catch (err) {
        showAlert('Server error', 'danger');
    }
}

function renderCart(items) {
    const body = document.getElementById('cartItemsBody');
    if (!body) return;
    if (!items.length) {
         body.innerHTML = '<tr><td colspan="5" class="text-center">Cart is empty</td></tr>';
         document.getElementById('cartTotal').textContent = '$0.00';
         const checkoutBtn = document.getElementById('checkoutBtn');
         if (checkoutBtn) checkoutBtn.classList.add('disabled');
         return;
     }
    body.innerHTML = items
        .map(it => `<tr>
            <td>${it.product_name}</td>
            <td class="d-flex align-items-center gap-2">
                <button class="btn btn-sm btn-outline-secondary" onclick="changeCartQty(${it.product_id}, -1)"><i class="bi bi-dash"></i></button>
                <span>${it.quantity}</span>
                <button class="btn btn-sm btn-outline-secondary" onclick="changeCartQty(${it.product_id}, 1)"><i class="bi bi-plus"></i></button>
            </td>
            <td>$${parseFloat(it.price).toFixed(2)}</td>
            <td>$${(it.price * it.quantity).toFixed(2)}</td>
            <td><button class="btn btn-sm btn-link text-danger" onclick="removeFromCart(${it.product_id})"><i class="bi bi-trash"></i></button></td>
        </tr>`)
        .join('');
    const total = items.reduce((sum, it) => sum + it.price * it.quantity, 0);
    document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

async function changeCartQty(productId, delta) {
    const rowSpan = event?.target?.closest('tr');
    try {
        // find current qty from span text
        const currentQty = parseInt(rowSpan.querySelector('span').textContent);
        const newQty = currentQty + delta;
        if (newQty < 1) return; // do nothing if would go 0
        const res = await authFetch('/api/cart/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, quantity: newQty })
        });
        const data = await res.json();
        if (data.success) {
            // update UI without full reload for speed
            rowSpan.querySelector('span').textContent = newQty;
            const price = parseFloat(rowSpan.children[2].textContent.replace('$',''));
            rowSpan.children[3].textContent = `$${(price*newQty).toFixed(2)}`;
            // recalc total
            recalcCartTotal();
        } else {
            showAlert(data.message || 'Failed to update', 'danger');
        }
    } catch(err) {
        showAlert('Server error', 'danger');
    }
}

function recalcCartTotal() {
    const rows = Array.from(document.querySelectorAll('#cartItemsBody tr'));
    const total = rows.reduce((sum, r) => sum + parseFloat(r.children[3].textContent.replace('$','')), 0);
    document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

async function removeFromCart(productId) {
    try {
        const res = await authFetch('/api/cart/remove', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId })
        });
        const data = await res.json();
        if (data.success) {
            showAlert('Item removed from cart', 'success');
            await loadCart();
        } else {
            showAlert(data.message || 'Failed to remove', 'danger');
        }
    } catch (err) {
        showAlert('Server error', 'danger');
    }
}

window.removeFromCart = removeFromCart;
window.loadCart = loadCart;
window.removeFromCart = removeFromCart;
window.loadCart = loadCart;
window.applyProductFilters = applyProductFilters;
window.clearProductFilters = clearProductFilters;
window.showProductDetails = showProductDetails;

// ------------ Wishlist functions -------------
async function loadWishlist() {
    const list = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const tbody = document.getElementById('wishlistBody');
    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">Your wishlist is empty</td></tr>';
    } else {
        // ensure global products array exists
        if(!window.products) window.products = [];
        // fetch missing product details
        const missingIds = list.filter(id=>!products.find(p=>p.id===id));
        for(const id of missingIds){
          try{
            const res = await fetch(`/api/products/${id}`);
            const data = await res.json();
            if(data.success) products.push(data.product || data.data);
          }catch{}
        }
        const rows = list.map(id => {
            const prod = products.find(p => p.id === id);
            if (!prod) return '';
            return `<tr>
                <td><input type="checkbox" value="${prod.id}" class="form-check-input wishlist-checkbox"></td>
                <td>${prod.name}</td>
                <td>$${parseFloat(prod.price).toFixed(2)}</td>
                <td><button type="button" class="btn btn-link text-danger p-0" onclick="removeWishlistItem(${prod.id})"><i class="bi bi-trash"></i></button></td>
            </tr>`;
        }).join('');
        tbody.innerHTML = rows || '<tr><td colspan="4" class="text-center">Items unavailable</td></tr>';
    }
    new bootstrap.Modal(document.getElementById('wishlistModal')).show();
}

async function moveWishlistToCart() {
    const checked = Array.from(document.querySelectorAll('.wishlist-checkbox:checked')).map(cb => parseInt(cb.value));
    if (!checked.length) {
        showAlert('Select at least one item.', 'info');
        return;
    }
    for (const id of checked) {
        try {
            await authFetch('/api/cart/add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ product_id: id, quantity: 1 })
            });
        } catch {}
    }
    // remove moved ids from wishlist
    let list = JSON.parse(localStorage.getItem('wishlist') || '[]');
    list = list.filter(id => !checked.includes(id));
    localStorage.setItem('wishlist', JSON.stringify(list));
    showAlert('Moved to cart!', 'success');
    loadWishlist(); // refresh view
}

window.loadWishlist = loadWishlist;
window.moveWishlistToCart = moveWishlistToCart;
function removeWishlistItem(id){
  let list = JSON.parse(localStorage.getItem('wishlist')||'[]');
  list = list.filter(pid=>pid!==id);
  localStorage.setItem('wishlist',JSON.stringify(list));
  loadWishlist();

  // update stats if on profile page
  const statElem = document.getElementById('statWishlist');
  if(statElem) statElem.textContent = list.length;
}
window.changeCartQty = changeCartQty;
window.recalcCartTotal = recalcCartTotal;