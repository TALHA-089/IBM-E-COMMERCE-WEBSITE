// Imarat Builders Mall CRUD System - Main JavaScript File

// Global variables
let currentSection = 'products';

// Export functions for module usage
export { addToCart, showAlert, loadProducts };

// Make loadProducts available globally
window.fetchProducts = loadProducts;

// User & role helpers
const authFetch = window.authFetch || ((url, options={})=>{
  const token = localStorage.getItem('accessToken');
  options.headers = options.headers || {};
  if(token){ options.headers['Authorization'] = 'Bearer '+token; }
  return fetch(url, options);
});
const isLoggedIn = window.isLoggedIn || (()=> !!localStorage.getItem('accessToken'));
const getUser = window.getUser || (()=>{try{return JSON.parse(localStorage.getItem('user'));}catch{return null;}});
const currentUser = getUser();
const isAdminUser = currentUser && currentUser.role === 'admin';

let categories = [];
let brands = [];
let products = [];
let filteredProducts = [];
let currentPage = 1;
let pageSize = parseInt(localStorage.getItem('pageSize')) || 8;
let showHot=false;

// API Base URL
const API_BASE_URL = '/api';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is admin to determine default section
    const currentUser = getUser();
    const isAdminUser = currentUser && currentUser.role === 'admin';
    
    if (isAdminUser) {
        showSection('dashboard');
    } else {
        showSection('products');
    }
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Product search input
    const productSearch = document.getElementById('productSearch');
    if (productSearch) {
        productSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchProducts();
            }
        });
    }
}

// Navigation functions
function showSection(section) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(el => {
        el.style.display = 'none';
    });
    
    // Show selected section
    const secEl = document.getElementById(`${section}-section`);
    if (!secEl) return; // if section not present on this page (e.g., product.html), do nothing
    secEl.style.display = 'block';

    // Toggle admin-only panels visibility
    const adminPanel = document.getElementById('admin-only-panels');
    if (adminPanel) {
        if (section === 'dashboard' && isAdminUser) {
            adminPanel.classList.remove('d-none');
        } else {
            adminPanel.classList.add('d-none');
        }
    }
    
    // Initialize my orders section for non-admin users
    if (section === 'my-orders' && !isAdminUser) {
        import('./myOrders.js').then(({ initMyOrders }) => {
            initMyOrders();
        }).catch(err => {
            console.error('Failed to load my orders module:', err);
        });
    }
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(el => {
        el.classList.remove('active');
    });
    
    // Set active based on section, not event target
    const targetLink = document.querySelector(`[onclick="showSection('${section}')"]`);
    if (targetLink) {
        targetLink.classList.add('active');
    }
    
    currentSection = section;
    
    // Load section data
    switch(section) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'categories':
            loadCategories();
            break;
        case 'brands':
            loadBrands();
            break;
        case 'products':
            loadProducts();
            break;
        case 'my-orders':
            console.log('Loading my-orders section');
            // Direct load and call
            if (!window.myOrdersLoaded) {
                const script = document.createElement('script');
                script.type = 'module';
                script.src = 'js/myOrders.js';
                script.onload = () => {
                    console.log('myOrders.js loaded, calling init');
                    window.myOrdersLoaded = true;
                    if (window.initMyOrders) {
                        window.initMyOrders();
                    } else {
                        console.error('initMyOrders not found on window');
                    }
                };
                script.onerror = (e) => console.error('Failed to load myOrders.js', e);
                document.head.appendChild(script);
            } else if (window.initMyOrders) {
                console.log('myOrders already loaded, calling init');
                window.initMyOrders();
            }
            break;
    }
}

// Dashboard functions
async function loadDashboard() {
    try {
        // Load statistics
        await Promise.all([
            loadCategoriesStats(),
            loadBrandsStats(),
            loadProductsStats(),
            loadRecentItems()
        ]);
    } catch (error) {
        showAlert('Error loading dashboard data', 'danger');
    }
}

async function loadCategoriesStats() {
    const response = await fetch(`${API_BASE_URL}/categories/stats`);
    const data = await response.json();
    if (data.success) {
        const totalCategories = data.data.length;
        document.getElementById('totalCategories').textContent = totalCategories;
    }
}

async function loadBrandsStats() {
    const response = await fetch(`${API_BASE_URL}/brands/stats`);
    const data = await response.json();
    if (data.success) {
        const totalBrands = data.data.length;
        document.getElementById('totalBrands').textContent = totalBrands;
    }
}

async function loadProductsStats() {
    const response = await fetch(`${API_BASE_URL}/products/stats`);
    const data = await response.json();
    if (data.success) {
        const stats = data.data;
        document.getElementById('totalProducts').textContent = stats.total_products ?? 0;
        document.getElementById('avgPrice').textContent = stats.avg_price !== null ? `$${parseFloat(stats.avg_price).toFixed(2)}` : '$0.00';
    }
}

async function loadRecentItems() {
    try {
        // Load recent categories
        const categoriesResponse = await fetch(`${API_BASE_URL}/categories/stats`);
        const categoriesData = await categoriesResponse.json();
        if (categoriesData.success) {
            const sortedCats = categoriesData.data.sort((a,b)=> new Date(b.created_at) - new Date(a.created_at));
            displayRecentCategories(sortedCats.slice(0,5));
        }

        // Load recent products depending on mode
        const prodUrl = showHot ? `${API_BASE_URL}/orders/recent-products?limit=5` : `${API_BASE_URL}/products`;
        const productsResponse = await authFetch(prodUrl);
        const productsData = await productsResponse.json();
        if (productsData.success) {
            let prods = productsData.data;
            if(!showHot){
                prods = prods.sort((a,b)=> new Date(b.created_at) - new Date(a.created_at)).slice(0,5);
            }
            displayRecentProducts(prods);
        }
    } catch (error) {
        console.error('Error loading recent items:', error);
    }
}

function toggleHotProducts(){
    showHot = !showHot;
    document.getElementById('hotIcon').classList.toggle('text-danger',showHot);
    loadRecentItems();

}

// Expose to inline handlers
window.toggleHotProducts = toggleHotProducts;

function displayRecentCategories(categories) {
    const container = document.getElementById('recentCategories');
    if (categories.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-tags"></i><p>No categories found</p></div>';
        return;
    }
    
    container.innerHTML = categories.map(category => `
        <div class="list-group-item d-flex justify-content-between align-items-center list-hover" role="button" onclick="showSection('categories')">
            <div>
                <strong>${category.name}</strong>
                <br><small class="text-muted">${new Date(category.created_at).toLocaleDateString()}</small>
            </div>
            ${(()=>{
                if(typeof category.brand_count !== 'undefined') return `<span class=\"badge bg-primary rounded-pill\">${category.brand_count} brands</span>`;
                if(typeof category.product_count !== 'undefined') return `<span class=\"badge bg-primary rounded-pill\">${category.product_count} products</span>`;
                return '';
            })()}
        </div>
    `).join('');
}

function displayRecentProducts(products) {
    const container = document.getElementById('recentProducts');
    if (products.length === 0) {
        container.innerHTML = '<div class="empty-state"><i class="bi bi-box"></i><p>No products found</p></div>';
        return;
    }
    
    container.innerHTML = products.map(product => `
        <div class="list-group-item d-flex justify-content-between align-items-center list-hover" role="button" onclick="viewProduct(${product.id})">
            <div>
                <strong>${product.name}</strong>
                <br><small class="text-muted">${product.brand_name} • ${product.category_name}</small>
            </div>
            <span class="price text-success fw-bold">$${parseFloat(product.price).toFixed(2)}</span>
        </div>
    `).join('');
}

// Category functions
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories/stats`);
        const data = await response.json();
        if (data.success) {
            categories = data.data;
            displayCategories(categories);
        }
    } catch (error) {
        showAlert('Error loading categories', 'danger');
    }
}

function displayCategories(categories) {
    const tbody = document.getElementById('categoriesTableBody');
    if (categories.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center">No categories found</td></tr>';
        return;
    }
    
    tbody.innerHTML = categories.map(category => `
        <tr>
            <td>${category.id}</td>
            <td><strong>${category.name}</strong></td>
            <td><span class="badge bg-primary">${category.brand_count || 0}</span></td>
            <td>${new Date(category.created_at).toLocaleDateString()}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-warning" onclick="editCategory(${category.id})">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteCategory(${category.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function showCategoryForm(categoryId = null) {
    const modal = new bootstrap.Modal(document.getElementById('categoryModal'));
    const title = document.getElementById('categoryModalTitle');
    const nameInput = document.getElementById('categoryName');
    const idInput = document.getElementById('categoryId');
    
    if (categoryId) {
        title.textContent = 'Edit Category';
        const category = categories.find(c => c.id === categoryId);
        if (category) {
            nameInput.value = category.name;
            idInput.value = category.id;
        }
    } else {
        title.textContent = 'Add Category';
        nameInput.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function saveCategory() {
    const nameInput = document.getElementById('categoryName');
    const idInput = document.getElementById('categoryId');
    const name = nameInput.value.trim();
    
    if (!name) {
        showAlert('Category name is required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/categories/${idInput.value}` : 
            `${API_BASE_URL}/categories`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('categoryModal')).hide();
            loadCategories();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving category', 'danger');
    }
}

async function editCategory(id) {
    showCategoryForm(id);
}

async function deleteCategory(id) {
    if (!confirm('Are you sure you want to delete this category?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/categories/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadCategories();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting category', 'danger');
    }
}

// Brand functions
async function loadBrands() {
    try {
        const response = await fetch(`${API_BASE_URL}/brands/stats`);
        const data = await response.json();
        if (data.success) {
            brands = data.data;
            displayBrands(brands);
        }
    } catch (error) {
        showAlert('Error loading brands', 'danger');
    }
}

function displayBrands(brands) {
    const tbody = document.getElementById('brandsTableBody');
    if (brands.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No brands found</td></tr>';
        return;
    }
    
    tbody.innerHTML = brands.map(brand => `
        <tr>
            <td>${brand.id}</td>
            <td><strong>${brand.name}</strong></td>
            <td><span class="badge bg-secondary">${brand.category_name}</span></td>
            <td><span class="badge bg-success">${brand.product_count || 0}</span></td>
            <td>${new Date(brand.created_at).toLocaleDateString()}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-warning" onclick="editBrand(${brand.id})">
                    <i class="bi bi-pencil"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteBrand(${brand.id})">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function showBrandForm(brandId = null) {
    // Load categories for dropdown
    await loadCategoriesForDropdown();
    
    const modal = new bootstrap.Modal(document.getElementById('brandModal'));
    const title = document.getElementById('brandModalTitle');
    const nameInput = document.getElementById('brandName');
    const categorySelect = document.getElementById('brandCategory');
    const idInput = document.getElementById('brandId');
    
    if (brandId) {
        title.textContent = 'Edit Brand';
        const brand = brands.find(b => b.id === brandId);
        if (brand) {
            nameInput.value = brand.name;
            categorySelect.value = brand.category_id;
            idInput.value = brand.id;
        }
    } else {
        title.textContent = 'Add Brand';
        nameInput.value = '';
        categorySelect.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function loadCategoriesForDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        const data = await response.json();
        if (data.success) {
            const categorySelect = document.getElementById('brandCategory');
            categorySelect.innerHTML = '<option value="">Select Category</option>' +
                data.data.map(category => 
                    `<option value="${category.id}">${category.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function saveBrand() {
    const nameInput = document.getElementById('brandName');
    const categorySelect = document.getElementById('brandCategory');
    const idInput = document.getElementById('brandId');
    const name = nameInput.value.trim();
    const categoryId = categorySelect.value;
    
    if (!name || !categoryId) {
        showAlert('Brand name and category are required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/brands/${idInput.value}` : 
            `${API_BASE_URL}/brands`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                name, 
                category_id: parseInt(categoryId) 
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('brandModal')).hide();
            loadBrands();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving brand', 'danger');
    }
}

async function editBrand(id) {
    showBrandForm(id);
}

async function deleteBrand(id) {
    if (!confirm('Are you sure you want to delete this brand?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/brands/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadBrands();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting brand', 'danger');
    }
}

// Product functions
async function loadProducts() {
    try {
        // Show loading spinner inside products grid
        showLoading('productsGrid');
        const response = await fetch(`${API_BASE_URL}/products`);
        const data = await response.json();
        hideLoading('productsGrid');
        if (data.success) {
            // Process images for optimal display
            if (window.imageResizer) {
                showLoading('productsGrid');
                products = await window.imageResizer.processProductImages(data.data);
                hideLoading('productsGrid');
            } else {
                products = data.data;
            }
            populateProductFilterOptions(products);
            filteredProducts = products;
            renderPage(1);
        } else {
            showAlert('Failed to load products.', 'danger');
        }
    } catch (error) {
        hideLoading('productsGrid');
        showAlert('Error loading products', 'danger');
    }
}

function displayProducts(productsPage) {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    const wishlistButton = (id) => !isAdminUser ? `<button type="button" class="btn btn-sm btn-outline-danger wishlist-btn flex-fill" onclick="event.stopPropagation(); toggleWishlist(${id}, this)"><i class="bi bi-heart"></i></button>` : '';

    const adminButtons = (id) => isAdminUser ? `
        <button class="btn btn-sm btn-warning flex-fill" onclick="event.stopPropagation(); editProduct(${id})"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-danger flex-fill" onclick="event.stopPropagation(); deleteProduct(${id})"><i class="bi bi-trash"></i></button>` : '';

    if (products.length === 0) {
        grid.innerHTML = '<p class="text-center">No products found</p>';
        return;
    }

    grid.innerHTML = productsPage.map(product => `
        <div class="col">
            <div class="card h-100 shadow-sm product-card" role="button" onclick="viewProduct(${product.id})">
                <img src="${product.resized_image_url || ImageProxy.getProxiedUrl(product.image_url)}" class="card-img-top" alt="${product.name}" style="height: 250px; object-fit: cover;" onerror="ImageProxy.handleImageError(this)">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title mb-1">${product.name}</h5>
                    <p class="card-text small text-muted mb-2">${product.brand_name} • ${product.category_name}</p>
                    <p class="card-text fw-bold text-primary mb-2">$${parseFloat(product.price).toFixed(2)}</p>
                    <p class="card-text small flex-grow-1">${product.description || ''}</p>
                    <div class="d-flex gap-2 mt-2">
                        ${wishlistButton(product.id)}
                        ${!isAdminUser ? `<button type="button" class="btn btn-sm btn-outline-info compare-btn flex-fill" onclick="event.stopPropagation(); toggleCompare(${product.id}, this)" title="Compare"><i class="bi bi-arrow-left-right"></i></button>` : ''}
                        ${adminButtons(product.id)}
                        ${(!isAdminUser && product.stock>0) ? `<button type=\"button\" class=\"btn btn-sm btn-success flex-fill\" onclick=\"event.stopPropagation(); addToCart(${product.id})\"><i class=\"bi bi-cart-plus\"></i></button>`:''}
                    </div>
                </div>
            </div>
         </div>
     `).join('');
}

function renderPage(page=1){
    currentPage = page;
    const start = (page-1)*pageSize;
    const pageItems = filteredProducts.slice(start,start+pageSize);
    displayProducts(pageItems);
    renderPagination();
}

// expose globally for inline handlers
window.renderPage = renderPage;

function changePageSize(el){
    const val = parseInt(el.value);
    if(!isNaN(val) && val>0){
        pageSize = val;
        localStorage.setItem('pageSize', pageSize);
        renderPage(1);
    }
}
    

// expose globally for inline handlers
window.changePageSize = changePageSize;

// Apply saved page size to dropdown on load
window.addEventListener('DOMContentLoaded', () => {
    const sel = document.getElementById('pageSizeSelect');
    if(sel){ sel.value = String(pageSize); }
});

function renderPagination(){
    const pagDiv = document.getElementById('pagination');
    if(!pagDiv) return;
    const totalPages = Math.ceil(filteredProducts.length / pageSize);
    if(totalPages<=1){pagDiv.innerHTML=''; return;}
    let html='';
    // Previous button
    html += `<li class="page-item ${currentPage===1?'disabled':''}"><a class="page-link" href="#" aria-label="Previous" onclick="${currentPage===1?'return false;':'renderPage('+(currentPage-1)+');return false;'}">&laquo;</a></li>`;
    for(let p=1;p<=totalPages;p++){
        html += `<li class="page-item ${p===currentPage?'active':''}"><a class="page-link" href="#" onclick="renderPage(${p});return false;">${p}</a></li>`;
    }
    // Next button
    html += `<li class="page-item ${currentPage===totalPages?'disabled':''}"><a class="page-link" href="#" aria-label="Next" onclick="${currentPage===totalPages?'return false;':'renderPage('+(currentPage+1)+');return false;'}">&raquo;</a></li>`;
    pagDiv.innerHTML = `<nav><ul class="pagination pagination-sm justify-content-center">${html}</ul></nav>`;
}

function populateProductFilterOptions(prodList) {
    const catSel = document.getElementById('filterCategory');
    const brandSel = document.getElementById('filterBrand');
    if (!catSel || !brandSel) return;
    const categories = [...new Set(prodList.map(p => p.category_name))].sort();
    const brands = [...new Set(prodList.map(p => p.brand_name))].sort();
    catSel.innerHTML = '<option value="">All Categories</option>' + categories.map(c => `<option value="${c}">${c}</option>`).join('');
    brandSel.innerHTML = '<option value="">All Brands</option>' + brands.map(b => `<option value="${b}">${b}</option>`).join('');
}

function applyProductFilters() {
    const cat = document.getElementById('filterCategory')?.value || '';
    const brand = document.getElementById('filterBrand')?.value || '';
    const minPriceVal = document.getElementById('filterMinPrice')?.value;
    const maxPriceVal = document.getElementById('filterMaxPrice')?.value;
    const minPrice = minPriceVal ? parseFloat(minPriceVal) : 0;
    const maxPrice = maxPriceVal ? parseFloat(maxPriceVal) : Infinity;
    let filtered = products.filter(p =>
        (!cat || p.category_name === cat) &&
        (!brand || p.brand_name === brand) &&
        (isNaN(minPrice) || p.price >= minPrice) &&
        (isNaN(maxPrice) || p.price <= maxPrice)
    );
    
    // Apply sorting
    const sortVal = document.getElementById('sortSelect')?.value || '';
    switch (sortVal) {
        case 'price_asc':
            filtered = filtered.sort((a,b)=>a.price - b.price);
            break;
        case 'price_desc':
            filtered = filtered.sort((a,b)=>b.price - a.price);
            break;
        case 'name_asc':
            filtered = filtered.sort((a,b)=>a.name.localeCompare(b.name));
            break;
        case 'name_desc':
            filtered = filtered.sort((a,b)=>b.name.localeCompare(a.name));
            break;
        default:
            break;
    }
    filteredProducts = filtered;
    renderPage(1);
}

function clearProductFilters() {
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterBrand').value = '';
    document.getElementById('filterMinPrice').value = '';
    document.getElementById('filterMaxPrice').value = '';
    document.getElementById('productSearch').value = '';
    filteredProducts = products;
    document.getElementById('sortSelect').value='';
    renderPage(1);
}

async function showProductForm(productId = null) {
    // Load categories and brands for dropdowns
    await Promise.all([
        loadCategoriesForProductDropdown(),
        loadBrandsForProductDropdown()
    ]);
    
    const modal = new bootstrap.Modal(document.getElementById('productModal'));
    const title = document.getElementById('productModalTitle');
    const nameInput = document.getElementById('productName');
    const brandSelect = document.getElementById('productBrand');
    const categorySelect = document.getElementById('productCategory');
    const priceInput = document.getElementById('productPrice');
    const imageInput = document.getElementById('productImage');
    const descriptionInput = document.getElementById('productDescription');
    const stockInput = document.getElementById('productStock');
    const idInput = document.getElementById('productId');
    
    if (productId) {
        title.textContent = 'Edit Product';
        const product = products.find(p => p.id === productId);
        if (product) {
            nameInput.value = product.name;
            brandSelect.value = product.brand_id;
            priceInput.value = product.price;
            stockInput.value = product.stock;
            imageInput.value = product.image_url || ''; // set image URL
            descriptionInput.value = product.description || '';
            imageInput.value = product.image_url || ''; // set image URL
            idInput.value = product.id;
            
            // Set category based on brand
            const brand = brands.find(b => b.id === product.brand_id);
            if (brand) {
                categorySelect.value = brand.category_id;
            }
        }
    } else {
        title.textContent = 'Add Product';
        nameInput.value = '';
        brandSelect.value = '';
        categorySelect.value = '';
        priceInput.value = '';
        descriptionInput.value = '';
        imageInput.value = '';
         stockInput.value = '';
        idInput.value = '';
    }
    
    modal.show();
}

async function loadCategoriesForProductDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        const data = await response.json();
        if (data.success) {
            const categorySelect = document.getElementById('productCategory');
            categorySelect.innerHTML = '<option value="">Select Category</option>' +
                data.data.map(category => 
                    `<option value="${category.id}">${category.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

async function loadBrandsForProductDropdown() {
    try {
        const response = await fetch(`${API_BASE_URL}/brands`);
        const data = await response.json();
        if (data.success) {
            const brandSelect = document.getElementById('productBrand');
            brandSelect.innerHTML = '<option value="">Select Brand</option>' +
                data.data.map(brand => 
                    `<option value="${brand.id}">${brand.name} (${brand.category_name})</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading brands:', error);
    }
}

async function loadBrandsByCategory() {
    const categorySelect = document.getElementById('productCategory');
    const brandSelect = document.getElementById('productBrand');
    const categoryId = categorySelect.value;
    
    if (!categoryId) {
        brandSelect.innerHTML = '<option value="">Select Brand</option>';
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/brands/category/${categoryId}`);
        const data = await response.json();
        if (data.success) {
            brandSelect.innerHTML = '<option value="">Select Brand</option>' +
                data.data.map(brand => 
                    `<option value="${brand.id}">${brand.name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading brands by category:', error);
    }
}

async function saveProduct() {
    const nameInput = document.getElementById('productName');
    const brandSelect = document.getElementById('productBrand');
    const priceInput = document.getElementById('productPrice');
    const imageInput = document.getElementById('productImage');
    const descriptionInput = document.getElementById('productDescription');
    const stockInput = document.getElementById('productStock');
    const idInput = document.getElementById('productId');
    
    const name = nameInput.value.trim();
    const brandId = brandSelect.value;
    const price = parseFloat(priceInput.value);
    const description = descriptionInput.value.trim();
    const stock = parseInt(stockInput.value);
    const image_url = imageInput.value.trim();
    
    if (!name || !brandId || !price || price <= 0 || stock<0 || isNaN(stock)) {
        showAlert('Product name, brand, and valid price are required', 'warning');
        return;
    }
    
    try {
        const url = idInput.value ? 
            `${API_BASE_URL}/products/${idInput.value}` : 
            `${API_BASE_URL}/products`;
        
        const method = idInput.value ? 'PUT' : 'POST';
        
        const response = await authFetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ 
                name, 
                brand_id: parseInt(brandId),
                price,
                description: description || null,
                image_url: image_url || null,
                 stock
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            bootstrap.Modal.getInstance(document.getElementById('productModal')).hide();
            loadProducts();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error saving product', 'danger');
    }
}

async function editProduct(id) {
    showProductForm(id);
}

async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this product?')) {
        return;
    }
    
    try {
        const response = await authFetch(`${API_BASE_URL}/products/${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showAlert(data.message, 'success');
            loadProducts();
            if (currentSection === 'dashboard') loadDashboard();
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error deleting product', 'danger');
    }
}

async function searchProducts() {
    const searchInput = document.getElementById('productSearch');
    const searchTerm = searchInput.value.trim();
    
    if (!searchTerm) {
        loadProducts();
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/products/search?q=${encodeURIComponent(searchTerm)}`);
        const data = await response.json();
        if (data.success) {
            displayProducts(data.data);
        } else {
            showAlert(data.message, 'danger');
        }
    } catch (error) {
        showAlert('Error searching products', 'danger');
    }
}

// Utility functions
function showAlert(message, type = 'info') {
    let alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) {
        // create at top of body if not present
        const div = document.createElement('div');
        div.id = 'alertContainer';
        div.className = 'position-fixed top-0 start-50 translate-middle-x p-3';
        div.style.zIndex = '1080';
        document.body.prepend(div);
        alertContainer = div;
    }
    const alertId = 'alert-' + Date.now();
    
    const alertHtml = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    alertContainer.innerHTML = alertHtml;
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = document.getElementById(alertId);
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

window.addToCart = addToCart;
window.showAlert = showAlert;

// Loading spinner utility
function showLoading(targetId = 'alertContainer') {
    const el = document.getElementById(targetId);
    if (el) {
        el.innerHTML = '<div class="d-flex justify-content-center my-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>';
    }
}
function hideLoading(targetId = 'alertContainer') {
    const el = document.getElementById(targetId);
    if (el) el.innerHTML = '';
}



document.addEventListener('DOMContentLoaded', () => {
  // Toggle admin-only UI blocks
  document.querySelectorAll('.admin-only').forEach(el => {
    el.classList.toggle('d-none', !isAdminUser);
  });
  if (isAdminUser) {
    import('./adminDashboard.js');
  }
  // Hide admin links for non-admins
  if (!isAdminUser) {
    document.querySelectorAll('.nav-item-admin').forEach(el => el.style.display = 'none');
    // Hide add buttons in products header
    const addBtn = document.getElementById('addProductBtn');
  }
});

// Add to Cart function
function addToCart(productId, quantity = 1) {
    if (!isLoggedIn()) {
      window.location.href = 'login.html';
      return;
    }
    
    // Use a temporary loading element to avoid conflicts with modal loading states
    const tempLoadingId = 'temp-cart-loading-' + Date.now();
    const tempDiv = document.createElement('div');
    tempDiv.id = tempLoadingId;
    tempDiv.style.position = 'fixed';
    tempDiv.style.top = '50%';
    tempDiv.style.left = '50%';
    tempDiv.style.transform = 'translate(-50%, -50%)';
    tempDiv.style.zIndex = '9999';
    tempDiv.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
    tempDiv.style.padding = '20px';
    tempDiv.style.borderRadius = '8px';
    tempDiv.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    document.body.appendChild(tempDiv);
    
    showLoading(tempLoadingId);
    
    authFetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: productId, quantity })
    })
      .then(async res => {
        if(res.status===401){
          document.body.removeChild(tempDiv);
          showAlert('Session expired. Please login again.','warning');
          await logout(); // from auth.js exposes logout to window
          return Promise.reject('unauth');
        }
        return res.json();
      })
      .then(data => {
        document.body.removeChild(tempDiv);
        if (data.success) {
          showAlert('Added to cart!', 'success');
          const cartIcon = document.querySelector('.bi-cart3');
          if (cartIcon){
            cartIcon.classList.add('cart-shake');
            setTimeout(()=>cartIcon.classList.remove('cart-shake'),400);
          }
        } else {
          showAlert(data.message || 'Failed to add to cart.', 'danger');
        }
      })
      .catch(() => {
        if (document.body.contains(tempDiv)) {
          document.body.removeChild(tempDiv);
        }
        showAlert('Server error. Please try again.', 'danger');
      });
  }
  
  // Load product details & reviews
  function showProductDetails(productId) {
    import('./review.js').then(({ loadReviews, loadAverageRating }) => {
      loadReviews(productId);
      loadAverageRating(productId);
    });
  }
  

// Global functions for onclick handlers
// Attach all global functions to window for HTML access
window.showSection = showSection;
window.showCategoryForm = showCategoryForm;
window.saveCategory = saveCategory;
window.editCategory = editCategory;
window.deleteCategory = deleteCategory;
window.showBrandForm = showBrandForm;
window.saveBrand = saveBrand;
window.editBrand = editBrand;
window.deleteBrand = deleteBrand;
window.showProductForm = showProductForm;
window.saveProduct = saveProduct;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.searchProducts = searchProducts;
window.loadBrandsByCategory = loadBrandsByCategory;
function toggleWishlist(productId, btn) {
    if (!isLoggedIn()) {
        window.location.href = 'login.html';
        return;
    }
    let list = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const idx = list.indexOf(productId);
    if (idx === -1) {
        list.push(productId);
        if (btn) btn.querySelector('i').classList.add('bi-heart-fill');
        showAlert('Added to wishlist!', 'success');
    } else {
        list.splice(idx, 1);
        if (btn) btn.querySelector('i').classList.remove('bi-heart-fill');
        showAlert('Removed from wishlist', 'info');
    }
    localStorage.setItem('wishlist', JSON.stringify(list));
}

// Compare functionality
function getCompareList() {
    try {
        return JSON.parse(localStorage.getItem('compareList')) || [];
    } catch {
        return [];
    }
}

function saveCompareList(list) {
    localStorage.setItem('compareList', JSON.stringify(list));
    updateCompareCount();
}

function updateCompareCount() {
    const count = getCompareList().length;
    const countSpan = document.getElementById('compareCount');
    if (countSpan) {
        countSpan.textContent = count;
    }
}

function toggleCompare(productId, btn) {
    let compareList = getCompareList();
    const index = compareList.indexOf(productId);
    
    if (index === -1) {
        if (compareList.length >= 4) {
            showAlert('You can compare up to 4 products only.', 'warning');
            return;
        }
        compareList.push(productId);
        btn.classList.remove('btn-outline-info');
        btn.classList.add('btn-info');
        btn.innerHTML = '<i class="bi bi-check2"></i>';
        
        // Save first, then check length
        const newLength = compareList.length;
        saveCompareList(compareList);
        
        // Auto-open compare modal when second product is selected
        if (newLength === 2) {
            showAlert('Comparison ready! Opening comparison view...', 'success');
            setTimeout(() => {
                openCompareModal();
            }, 800);
        } else if (newLength === 1) {
            showAlert('Product added to comparison. Select one more to view comparison!', 'info');
        } else if (newLength > 2) {
            showAlert('Product added to comparison!', 'success');
            // Update modal if it's already open
            const modal = document.getElementById('compareModal');
            if (modal && modal.classList.contains('show')) {
                setTimeout(() => loadComparisonInModal(), 200);
            }
        }
    } else {
        compareList.splice(index, 1);
        btn.classList.remove('btn-info');
        btn.classList.add('btn-outline-info');
        btn.innerHTML = '<i class="bi bi-arrow-left-right"></i>';
        saveCompareList(compareList);
        
        if (compareList.length === 0) {
            showAlert('Product removed from comparison', 'info');
        } else {
            showAlert('Product removed from comparison', 'info');
        }
    }
    
    // Update modal if it's open
    const modal = document.getElementById('compareModal');
    if (modal && modal.classList.contains('show')) {
        loadComparisonInModal();
    }
}

// Compare modal functions
async function openCompareModal() {
    const compareList = getCompareList();
    const modal = new bootstrap.Modal(document.getElementById('compareModal'));
    
    if (compareList.length === 0) {
        showAlert('No products selected for comparison. Click the arrow buttons on product cards to add them.', 'info');
        return;
    }
    
    modal.show();
    await loadComparisonInModal();
}

async function loadComparisonInModal() {
    const compareList = getCompareList();
    const container = document.getElementById('compareContent');
    
    if (compareList.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="bi bi-arrow-left-right display-1 text-muted"></i>
                <h4 class="mt-3">No products selected</h4>
                <p class="text-muted">Click the arrow buttons on product cards to add them for comparison.</p>
            </div>
        `;
        return;
    }
    
    if (compareList.length === 1) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="bi bi-arrow-left-right display-1 text-info"></i>
                <h4 class="mt-3">Select one more product</h4>
                <p class="text-muted">You need at least 2 products to compare. Click arrow buttons on more product cards.</p>
                <div class="mt-4">
                    <span class="badge bg-info fs-6">1 product selected</span>
                </div>
            </div>
        `;
        return;
    }

    try {
        container.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2">Loading comparison...</p></div>';
        
        // Fetch product details for all items in compare list
        const productPromises = compareList.map(id => 
            fetch(`/api/products/${id}`).then(res => res.json())
        );
        
        const responses = await Promise.all(productPromises);
        const products = responses
            .filter(res => res.success)
            .map(res => res.product || res.data);

        if (products.length === 0) {
            container.innerHTML = `
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i>
                    Failed to load comparison products. Please try again.
                </div>
            `;
            return;
        }

        renderComparisonInModal(products);
    } catch (error) {
        console.error('Error loading comparison:', error);
        container.innerHTML = `
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-circle"></i>
                Error loading products for comparison.
            </div>
        `;
    }
}

function renderComparisonInModal(products) {
    const container = document.getElementById('compareContent');
    
    const tableHTML = `
        <div class="table-responsive">
            <table class="table table-bordered bg-white">
                <thead class="table-light">
                    <tr>
                        <th style="width: 150px;">Specification</th>
                        ${products.map(p => `
                            <th class="text-center" style="min-width: 200px;">
                                <div class="position-relative">
                                    <button class="btn btn-sm btn-outline-danger position-absolute top-0 end-0" 
                                            onclick="removeFromComparisonModal(${p.id})" title="Remove">
                                        <i class="bi bi-x"></i>
                                    </button>
                                    <img src="${p.image_url || 'https://via.placeholder.com/150'}" 
                                         class="img-fluid mb-2" style="height: 80px; object-fit: cover;" alt="${p.name}">
                                    <h6 class="mb-1 small">${p.name}</h6>
                                    <p class="text-danger fw-bold mb-0 small">$${parseFloat(p.price).toLocaleString('en-US')}</p>
                                </div>
                            </th>
                        `).join('')}
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-bold">Price</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <span class="fs-6 text-danger fw-bold">$${parseFloat(p.price).toLocaleString('en-US')}</span>
                            </td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Category</td>
                        ${products.map(p => `
                            <td class="text-center small">${p.category_name || 'N/A'}</td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Brand</td>
                        ${products.map(p => `
                            <td class="text-center small">${p.brand_name || 'N/A'}</td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Stock</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <span class="badge bg-${p.stock > 0 ? 'success' : 'secondary'} small">
                                    ${p.stock > 0 ? 'In Stock' : 'Out of Stock'}
                                </span>
                            </td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Actions</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <div class="d-grid gap-1">
                                    <a href="product.html?id=${p.id}" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-eye"></i> View
                                    </a>
                                    ${p.stock > 0 ? `
                                        <button class="btn btn-success btn-sm" onclick="window.addToCart && window.addToCart(${p.id})">
                                            <i class="bi bi-cart-plus"></i> Add to Cart
                                        </button>
                                    ` : `
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            Out of Stock
                                        </button>
                                    `}
                                </div>
                            </td>
                        `).join('')}
                    </tr>
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = tableHTML;
}

function removeFromComparisonModal(productId) {
    let compareList = getCompareList();
    compareList = compareList.filter(id => id !== productId);
    saveCompareList(compareList);
    
    // Update product card button state
    const productCards = document.querySelectorAll('.compare-btn');
    productCards.forEach(btn => {
        if (btn.onclick && btn.onclick.toString().includes(productId)) {
            btn.classList.remove('btn-info');
            btn.classList.add('btn-outline-info');
            btn.innerHTML = '<i class="bi bi-arrow-left-right"></i>';
        }
    });
    
    loadComparisonInModal();
}

function clearComparison() {
    localStorage.removeItem('compareList');
    updateCompareCount();
    
    // Reset all compare buttons
    const compareButtons = document.querySelectorAll('.compare-btn');
    compareButtons.forEach(btn => {
        btn.classList.remove('btn-info');
        btn.classList.add('btn-outline-info');
        btn.innerHTML = '<i class="bi bi-arrow-left-right"></i>';
    });
    
    loadComparisonInModal();
    showAlert('Comparison cleared', 'info');
}

function clearComparisonOnClose() {
    localStorage.removeItem('compareList');
    updateCompareCount();
    
    // Reset all compare buttons
    const compareButtons = document.querySelectorAll('.compare-btn');
    compareButtons.forEach(btn => {
        btn.classList.remove('btn-info');
        btn.classList.add('btn-outline-info');
        btn.innerHTML = '<i class="bi bi-arrow-left-right"></i>';
    });
    
    showAlert('Comparison cleared', 'info');
}

window.toggleWishlist = toggleWishlist;
window.toggleCompare = toggleCompare;
window.openCompareModal = openCompareModal;
window.removeFromComparisonModal = removeFromComparisonModal;
window.clearComparison = clearComparison;
window.clearComparisonOnClose = clearComparisonOnClose;
window.addToCart = addToCart;
function viewProduct(id){
    window.location.href = `product.html?id=${id}`;
}
window.viewProduct = viewProduct;
async function loadCart() {
    if (!isLoggedIn() || isAdminUser) {
        if (isAdminUser) {
            showAlert('Cart is available only for customer accounts.', 'info');
            return;
        }
        window.location.href = 'login.html';
        return;
    }
    try {
        const res = await authFetch('/api/cart');
        const data = await res.json();
        if (data.success) {
            renderCart(data.cart || []);
            const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
            cartModal.show();
        } else {
            showAlert(data.message || 'Failed to load cart', 'danger');
        }
    } catch (err) {
        showAlert('Server error', 'danger');
    }
}

function renderCart(items) {
    const body = document.getElementById('cartItemsBody');
    if (!body) return;
    if (!items.length) {
         body.innerHTML = '<tr><td colspan="5" class="text-center">Cart is empty</td></tr>';
         document.getElementById('cartTotal').textContent = '$0.00';
         const checkoutBtn = document.getElementById('checkoutBtn');
         if (checkoutBtn) checkoutBtn.classList.add('disabled');
         return;
     }
    body.innerHTML = items
        .map(it => `<tr>
            <td>${it.product_name}</td>
            <td class="d-flex align-items-center gap-2">
                <button class="btn btn-sm btn-outline-secondary" onclick="changeCartQty(${it.product_id}, -1)"><i class="bi bi-dash"></i></button>
                <span>${it.quantity}</span>
                <button class="btn btn-sm btn-outline-secondary" onclick="changeCartQty(${it.product_id}, 1)"><i class="bi bi-plus"></i></button>
            </td>
            <td>$${parseFloat(it.price).toFixed(2)}</td>
            <td>$${(it.price * it.quantity).toFixed(2)}</td>
            <td><button class="btn btn-sm btn-link text-danger" onclick="removeFromCart(${it.product_id})"><i class="bi bi-trash"></i></button></td>
        </tr>`)
        .join('');
    const total = items.reduce((sum, it) => sum + it.price * it.quantity, 0);
    // Enable checkout button as cart has items now
    const checkoutBtn = document.getElementById('checkoutBtn');
    if (checkoutBtn) checkoutBtn.classList.remove('disabled');
    document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

async function changeCartQty(productId, delta) {
    const rowSpan = event?.target?.closest('tr');
    try {
        // find current qty from span text
        const currentQty = parseInt(rowSpan.querySelector('span').textContent);
        const newQty = currentQty + delta;
        if (newQty < 1) return; // do nothing if would go 0
        const res = await authFetch('/api/cart/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId, quantity: newQty })
        });
        const data = await res.json();
        if (data.success) {
            // update UI without full reload for speed
            rowSpan.querySelector('span').textContent = newQty;
            const price = parseFloat(rowSpan.children[2].textContent.replace('$',''));
            rowSpan.children[3].textContent = `$${(price*newQty).toFixed(2)}`;
            // recalc total
            recalcCartTotal();
        } else {
            showAlert(data.message || 'Failed to update', 'danger');
        }
    } catch(err) {
        showAlert('Server error', 'danger');
    }
}

function recalcCartTotal() {
    const rows = Array.from(document.querySelectorAll('#cartItemsBody tr'));
    const total = rows.reduce((sum, r) => sum + parseFloat(r.children[3].textContent.replace('$','')), 0);
    document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;
}

async function removeFromCart(productId) {
    try {
        showLoading('cartItemsBody');
        const res = await authFetch('/api/cart/remove', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: productId })
        });
        const data = await res.json();
        hideLoading('cartItemsBody');
        if (data.success) {
            showAlert('Item removed from cart', 'success');
            // Reload cart data without opening modal again
            const cartRes = await authFetch('/api/cart');
            const cartData = await cartRes.json();
            if (cartData.success) {
                renderCart(cartData.cart || []);
            }
        } else {
            showAlert(data.message || 'Failed to remove', 'danger');
        }
    } catch (err) {
        hideLoading('cartItemsBody');
        showAlert('Server error', 'danger');
    }
}

window.removeFromCart = removeFromCart;
window.loadCart = loadCart;
window.applyProductFilters = applyProductFilters;
window.clearProductFilters = clearProductFilters;
window.showProductDetails = showProductDetails;

// ------------ Wishlist functions -------------
async function loadWishlist() {
    const list = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const tbody = document.getElementById('wishlistBody');
    if (!list.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="text-center">Your wishlist is empty</td></tr>';
    } else {
        // ensure global products array exists
        if(!window.products) window.products = [];
        // fetch missing product details
        const missingIds = list.filter(id=>!products.find(p=>p.id===id));
        for(const id of missingIds){
          try{
            const res = await fetch(`/api/products/${id}`);
            const data = await res.json();
            if(data.success) products.push(data.product || data.data);
          }catch{}
        }
        const rows = list.map(id => {
            const prod = products.find(p => p.id === id);
            if (!prod) return '';
            return `<tr>
                <td><input type="checkbox" value="${prod.id}" class="form-check-input wishlist-checkbox"></td>
                <td>${prod.name}</td>
                <td>$${parseFloat(prod.price).toFixed(2)}</td>
                <td><button type="button" class="btn btn-link text-danger p-0" onclick="removeWishlistItem(${prod.id})"><i class="bi bi-trash"></i></button></td>
            </tr>`;
        }).join('');
        tbody.innerHTML = rows || '<tr><td colspan="4" class="text-center">Items unavailable</td></tr>';
    }
    new bootstrap.Modal(document.getElementById('wishlistModal')).show();
}

async function moveWishlistToCart() {
    const checked = Array.from(document.querySelectorAll('.wishlist-checkbox:checked')).map(cb => parseInt(cb.value));
    if (!checked.length) {
        showAlert('Select at least one item.', 'info');
        return;
    }
    
    try {
        // Show loading indicator
        showLoading('wishlistBody');
        
        // Move items to cart with proper error handling
        const movePromises = checked.map(async (id) => {
            try {
                const response = await authFetch('/api/cart/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ product_id: id, quantity: 1 })
                });
                const data = await response.json();
                if (!data.success) {
                    console.warn(`Failed to add product ${id} to cart:`, data.message);
                }
                return data.success;
            } catch (error) {
                console.error(`Error adding product ${id} to cart:`, error);
                return false;
            }
        });
        
        // Wait for all operations to complete
        const results = await Promise.all(movePromises);
        const successCount = results.filter(success => success).length;
        
        // Hide loading indicator
        hideLoading('wishlistBody');
        
        // remove moved ids from wishlist
        let list = JSON.parse(localStorage.getItem('wishlist') || '[]');
        list = list.filter(id => !checked.includes(id));
        localStorage.setItem('wishlist', JSON.stringify(list));
        
        // Close modal to remove backdrop
        const wishlistModalEl = document.getElementById('wishlistModal');
        const wishlistModal = wishlistModalEl ? bootstrap.Modal.getInstance(wishlistModalEl) : null;
        wishlistModal?.hide();
        // Refresh cart contents so checkout button becomes active
        loadCart();

        // Show appropriate success message
        if (successCount === checked.length) {
            showAlert('All items moved to cart!', 'success');
        } else if (successCount > 0) {
            showAlert(`${successCount} of ${checked.length} items moved to cart`, 'warning');
        } else {
            showAlert('Failed to move items to cart. Please try again.', 'danger');
        }
        
        loadWishlist(); // refresh view
    } catch (error) {
        // Close modal to remove backdrop even on error
        const wishlistModalEl = document.getElementById('wishlistModal');
        const wishlistModal = wishlistModalEl ? bootstrap.Modal.getInstance(wishlistModalEl) : null;
        wishlistModal?.hide();
        // Ensure loading indicator is hidden on error
        hideLoading('wishlistBody');
        console.error('Error moving wishlist items to cart:', error);
        showAlert('Error moving items to cart. Please try again.', 'danger');
    }
}

window.loadWishlist = loadWishlist;
window.moveWishlistToCart = moveWishlistToCart;
function removeWishlistItem(id){
  let list = JSON.parse(localStorage.getItem('wishlist')||'[]');
  list = list.filter(pid=>pid!==id);
  localStorage.setItem('wishlist',JSON.stringify(list));
  loadWishlist();

  // update stats if on profile page
  const statElem = document.getElementById('statWishlist');
  if(statElem) statElem.textContent = list.length;
}
window.changeCartQty = changeCartQty;
window.recalcCartTotal = recalcCartTotal;