// auth.js - handles authentication state and token management

export function getAccessToken() {
  return localStorage.getItem('accessToken');
}
export function getRefreshToken() {
  return localStorage.getItem('refreshToken');
}
export function getUser() {
  try {
    return JSON.parse(localStorage.getItem('user'));
  } catch {
    return null;
  }
}
export function isLoggedIn() {
  return !!getAccessToken();
}
export function isAdmin() {
  const user = getUser();
  return user && user.role === 'admin';
}
export function isUser() {
  const user = getUser();
  return user && user.role === 'user';
}
export async function logout() {
  try{
    await fetch('/api/users/logout', {method:'POST', headers:{'Content-Type':'application/json', 'Authorization':'Bearer '+getAccessToken()}});
  }catch(err){console.warn('logout req failed',err.message);}
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  localStorage.removeItem('user');
  window.location.href = '/';
}
export function authFetch(url, options = {}) {
  const token = getAccessToken();
  options.headers = options.headers || {};
  if (token) {
    options.headers['Authorization'] = 'Bearer ' + token;
  }
  return fetch(url, options);
}

// expose to global window for non-module scripts
if (typeof window !== 'undefined') {
  window.getUser = getUser;
  window.getAccessToken = getAccessToken;
  window.isLoggedIn = isLoggedIn;
  window.authFetch = authFetch;
  window.logout = logout;
} 