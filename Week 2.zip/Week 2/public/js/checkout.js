// Checkout JavaScript
import { getAccessToken, isLoggedIn, authFetch } from './auth.js';

// Check authentication
if (!isLoggedIn()) {
    window.location.href = 'login.html';
}

const accessToken = getAccessToken();
let cart = [];
let currentStep = 1;
let orderData = {
    shipping: {},
    payment: {},
    items: [],
    total: 0
};

// Initialize checkout
document.addEventListener('DOMContentLoaded', function() {
    loadCart();
    setupEventListeners();
});

function setupEventListeners() {
    // Payment method change
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', togglePaymentForm);
    });

    // Same as billing checkbox
    document.getElementById('sameAsBilling').addEventListener('change', function() {
        // Could implement billing form toggle here
    });

    // Form validation
    document.getElementById('shippingForm').addEventListener('submit', function(e) {
        e.preventDefault();
        if (validateShippingForm()) {
            nextStep(2);
        }
    });
}

// Load cart data
async function loadCart() {
    try {
        const response = await authFetch('/api/cart');
        const data = await response.json();
        
        if (data.success) {
            cart = data.cart;
            if (cart.length === 0) {
                showToast('Your cart is empty. Redirecting to products...', 'warning');
                setTimeout(() => window.location.href = 'index.html', 2000);
                return;
            }
            renderOrderSummary();
        } else {
            showToast('Failed to load cart', 'danger');
        }
    } catch (error) {
        console.error('Error loading cart:', error);
        showToast('Error loading cart', 'danger');
    }
}

// Render order summary
function renderOrderSummary() {
    const container = document.getElementById('orderSummary');
    let subtotal = 0;
    
    const itemsHtml = cart.map(item => {
        const price = parseFloat(item.price);
        const itemTotal = price * item.quantity;
        subtotal += itemTotal;
        return `
            <div class="d-flex justify-content-between align-items-center mb-2">
                <div>
                    <div class="fw-medium">${item.product_name}</div>
                    <small class="text-muted">Qty: ${item.quantity} × $${price.toFixed(2)}</small>
                </div>
                <div class="fw-medium">$${itemTotal.toFixed(2)}</div>
            </div>
        `;
    }).join('');

    const shipping = 9.99; // Fixed shipping cost
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + shipping + tax;

    container.innerHTML = `
        <div class="order-items mb-3">
            ${itemsHtml}
        </div>
        <hr>
        <div class="d-flex justify-content-between mb-2">
            <span>Subtotal:</span>
            <span>$${subtotal.toFixed(2)}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Shipping:</span>
            <span>$${shipping.toFixed(2)}</span>
        </div>
        <div class="d-flex justify-content-between mb-2">
            <span>Tax:</span>
            <span>$${tax.toFixed(2)}</span>
        </div>
        <hr>
        <div class="d-flex justify-content-between fw-bold h5">
            <span>Total:</span>
            <span>$${total.toFixed(2)}</span>
        </div>
    `;

    // Update order data
    orderData.items = cart;
    orderData.subtotal = subtotal;
    orderData.shipping = shipping;
    orderData.tax = tax;
    orderData.total = total;
}

// Step navigation
function nextStep(step) {
    if (step === 2 && !validateShippingForm()) {
        return;
    }
    if (step === 3 && !validatePaymentForm()) {
        return;
    }

    // Hide current step
    document.getElementById(`step-${currentStep}`).classList.add('d-none');
    
    // Show next step
    document.getElementById(`step-${step}`).classList.remove('d-none');
    
    // Update progress
    updateProgress(step);
    
    // Load step-specific content
    if (step === 3) {
        renderOrderReview();
    }
    
    currentStep = step;
}

function prevStep(step) {
    // Hide current step
    document.getElementById(`step-${currentStep}`).classList.add('d-none');
    
    // Show previous step
    document.getElementById(`step-${step}`).classList.remove('d-none');
    
    // Update progress
    updateProgress(step);
    
    currentStep = step;
}

function updateProgress(step) {
    // Remove active class from all steps
    document.querySelectorAll('.step').forEach(s => {
        s.classList.remove('active', 'completed');
    });
    
    // Mark completed steps
    for (let i = 1; i < step; i++) {
        document.querySelector(`[data-step="${i}"]`).classList.add('completed');
    }
    
    // Mark current step as active
    document.querySelector(`[data-step="${step}"]`).classList.add('active');
}

// Form validation
function validateShippingForm() {
    const form = document.getElementById('shippingForm');
    const formData = new FormData(form);
    let valid = true;

    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'address', 'city', 'state', 'zipCode'];
    requiredFields.forEach(name=>{
        const input = form.querySelector(`[name="${name}"]`);
        if(!input) return;
        const value = formData.get(name).trim();
        if(!value){
          input.classList.add('is-invalid');
          valid = false;
        }else{
          input.classList.remove('is-invalid');
        }
    });

    if(!valid) return false;

    // Save shipping data
    orderData.shipping = Object.fromEntries(formData);
    return true;
}

function validatePaymentForm() {
    const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
    orderData.payment.method = paymentMethod;
    
    if (paymentMethod === 'credit_card') {
        // Validate credit card fields (simplified)
        const cardNumber = document.querySelector('#creditCardForm input[placeholder*="1234"]').value;
        const expiry = document.querySelector('#creditCardForm input[placeholder*="MM/YY"]').value;
        const cvv = document.querySelector('#creditCardForm input[placeholder*="123"]').value;
        const cardholderName = document.querySelector('#creditCardForm input[placeholder*="John Doe"]').value;
        
        if (!cardNumber || !expiry || !cvv || !cardholderName) {
            showToast('Please fill in all credit card details', 'warning');
            return false;
        }
        
        orderData.payment.cardDetails = {
            cardNumber: cardNumber.replace(/\s/g, ''),
            expiry,
            cvv,
            cardholderName
        };
    }
    
    return true;
}

// Toggle payment form
function togglePaymentForm() {
    const selectedMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
    const creditCardForm = document.getElementById('creditCardForm');
    
    if (selectedMethod === 'credit_card') {
        creditCardForm.classList.remove('d-none');
    } else {
        creditCardForm.classList.add('d-none');
    }
}

// Render order review
function renderOrderReview() {
    const container = document.getElementById('orderReview');
    
    const shippingHtml = `
        <div class="mb-4">
            <h6><i class="bi bi-truck"></i> Shipping Address</h6>
            <div class="bg-light p-3 rounded">
                <div>${orderData.shipping.firstName} ${orderData.shipping.lastName}</div>
                <div>${orderData.shipping.address}</div>
                <div>${orderData.shipping.city}, ${orderData.shipping.state} ${orderData.shipping.zipCode}</div>
                <div>${orderData.shipping.phone}</div>
                <div>${orderData.shipping.email}</div>
            </div>
        </div>
    `;
    
    const paymentHtml = `
        <div class="mb-4">
            <h6><i class="bi bi-credit-card"></i> Payment Method</h6>
            <div class="bg-light p-3 rounded">
                ${getPaymentMethodDisplay(orderData.payment.method)}
            </div>
        </div>
    `;
    
    const itemsHtml = `
        <div class="mb-4">
            <h6><i class="bi bi-box"></i> Order Items</h6>
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${cart.map(item => {
                            const priceNum = parseFloat(item.price);
                            return `
                                <tr>
                                    <td>${item.product_name}</td>
                                    <td>${item.quantity}</td>
                                    <td>$${priceNum.toFixed(2)}</td>
                                    <td>$${(priceNum * item.quantity).toFixed(2)}</td>
                                </tr>`;
                        }).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    container.innerHTML = shippingHtml + paymentHtml + itemsHtml;
}

function getPaymentMethodDisplay(method) {
    switch (method) {
        case 'credit_card':
            return `<i class="bi bi-credit-card"></i> Credit/Debit Card ending in ${orderData.payment.cardDetails?.cardNumber.slice(-4) || '****'}`;
        case 'paypal':
            return '<i class="bi bi-paypal"></i> PayPal';
        case 'cod':
            return '<i class="bi bi-cash"></i> Cash on Delivery';
        default:
            return method;
    }
}

// Place order
async function placeOrder() {
    try {
        showLoading();
        
        const orderPayload = {
            items: orderData.items.map(item => ({
                product_id: item.product_id,
                quantity: item.quantity,
                price: parseFloat(item.price)
            })),
            total_amount: orderData.total,
            shipping_address: orderData.shipping,
            payment_method: orderData.payment.method,
            subtotal: orderData.subtotal,
            shipping_cost: orderData.shipping,
            tax_amount: orderData.tax
        };
        
        const response = await authFetch('/api/orders/place', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderPayload)
        });
        
        const data = await response.json();
        hideLoading();
        
        if (data.success) {
            // Clear cart
            await clearCart();
            
            // Show confirmation
            showConfirmation(data.order);
            nextStep(4);
        } else {
            showToast(data.message || 'Failed to place order', 'danger');
        }
    } catch (error) {
        hideLoading();
        console.error('Error placing order:', error);
        showToast('Error placing order. Please try again.', 'danger');
    }
}

// Clear cart after successful order
async function clearCart() {
    try {
        await fetch('/api/cart/clear', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + accessToken }
        });
    } catch (error) {
        console.error('Error clearing cart:', error);
    }
}

// Show order confirmation
function showConfirmation(order) {
    const container = document.getElementById('confirmationDetails');
    
    container.innerHTML = `
        <div class="mb-4">
            <h3 class="text-success">Thank you for your order!</h3>
            <p class="text-muted">Your order has been successfully placed and is being processed.</p>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h6>Order Details</h6>
                        <p><strong>Order ID:</strong> #${order.id}</p>
                        <p><strong>Total:</strong> $${orderData.total.toFixed(2)}</p>
                        <p><strong>Payment:</strong> ${getPaymentMethodDisplay(orderData.payment.method)}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h6>Shipping Address</h6>
                        <p>
                            ${orderData.shipping.firstName} ${orderData.shipping.lastName}<br>
                            ${orderData.shipping.address}<br>
                            ${orderData.shipping.city}, ${orderData.shipping.state} ${orderData.shipping.zipCode}
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="alert alert-info mt-3">
            <i class="bi bi-info-circle"></i>
            You will receive an email confirmation shortly at ${orderData.shipping.email}
        </div>
    `;
}

// Utility functions
function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    const toastId = 'toast-' + Date.now();
    
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement);
    toast.show();
    
    // Remove toast element after it's hidden
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

function showLoading() {
    // Simple loading state - could be enhanced with a spinner
    document.body.style.cursor = 'wait';
}

function hideLoading() {
    document.body.style.cursor = 'default';
}

// Export functions for global access
window.nextStep = nextStep;
window.prevStep = prevStep;
window.placeOrder = placeOrder;
