// compare.js - Product comparison functionality

// Get compare list from localStorage
function getCompareList() {
    try {
        return JSON.parse(localStorage.getItem('compareList')) || [];
    } catch {
        return [];
    }
}

// Save compare list to localStorage
function saveCompareList(list) {
    localStorage.setItem('compareList', JSON.stringify(list));
}

// Clear all comparisons
function clearComparison() {
    localStorage.removeItem('compareList');
    window.location.reload();
}

// Load and render comparison
async function loadComparison() {
    const compareList = getCompareList();
    const container = document.getElementById('comparisonContainer');
    
    if (compareList.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="bi bi-arrow-left-right display-1 text-muted"></i>
                <h4 class="mt-3">No products to compare</h4>
                <p class="text-muted">Add products to comparison from the product listing page.</p>
                <a href="index.html" class="btn btn-primary">Browse Products</a>
            </div>
        `;
        return;
    }

    try {
        // Fetch product details for all items in compare list
        const productPromises = compareList.map(id => 
            fetch(`/api/products/${id}`).then(res => res.json())
        );
        
        const responses = await Promise.all(productPromises);
        const products = responses
            .filter(res => res.success)
            .map(res => res.product || res.data);

        if (products.length === 0) {
            container.innerHTML = `
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i>
                    Failed to load comparison products. Please try again.
                </div>
            `;
            return;
        }

        renderComparisonTable(products);
    } catch (error) {
        console.error('Error loading comparison:', error);
        container.innerHTML = `
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-circle"></i>
                Error loading products for comparison.
            </div>
        `;
    }
}

// Render comparison table
function renderComparisonTable(products) {
    const container = document.getElementById('comparisonContainer');
    
    const tableHTML = `
        <div class="table-responsive">
            <table class="table table-bordered bg-white">
                <thead class="table-light">
                    <tr>
                        <th style="width: 200px;">Specification</th>
                        ${products.map(p => `
                            <th class="text-center" style="min-width: 250px;">
                                <div class="position-relative">
                                    <button class="btn btn-sm btn-outline-danger position-absolute top-0 end-0" 
                                            onclick="removeFromComparison(${p.id})" title="Remove">
                                        <i class="bi bi-x"></i>
                                    </button>
                                    <img src="${p.image_url || 'https://via.placeholder.com/150'}" 
                                         class="img-fluid mb-2" style="height: 120px; object-fit: cover;" alt="${p.name}">
                                    <h6 class="mb-1">${p.name}</h6>
                                    <p class="text-danger fw-bold mb-0">$${parseFloat(p.price).toLocaleString('en-US')}</p>
                                </div>
                            </th>
                        `).join('')}
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="fw-bold">Price</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <span class="fs-5 text-danger fw-bold">$${parseFloat(p.price).toLocaleString('en-US')}</span>
                            </td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Category</td>
                        ${products.map(p => `
                            <td class="text-center">${p.category_name || 'N/A'}</td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Brand</td>
                        ${products.map(p => `
                            <td class="text-center">${p.brand_name || 'N/A'}</td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Stock Status</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <span class="badge bg-${p.stock > 0 ? 'success' : 'secondary'}">
                                    ${p.stock > 0 ? 'In Stock' : 'Out of Stock'}
                                </span>
                            </td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Available Quantity</td>
                        ${products.map(p => `
                            <td class="text-center">${p.stock || 0}</td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Description</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <div style="max-height: 100px; overflow-y: auto;">
                                    ${p.description || 'No description available'}
                                </div>
                            </td>
                        `).join('')}
                    </tr>
                    <tr>
                        <td class="fw-bold">Actions</td>
                        ${products.map(p => `
                            <td class="text-center">
                                <div class="d-grid gap-2">
                                    <a href="product.html?id=${p.id}" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-eye"></i> View Details
                                    </a>
                                    ${p.stock > 0 ? `
                                        <button class="btn btn-success btn-sm" onclick="window.addToCart && window.addToCart(${p.id})">
                                            <i class="bi bi-cart-plus"></i> Add to Cart
                                        </button>
                                    ` : `
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            Out of Stock
                                        </button>
                                    `}
                                </div>
                            </td>
                        `).join('')}
                    </tr>
                </tbody>
            </table>
        </div>
    `;
    
    container.innerHTML = tableHTML;
}

// Remove product from comparison
function removeFromComparison(productId) {
    let compareList = getCompareList();
    compareList = compareList.filter(id => id !== productId);
    saveCompareList(compareList);
    
    if (compareList.length === 0) {
        window.location.reload();
    } else {
        loadComparison();
    }
}

// Initialize comparison page
document.addEventListener('DOMContentLoaded', () => {
    loadComparison();
    
    // Set year in footer
    document.getElementById('yearCopy').textContent = new Date().getFullYear();
});

// Expose functions globally
window.clearComparison = clearComparison;
window.removeFromComparison = removeFromComparison;
