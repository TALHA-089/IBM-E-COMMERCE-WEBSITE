// Image Proxy Utility to handle CORS issues with external images
class ImageProxy {
    static getProxiedUrl(originalUrl) {
        if (!originalUrl) return '/images/placeholder.jpg';
        
        // If it's already a local URL, return as is
        if (originalUrl.startsWith('/') || originalUrl.startsWith('http://localhost') || originalUrl.startsWith('http://127.0.0.1')) {
            return originalUrl;
        }
        
        // For external URLs, use our proxy
        return `/proxy-image?url=${encodeURIComponent(originalUrl)}`;
    }
    
    static handleImageError(imgElement) {
        // Set fallback image on error
        imgElement.src = '/images/placeholder.jpg';
        imgElement.onerror = null; // Prevent infinite loop
    }
    
    static setupImageErrorHandling() {
        // Add global error handling for all images
        document.addEventListener('error', (e) => {
            if (e.target.tagName === 'IMG') {
                ImageProxy.handleImageError(e.target);
            }
        }, true);
    }
}

// Initialize global image error handling
document.addEventListener('DOMContentLoaded', () => {
    ImageProxy.setupImageErrorHandling();
});

// Export for use in other modules
window.ImageProxy = ImageProxy;
