// Dynamic Image Resizing Utility for Product Cards
class ImageResizer {
    constructor() {
        this.targetWidth = 250;
        this.targetHeight = 250;
        // Slightly higher compression quality for sharper images
        this.quality = 0.92;
        // Detect WebP support once and cache result
        this.webpSupported = this.checkWebpSupport();
    }

    // Resize image to fit card dimensions perfectly
    // Uses devicePixelRatio to render crisp images on HiDPI / retina screens
    // Skips resizing when the original image is already smaller than the target to avoid up-scaling artefacts
    async resizeImageToFit(imageUrl, targetWidth = this.targetWidth, targetHeight = this.targetHeight) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            
            img.onload = () => {
                try {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    
                    // Calculate optimal dimensions maintaining aspect ratio
                    const { width, height, offsetX, offsetY } = this.calculateOptimalSize(
                        img.width, 
                        img.height, 
                        targetWidth, 
                        targetHeight
                    );
                    
                    // Use devicePixelRatio for sharper rendering
                    const dpr = window.devicePixelRatio || 1;
                    canvas.width = targetWidth * dpr;
                    canvas.height = targetHeight * dpr;
                    // Style size will remain logical pixels
                    canvas.style.width = `${targetWidth}px`;
                    canvas.style.height = `${targetHeight}px`;

                    // Scale the context so 1 unit in the canvas maps to one CSS pixel
                    ctx.scale(dpr, dpr);

                    // Fill background with light colour
                    ctx.fillStyle = '#f8f9fa';
                    ctx.fillRect(0, 0, targetWidth, targetHeight);
                    // Draw image centered and properly sized
                    ctx.drawImage(img, offsetX, offsetY, width, height);

                    // Choose format
                    const mimeType = this.webpSupported ? 'image/webp' : 'image/jpeg';
                    canvas.toBlob((blob) => {
                        const resizedUrl = URL.createObjectURL(blob);
                        resolve(resizedUrl);
                    }, mimeType, this.quality);
                    
                } catch (error) {
                    reject(error);
                }
            };
            
            img.onerror = () => reject(new Error('Failed to load image'));
            img.src = imageUrl;
        });
    }

    // Check browser WebP support (synchronous – runs once in constructor)
    checkWebpSupport() {
        const elem = document.createElement('canvas');
        if (!!(elem.getContext && elem.getContext('2d'))) {
            return elem.toDataURL('image/webp').indexOf('data:image/webp') === 0;
        }
        return false;
    }

    // Calculate optimal size to fit within target dimensions
    calculateOptimalSize(imgWidth, imgHeight, targetWidth, targetHeight) {
        // Skip up-scaling – if image is already close to target size, draw at native size
        if (imgWidth <= targetWidth * 1.1 && imgHeight <= targetHeight * 1.1) {
            return { width: imgWidth, height: imgHeight, offsetX: (targetWidth - imgWidth) / 2, offsetY: (targetHeight - imgHeight) / 2 };
        }
        const imgAspectRatio = imgWidth / imgHeight;
        const targetAspectRatio = targetWidth / targetHeight;
        
        let width, height, offsetX = 0, offsetY = 0;
        
        if (imgAspectRatio > targetAspectRatio) {
            // Image is wider - fit to width
            width = targetWidth * 0.9; // 90% to leave some padding
            height = width / imgAspectRatio;
            offsetX = (targetWidth - width) / 2;
            offsetY = (targetHeight - height) / 2;
        } else {
            // Image is taller - fit to height
            height = targetHeight * 0.9; // 90% to leave some padding
            width = height * imgAspectRatio;
            offsetX = (targetWidth - width) / 2;
            offsetY = (targetHeight - height) / 2;
        }
        
        return { width, height, offsetX, offsetY };
    }

    // Process product image with fallback handling
    async processProductImage(originalUrl) {
        try {
            // First try to get the image through proxy
            const proxyUrl = ImageProxy.getProxiedUrl(originalUrl);
            const resizedUrl = await this.resizeImageToFit(proxyUrl);
            return resizedUrl;
        } catch (error) {
            console.warn('Image resize failed, using fallback:', error);
            // Fallback to original proxy URL
            return ImageProxy.getProxiedUrl(originalUrl);
        }
    }

    // Batch process multiple images
    async processProductImages(products) {
        const processedProducts = await Promise.allSettled(
            products.map(async (product) => {
                try {
                    const resizedImageUrl = await this.processProductImage(product.image_url);
                    return {
                        ...product,
                        resized_image_url: resizedImageUrl,
                        original_image_url: product.image_url
                    };
                } catch (error) {
                    console.warn(`Failed to process image for product ${product.id}:`, error);
                    return {
                        ...product,
                        resized_image_url: ImageProxy.getProxiedUrl(product.image_url),
                        original_image_url: product.image_url
                    };
                }
            })
        );

        return processedProducts.map(result => 
            result.status === 'fulfilled' ? result.value : result.reason
        );
    }

    // Clean up blob URLs to prevent memory leaks
    cleanupBlobUrls(urls) {
        urls.forEach(url => {
            if (url && url.startsWith('blob:')) {
                URL.revokeObjectURL(url);
            }
        });
    }

    // Initialize image observer for lazy loading optimization
    setupImageObserver() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            imageObserver.unobserve(img);
                        }
                    }
                });
            });

            // Observe all product images
            document.querySelectorAll('.product-card img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
}

// Create global instance
const imageResizer = new ImageResizer();

// Export for use in other modules
window.ImageResizer = ImageResizer;
window.imageResizer = imageResizer;

// Auto-setup when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    imageResizer.setupImageObserver();
});
