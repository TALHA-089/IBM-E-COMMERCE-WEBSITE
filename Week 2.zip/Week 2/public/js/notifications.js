// Real-time Notifications Client
class NotificationManager {
    constructor() {
        this.socket = null;
        this.userId = null;
        this.notificationContainer = null;
        this.init();
    }

    async init() {
        // Get user info
        try {
            const authModule = await import('./auth.js');
            if (authModule.isLoggedIn()) {
                const userInfo = authModule.getUser();
                this.userId = userInfo.id;
                this.setupWebSocket();
            }
        } catch (error) {
            console.error('Failed to initialize notifications:', error);
        }

        // Create notification container
        this.createNotificationContainer();
        
        // Request notification permission
        this.requestNotificationPermission();
    }

    setupWebSocket() {
        if (!this.userId) return;

        // Connect to WebSocket server
        this.socket = io();

        this.socket.on('connect', () => {
            console.log('Connected to notification server');
            // Join user's personal notification room
            this.socket.emit('join_user_room', this.userId);
        });

        // Listen for delivery updates
        this.socket.on('delivery_update', (notification) => {
            this.handleDeliveryUpdate(notification);
        });

        // Listen for order confirmations
        this.socket.on('order_confirmation', (notification) => {
            this.handleOrderConfirmation(notification);
        });

        this.socket.on('disconnect', () => {
            console.log('Disconnected from notification server');
        });
    }

    createNotificationContainer() {
        // Create floating notification container
        this.notificationContainer = document.createElement('div');
        this.notificationContainer.id = 'notification-container';
        this.notificationContainer.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
            pointer-events: none;
        `;
        document.body.appendChild(this.notificationContainer);
    }

    handleDeliveryUpdate(notification) {
        const { order_id, tracking_number, status_description, location, notes } = notification;
        
        // Show in-app notification
        this.showInAppNotification({
            title: `Order #${order_id} Updated`,
            message: status_description,
            type: 'delivery',
            icon: 'truck',
            action: () => {
                window.open(`/track-order.html?tracking=${tracking_number}`, '_blank');
            }
        });

        // Show browser notification
        this.showBrowserNotification(
            `Order #${order_id} Updated`,
            {
                body: `${status_description}${location ? ` - ${location}` : ''}`,
                icon: '/favicon.ico',
                tag: `order-${order_id}`,
                data: { tracking_number, order_id }
            }
        );

        // Update any open tracking pages
        this.updateTrackingPages(notification);
    }

    handleOrderConfirmation(notification) {
        const { order_id, total_amount } = notification;
        
        this.showInAppNotification({
            title: 'Order Confirmed!',
            message: `Order #${order_id} for $${parseFloat(total_amount).toFixed(2)} has been confirmed`,
            type: 'success',
            icon: 'check-circle',
            action: () => {
                window.location.href = '/profile.html';
            }
        });

        this.showBrowserNotification(
            'Order Confirmed!',
            {
                body: `Your order #${order_id} has been confirmed and is being processed`,
                icon: '/favicon.ico',
                tag: `order-confirmed-${order_id}`
            }
        );
    }

    showInAppNotification({ title, message, type = 'info', icon = 'bell', action = null, duration = 5000 }) {
        const notification = document.createElement('div');
        notification.className = `alert alert-${this.getAlertType(type)} alert-dismissible fade show shadow-lg mb-3`;
        notification.style.cssText = `
            pointer-events: auto;
            cursor: ${action ? 'pointer' : 'default'};
            animation: slideInRight 0.3s ease-out;
        `;

        notification.innerHTML = `
            <div class="d-flex align-items-center">
                <i class="bi bi-${icon} me-2 fs-5"></i>
                <div class="flex-grow-1">
                    <div class="fw-bold">${title}</div>
                    <div class="small">${message}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        if (action) {
            notification.addEventListener('click', (e) => {
                if (!e.target.classList.contains('btn-close')) {
                    action();
                }
            });
        }

        this.notificationContainer.appendChild(notification);

        // Auto-remove after duration
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);

        // Add CSS animation
        if (!document.getElementById('notification-animations')) {
            const style = document.createElement('style');
            style.id = 'notification-animations';
            style.textContent = `
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
    }

    async showBrowserNotification(title, options = {}) {
        if (!('Notification' in window)) return;
        
        if (Notification.permission === 'granted') {
            const notification = new Notification(title, {
                ...options,
                requireInteraction: false
            });

            // Handle click
            notification.onclick = () => {
                window.focus();
                if (options.data?.tracking_number) {
                    window.open(`/track-order.html?tracking=${options.data.tracking_number}`, '_blank');
                }
                notification.close();
            };

            // Auto-close after 5 seconds
            setTimeout(() => notification.close(), 5000);
        }
    }

    async requestNotificationPermission() {
        if (!('Notification' in window)) {
            console.log('This browser does not support notifications');
            return;
        }

        if (Notification.permission === 'default') {
            const permission = await Notification.requestPermission();
            console.log('Notification permission:', permission);
        }
    }

    getAlertType(type) {
        const typeMap = {
            'delivery': 'info',
            'success': 'success',
            'warning': 'warning',
            'error': 'danger',
            'info': 'info'
        };
        return typeMap[type] || 'info';
    }

    updateTrackingPages(notification) {
        // If tracking page is open, trigger a refresh
        if (window.location.pathname.includes('track-order')) {
            const event = new CustomEvent('deliveryUpdate', { detail: notification });
            window.dispatchEvent(event);
        }
    }

    // Public method to show custom notifications
    showNotification(title, message, type = 'info', action = null) {
        this.showInAppNotification({ title, message, type, action });
    }

    // Disconnect WebSocket
    disconnect() {
        if (this.socket) {
            this.socket.disconnect();
        }
    }
}

// Initialize notification manager
const notificationManager = new NotificationManager();

// Export for use in other scripts
window.notificationManager = notificationManager;

// Listen for page unload to disconnect WebSocket
window.addEventListener('beforeunload', () => {
    notificationManager.disconnect();
});
