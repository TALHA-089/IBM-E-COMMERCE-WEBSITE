// Order Tracking Integration for Profile and Order Pages
const API_BASE = '/api';

// Add tracking functionality to existing order displays
function addTrackingToOrders() {
    const orderCards = document.querySelectorAll('.order-card, .order-item');
    
    orderCards.forEach(card => {
        const orderId = card.dataset.orderId;
        if (orderId) {
            addTrackingButton(card, orderId);
        }
    });
}

// Add tracking button to order card
function addTrackingButton(orderCard, orderId) {
    const existingButton = orderCard.querySelector('.track-order-btn');
    if (existingButton) return; // Already added

    const buttonContainer = orderCard.querySelector('.order-actions, .card-footer, .d-flex');
    if (buttonContainer) {
        const trackButton = document.createElement('a');
        trackButton.href = `track-order.html?order=${orderId}`;
        trackButton.className = 'btn btn-outline-primary btn-sm track-order-btn';
        trackButton.innerHTML = '<i class="bi bi-truck me-1"></i>Track Order';
        
        buttonContainer.appendChild(trackButton);
    }
}

// Quick tracking status for order cards
async function addQuickTrackingStatus(orderCard, orderId) {
    try {
        const token = localStorage.getItem('accessToken');
        
        if (!token) return;

        const response = await fetch(`${API_BASE}/deliveries/order/${orderId}/tracking`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        const data = await response.json();
        
        if (data.success && data.data.current_status) {
            const statusElement = document.createElement('div');
            statusElement.className = 'mt-2 small text-muted';
            statusElement.innerHTML = `
                <i class="bi bi-truck me-1"></i>
                <strong>Status:</strong> ${data.data.current_status.description}
            `;
            
            const cardBody = orderCard.querySelector('.card-body');
            if (cardBody) {
                cardBody.appendChild(statusElement);
            }
        }
    } catch (error) {
        console.error('Error fetching quick tracking status:', error);
    }
}

// Initialize tracking features when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add tracking buttons to existing orders
    setTimeout(addTrackingToOrders, 1000); // Wait for orders to load
    
    // Listen for new orders being added dynamically
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1 && (node.classList.contains('order-card') || node.classList.contains('order-item'))) {
                    const orderId = node.dataset.orderId;
                    if (orderId) {
                        addTrackingButton(node, orderId);
                        addQuickTrackingStatus(node, orderId);
                    }
                }
            });
        });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
});

// Export functions for use in other scripts
window.addTrackingToOrders = addTrackingToOrders;
window.addTrackingButton = addTrackingButton;
