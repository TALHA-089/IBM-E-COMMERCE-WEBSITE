// productDetail.js
// Fetch product id from query param
const params = new URLSearchParams(window.location.search);
const productId = params.get('id');
const container = document.getElementById('productContainer');

if (!productId) {
  container.innerHTML = '<div class="alert alert-danger">Product not specified.</div>';
} else {
  loadProduct();
}

async function loadProduct() {
  try {
    const res = await fetch(`/api/products/${productId}`);
    const data = await res.json();
    if (data.success) {
      renderProduct(data.product || data.data);
    } else {
      container.innerHTML = `<div class="alert alert-danger">${data.message || 'Failed to load product.'}</div>`;
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = '<div class="alert alert-danger">Server error.</div>';
  }
}

function renderProduct(p) {
  // breadcrumbs
  document.getElementById('breadcrumbCategory').innerHTML = `<a href="index.html#products" onclick="localStorage.setItem('filterCategory','${p.category_name}')">${p.category_name}</a>`;
  document.getElementById('breadcrumbProduct').textContent = p.name;
  document.getElementById('canonicalLink').href = window.location.href;
  // schema
  const schema = {
    '@context':'https://schema.org',
    '@type':'Product',
    name:p.name,
    image:[p.image_url],
    description:p.description,
    sku:p.id,
    brand:{'@type':'Brand',name:p.brand_name},
    offers:{'@type':'Offer',price:p.price,priceCurrency:'USD',availability:p.in_stock?'https://schema.org/InStock':'https://schema.org/OutOfStock'}
  };
  document.getElementById('productSchema').textContent = JSON.stringify(schema);

  const price = parseFloat(p.price);
  const inStock = p.in_stock !== false;
  document.title = `${p.name} | Imarat Builders Mall`;
  container.innerHTML = `
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="border rounded mb-3">
          <img src="${p.image_url || 'https://via.placeholder.com/600x400?text=No+Image'}" class="img-fluid" alt="${p.name}" loading="eager">
        </div>
        <div class="thumb-vertical d-flex flex-column gap-2" id="thumbs">
          ${(p.gallery || []).map(url=>`<img src="${url}" loading="lazy" class="img-thumbnail" style="width:80px;cursor:pointer">`).join('')}
        </div>
      </div>
      <div class="col-lg-6">
        <h3>${p.name}</h3>
        <p class="text-muted mb-1">Estimated Shipping: 5 Days</p>
        <p class="fs-4 text-danger">$${price.toLocaleString('en-US',{minimumFractionDigits:2})}</p>
        <span class="badge bg-${inStock?'success':'secondary'} mb-2">${inStock?'In Stock':'Out of Stock'}</span>
        <div class="mb-3">
          <label class="form-label">Quantity:</label>
          <div class="input-group quantity-group">
            <button class="btn btn-outline-secondary" type="button" id="qtyMinus">-</button>
            <input type="number" id="qtyInput" class="form-control text-center" value="1" min="1">
            <button class="btn btn-outline-secondary" type="button" id="qtyPlus">+</button>
          </div>
        </div>
        ${(!isAdminUser && inStock) ? `<button id=\"addCartBtn\" class=\"btn btn-success mb-3\"><i class=\"bi bi-cart-plus\"></i> Add to Cart</button>` : ''}
        <div class="mb-3">
          <strong>Total Price:</strong> $<span id="totalPrice">${price.toFixed(2)}</span>
        </div>
        <div class="mb-3">
          <span class="me-2">Share:</span>
          <a href="https://www.facebook.com/sharer/sharer.php?u=${location.href}" target="_blank" class="btn btn-sm btn-outline-primary">Facebook</a>
          <a href="https://twitter.com/intent/tweet?url=${location.href}" target="_blank" class="btn btn-sm btn-outline-info">Twitter</a>
          <a href="https://wa.me/?text=${encodeURIComponent(location.href)}" target="_blank" class="btn btn-sm btn-outline-success">WhatsApp</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-4">
      <div class="col-lg-4">
        <div class="border rounded p-3 h-100">
          <h6>Seller</h6>
          <p class="mb-1">${p.seller_name || 'IBM Seller'}</p>
          <a href="#" class="btn btn-sm btn-outline-success">Visit Store</a>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="border rounded p-3 h-100">
          <h6>Reviews & Ratings</h6>
          <p>0 out of 5.0 (0 reviews)</p>
          <button class="btn btn-sm btn-success">Rate this Product</button>
          <p class="mt-3 mb-0 text-muted">There have been no reviews for this product yet.</p>
        </div>
      </div>
    </div>
    <div class="mt-4">
      <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#descTab">Description</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#videoTab">Video</a>
        </li>
      </ul>
      <div class="tab-content border border-top-0 p-3 bg-white">
        <div id="descTab" class="tab-pane fade show active">
          ${p.description || 'No description available.'}
        </div>
        <div id="videoTab" class="tab-pane fade">
          ${p.video_embed ? `<div class="ratio ratio-16x9">${p.video_embed}</div>` : 'No video available.'}
        </div>
      </div>
    </div>
  `;
  // quantity listeners
  const qtyInput = document.getElementById('qtyInput');
  const totalPriceSpan = document.getElementById('totalPrice');
  const maxQty = p.stock || 999;
  qtyInput.addEventListener('input', () => {
    const qty = parseInt(qtyInput.value)||1;
    mobTotal.textContent = `$${(price*qty).toFixed(2)}`;
    totalPriceSpan.textContent = (price * qty).toFixed(2);
  });
  const addHandler = () => addToCart(productId, parseInt(qtyInput?.value)||1);
  const addBtn = document.getElementById('addCartBtn');
  if(addBtn){
    addBtn.addEventListener('click', addHandler);
  }
  // mobile bar
  const mobBar=document.getElementById('mobileBar');
  const mobTotal=document.getElementById('mobileTotal');
  const mobBtn=document.getElementById('mobileAddCartBtn');
  if(mobBtn){
    mobBtn.addEventListener('click', addHandler);
  }
    // plus/minus buttons
  const minusBtn=document.getElementById('qtyMinus');
  const plusBtn=document.getElementById('qtyPlus');
  if(minusBtn){
    minusBtn.addEventListener('click', ()=>{
      let val=parseInt(qtyInput.value)||1;
      if(val>1){val--; qtyInput.value=val; qtyInput.dispatchEvent(new Event('input'));}
    });
  }
  if(plusBtn){
    plusBtn.addEventListener('click', ()=>{
      let val=parseInt(qtyInput.value)||1;
      if(val<maxQty){val++; qtyInput.value=val; qtyInput.dispatchEvent(new Event('input'));}
    });
  }

  mobBar.style.display='flex';
  mobTotal.textContent = `$${price.toFixed(2)}`;
  // related products
fetch(`/api/products?category_id=${p.category_id}&limit=4`).then(r=>r.json()).then(d=>{
  if(d.success && d.data && d.data.length){
    const relHTML = `<h4 class="mt-5">Related Products</h4><div class="row g-3">${d.data.filter(it=>it.id!==p.id).map(it=>`<div class='col-6 col-md-3'><div class='card h-100' onclick="window.location.href='product.html?id=${it.id}'" style='cursor:pointer'> <img src='${it.image_url||'https://via.placeholder.com/150'}' class='card-img-top' loading='lazy' alt='${it.name}'><div class='card-body'><h6 class='card-title'>${it.name}</h6><p class='text-danger mb-0'>$${parseFloat(it.price).toLocaleString('en-US')}</p></div></div></div>`).join('')}</div>`;
    container.insertAdjacentHTML('beforeend', relHTML);
  }
});

// thumbs click to change main image
  document.querySelectorAll('#thumbs img').forEach(img => {
    img.addEventListener('click', () => {
      document.querySelector('#productContainer img.img-fluid').src = img.src;
    });
  });
}

// set year in footer
 document.getElementById('yearCopy').textContent = new Date().getFullYear();
