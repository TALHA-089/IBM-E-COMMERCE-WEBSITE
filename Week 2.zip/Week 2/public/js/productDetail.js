// productDetail.js
// Fetch product id from query param
const params = new URLSearchParams(window.location.search);
const productId = params.get('id');
const container = document.getElementById('productContainer');

// Helper to safely get a usable image URL for a product (mainly for related products list)
function getProductImage(product) {
  if (!product) return 'https://via.placeholder.com/300x200?text=No+Image';
  // Prefer resized URL generated earlier if available
  if (product.resized_image_url) return product.resized_image_url;
  // Fallback to proxying the original URL (handles CORS) or placeholder
  return ImageProxy.getProxiedUrl(product.image_url || 'https://via.placeholder.com/300x200?text=No+Image');
}


// determine if current user is admin
const isAdminUser = (()=>{try{const u=JSON.parse(localStorage.getItem('user'));return u && u.role==='admin';}catch{return false;}})();

if (!productId) {
  container.innerHTML = '<div class="alert alert-danger">Product not specified.</div>';
} else {
  loadProduct();
}

async function loadProduct() {
  try {
    const res = await fetch(`/api/products/${productId}`);
    const data = await res.json();
    if (data.success) {
      let product = data.product || data.data;
      
      // Process main product image with resizer if available
      if (window.imageResizer && product.image_url) {
        try {
          product.resized_image_url = await window.imageResizer.processProductImage(product.image_url);
        } catch (error) {
          console.warn('Failed to resize main product image:', error);
        }
      }
      
      // Process gallery images if they exist
      if (window.imageResizer && product.gallery && product.gallery.length > 0) {
        try {
          const resizedGallery = await Promise.allSettled(
            product.gallery.map(url => window.imageResizer.processProductImage(url))
          );
          product.resized_gallery = resizedGallery.map((result, index) => 
            result.status === 'fulfilled' ? result.value : product.gallery[index]
          );
        } catch (error) {
          console.warn('Failed to resize gallery images:', error);
        }
      }
      
      renderProduct(product);
    } else {
      container.innerHTML = `<div class="alert alert-danger">${data.message || 'Failed to load product.'}</div>`;
    }
  } catch (err) {
    console.error(err);
    container.innerHTML = '<div class="alert alert-danger">Server error.</div>';
  }
}

function renderProduct(p) {
  // breadcrumbs
  document.getElementById('breadcrumbCategory').innerHTML = `<a href="index.html#products" onclick="localStorage.setItem('filterCategory','${p.category_name}')">${p.category_name}</a>`;
  document.getElementById('breadcrumbProduct').textContent = p.name;
  document.getElementById('canonicalLink').href = window.location.href;
  // schema
  const schema = {
    '@context':'https://schema.org',
    '@type':'Product',
    name:p.name,
    image:[p.image_url],
    description:p.description,
    sku:p.id,
    brand:{'@type':'Brand',name:p.brand_name},
    offers:{'@type':'Offer',price:p.price,priceCurrency:'USD',availability:p.in_stock?'https://schema.org/InStock':'https://schema.org/OutOfStock'}
  };
  document.getElementById('productSchema').textContent = JSON.stringify(schema);

  const price = parseFloat(p.price);
  const inStock = p.in_stock !== false;
  document.title = `${p.name} | Imarat Builders Mall`;
  container.innerHTML = `
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="border rounded mb-3">
          <img src="${p.resized_image_url || ImageProxy.getProxiedUrl(p.image_url) || 'https://via.placeholder.com/600x400?text=No+Image'}" class="img-fluid" alt="${p.name}" loading="eager" style="max-height: 500px; object-fit: contain; background-color: #f8f9fa;">
        </div>
        <div class="thumb-vertical d-flex flex-column gap-2" id="thumbs">
          ${(p.resized_gallery || p.gallery || []).map((url, index)=>`<img src="${url}" loading="lazy" class="img-thumbnail" style="width:80px;height:80px;object-fit:cover;cursor:pointer" onclick="changeMainImage('${url}')">`).join('')}
        </div>
      </div>
      <div class="col-lg-6">
        <h3>${p.name}</h3>
        <p class="text-muted mb-1">Estimated Shipping: 5 Days</p>
        <p class="fs-4 text-danger">$${price.toLocaleString('en-US',{minimumFractionDigits:2})}</p>
        <span class="badge bg-${inStock?'success':'secondary'} mb-2">${inStock?'In Stock':'Out of Stock'}</span>
        <div class="mb-3">
          <label class="form-label">Quantity:</label>
          <div class="input-group quantity-group">
            <button class="btn btn-outline-secondary" type="button" id="qtyMinus">-</button>
            <input type="number" id="qtyInput" class="form-control text-center" value="1" min="1">
            <button class="btn btn-outline-secondary" type="button" id="qtyPlus">+</button>
          </div>
        </div>
        ${(!isAdminUser && inStock) ? `<button id=\"addCartBtn\" class=\"btn btn-success mb-3\"><i class=\"bi bi-cart-plus\"></i> Add to Cart</button>` : ''}
        <div class="mb-3">
          <strong>Total Price:</strong> $<span id="totalPrice">${price.toFixed(2)}</span>
        </div>
        <div class="mb-3">
          <span class="me-2">Share:</span>
          <a href="https://www.facebook.com/sharer/sharer.php?u=${location.href}" target="_blank" class="btn btn-sm btn-outline-primary">Facebook</a>
          <a href="https://twitter.com/intent/tweet?url=${location.href}" target="_blank" class="btn btn-sm btn-outline-info">Twitter</a>
          <a href="https://wa.me/?text=${encodeURIComponent(location.href)}" target="_blank" class="btn btn-sm btn-outline-success">WhatsApp</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-4">
      <div class="col-lg-4">
        <div class="border rounded p-3 h-100">
          <h6>Seller</h6>
          <p class="mb-1">${p.seller_name || 'IBM Seller'}</p>
          <a href="#" class="btn btn-sm btn-outline-success">Visit Store</a>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="border rounded p-3 h-100">
          <h6>Reviews & Ratings</h6>
          <p>0 out of 5.0 (0 reviews)</p>
          <button id="rateBtn" class="btn btn-sm btn-success">Rate this Product</button>
            <div id="averageRating" class="mt-2"></div>
            <div id="reviewsContainer" class="mt-3"></div>
          <p class="mt-3 mb-0 text-muted">There have been no reviews for this product yet.</p>
        </div>
      </div>
    </div>
    <div class="mt-4">
      <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" data-bs-toggle="tab" href="#descTab">Description</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-bs-toggle="tab" href="#videoTab">Video</a>
        </li>
      </ul>
      <div class="tab-content border border-top-0 p-3 bg-white">
        <div id="descTab" class="tab-pane fade show active">
          ${p.description || 'No description available.'}
        </div>
        <div id="videoTab" class="tab-pane fade">
          ${p.video_embed ? `<div class="ratio ratio-16x9">${p.video_embed}</div>` : 'No video available.'}
        </div>
      </div>
    </div>
  `;
  // references
  const mobBar=document.getElementById('mobileBar');
  const mobTotal=document.getElementById('mobileTotal');
  const mobBtn=document.getElementById('mobileAddCartBtn');
  // quantity listeners
  const qtyInput = document.getElementById('qtyInput');
  const totalPriceSpan = document.getElementById('totalPrice');
  const maxQty = p.stock || 999;
  qtyInput.addEventListener('input', () => {
    const qty = parseInt(qtyInput.value)||1;
    mobTotal.textContent = `$${(price*qty).toFixed(2)}`;
    totalPriceSpan.textContent = (price * qty).toFixed(2);
  });
  const addHandler = async () => {
    console.log('Add to cart clicked');
    try {
      // Import addToCart and showAlert from app.js module
      const { addToCart, showAlert } = await import('./app.js');
      await addToCart(productId, parseInt(qtyInput?.value)||1);
    } catch (error) {
      console.error('Error adding to cart:', error);
      // Fallback alert
      const alertDiv = document.createElement('div');
      alertDiv.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x';
      alertDiv.style.zIndex = '1080';
      alertDiv.innerHTML = `
        Added to cart!
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      `;
      document.body.prepend(alertDiv);
      setTimeout(() => alertDiv.remove(), 3000);
    }
  };
  // review button
  const rateBtn = document.getElementById('rateBtn');
  if(rateBtn){
    rateBtn.addEventListener('click', async ()=>{
      const { isLoggedIn } = await import('./auth.js');
      if(!isLoggedIn()) { window.location.href='login.html'; return; }
      renderReviewModal();
    });
  }
  function renderReviewModal(){
    let modalDiv = document.getElementById('reviewModal');
    if(!modalDiv){
      document.body.insertAdjacentHTML('beforeend',`
<div class="modal fade" id="reviewModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title"><i class="bi bi-star-fill"></i> Rate & Review Product</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form id="reviewFormModal">
          <div class="mb-4">
            <label class="form-label fw-bold fs-5">Your Rating</label>
            <div class="star-rating d-flex align-items-center gap-1 my-2">
              <span class="star" data-rating="1"><i class="bi bi-star fs-2"></i></span>
              <span class="star" data-rating="2"><i class="bi bi-star fs-2"></i></span>
              <span class="star" data-rating="3"><i class="bi bi-star fs-2"></i></span>
              <span class="star" data-rating="4"><i class="bi bi-star fs-2"></i></span>
              <span class="star" data-rating="5"><i class="bi bi-star fs-2"></i></span>
              <span class="rating-text ms-3 text-muted">Click to rate</span>
            </div>
            <input type="hidden" id="modalRating" required>
          </div>
          <div class="mb-4">
            <label class="form-label fw-bold">Share Your Experience</label>
            <textarea id="modalComment" class="form-control" rows="4" placeholder="Tell others about your experience with this product..."></textarea>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-warning px-4">
              <i class="bi bi-send"></i> Submit Review
            </button>
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<style>
.star-rating .star {
  cursor: pointer;
  color: #ddd;
  transition: color 0.2s ease;
}
.star-rating .star:hover,
.star-rating .star.active {
  color: #ffc107;
}
.star-rating .star:hover ~ .rating-text {
  display: none;
}
</style>`);
      modalDiv = document.getElementById('reviewModal');
      
      // Star rating functionality
      const stars = modalDiv.querySelectorAll('.star');
      const ratingInput = document.getElementById('modalRating');
      const ratingText = modalDiv.querySelector('.rating-text');
      
      stars.forEach((star, index) => {
        star.addEventListener('click', () => {
          const rating = index + 1;
          ratingInput.value = rating;
          
          // Update star display
          stars.forEach((s, i) => {
            if (i < rating) {
              s.classList.add('active');
              s.querySelector('i').className = 'bi bi-star-fill fs-2';
            } else {
              s.classList.remove('active');
              s.querySelector('i').className = 'bi bi-star fs-2';
            }
          });
          
          // Update rating text
          const ratingTexts = ['Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
          ratingText.textContent = ratingTexts[rating - 1];
          ratingText.style.color = '#ffc107';
        });
        
        star.addEventListener('mouseenter', () => {
          const rating = index + 1;
          stars.forEach((s, i) => {
            if (i < rating) {
              s.style.color = '#ffc107';
            } else {
              s.style.color = '#ddd';
            }
          });
        });
      });
      
      modalDiv.addEventListener('mouseleave', () => {
        const currentRating = parseInt(ratingInput.value) || 0;
        stars.forEach((s, i) => {
          if (i < currentRating) {
            s.style.color = '#ffc107';
          } else {
            s.style.color = '#ddd';
          }
        });
      });
      
      document.getElementById('reviewFormModal').addEventListener('submit', async (e)=>{
        e.preventDefault();
        const rating=parseInt(document.getElementById('modalRating').value);
        const comment=document.getElementById('modalComment').value;
        const { submitReview } = await import('./review.js');
        submitReview(productId,rating,comment);
        bootstrap.Modal.getInstance(modalDiv).hide();
      });
    }
    new bootstrap.Modal(modalDiv).show();
  }

  // Function to change main image when thumbnail is clicked
  // Store reference to thumbnails for reuse
  const thumbImages = document.querySelectorAll('#thumbs img');
  // Initially mark first thumb active
  thumbImages[0]?.classList.add('active');

  window.changeMainImage = function(newImageUrl, thumbEl) {
    const mainImage = document.querySelector('.col-lg-6 .border img');
    if (mainImage) {
      // fade transition
      mainImage.style.opacity = 0;
      // once image loaded bring back opacity
      const onLoad = () => {
        mainImage.style.opacity = 1;
        mainImage.removeEventListener('load', onLoad);
      };
      mainImage.addEventListener('load', onLoad);
      mainImage.src = newImageUrl;
    }
    // update active thumbnail highlight
    thumbImages.forEach(t => t.classList.remove('active'));
    if (thumbEl) thumbEl.classList.add('active');
  };

  // add to cart
  document.getElementById('addCartBtn')?.addEventListener('click', addHandler);
  mobBtn?.addEventListener('click', addHandler);
  // mobile bar
  if (mobBar && !isAdminUser && inStock) {
    mobBar.style.display = 'block';
    mobTotal.textContent = `$${price.toFixed(2)}`;
  }
  // plus/minus buttons
  document.getElementById('qtyPlus').addEventListener('click', () => {
    const current = parseInt(qtyInput.value) || 1;
    if (current < maxQty) {
      qtyInput.value = current + 1;
      qtyInput.dispatchEvent(new Event('input'));
    }
  });
  document.getElementById('qtyMinus').addEventListener('click', () => {
    const current = parseInt(qtyInput.value) || 1;
    if (current > 1) {
      qtyInput.value = current - 1;
      qtyInput.dispatchEvent(new Event('input'));
    }
  });

  // related products
fetch(`/api/products?category_id=${p.category_id}&limit=8`).then(r=>r.json()).then(d=>{
  if(d.success && d.data && d.data.length){
    const relatedProducts = d.data.filter(it=>it.id!==p.id).slice(0, 6);
    const relHTML = `
    <div class="mt-5 mb-4">
      <div class="d-flex align-items-center justify-content-between mb-4">
        <h3 class="fw-bold text-dark mb-0">
          <i class="bi bi-grid-3x3-gap-fill text-primary me-2"></i>
          You Might Also Like
        </h3>
        <a href="index.html" class="btn btn-outline-primary btn-sm">
          View All <i class="bi bi-arrow-right ms-1"></i>
        </a>
      </div>
      <div class="row row-cols-2 row-cols-md-3 row-cols-lg-4 g-4">
        ${relatedProducts.map(it => `
          <div class="col">
            <div class="card h-100 shadow-sm product-card" role="button" onclick="viewProduct(${it.id})">
              <img src="${getProductImage(it)}" class="card-img-top" alt="${it.name}" style="height: 250px; object-fit: cover;" onerror="ImageProxy.handleImageError(this)">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title mb-1 text-truncate">${it.name}</h5>
                <p class="card-text small text-muted mb-2">${it.brand_name || ''}${it.category_name ? ' • ' + it.category_name : ''}</p>
                <p class="card-text fw-bold text-primary mb-3">$${parseFloat(it.price).toFixed(2)}</p>
                <button class="btn btn-success btn-sm mt-auto w-100" onclick="event.stopPropagation(); addToCart(${it.id}, 1)"><i class="bi bi-cart-plus me-1"></i>Add to Cart</button>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
    <style>
    /* Ensure all suggestion cards align to equal height */
    .product-card {
      display: flex;
      flex-direction: column;
      height: 100%;
    }
    .product-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
    }
    /* Image behaviour (match product grid) */
    .product-card .card-img-top {
      height: 250px;
      object-fit: cover;
      transition: transform 0.3s ease;
    }
    .product-card:hover .card-img-top {
      transform: scale(1.05);
    }
    /* Body should stretch to fill remaining space */
    .product-card .card-body {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    /* Compare button */
    .product-card .compare-btn {
      opacity: 0;
      transition: opacity 0.3s ease;
    }
    .product-card:hover .compare-btn {
      opacity: 1;
    }
    </style>`;
    container.insertAdjacentHTML('beforeend', relHTML);
  }
});

// thumbs click to change main image
  // add click listeners to support keyboard navigation as fallback
  thumbImages.forEach(img => {
    img.addEventListener('click', () => changeMainImage(img.src, img));
  });
}

// set year in footer
 document.getElementById('yearCopy').textContent = new Date().getFullYear();
