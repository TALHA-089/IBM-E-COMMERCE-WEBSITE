import { authFetch, getUser } from './auth.js';
function showToast(message, type = 'info') {
  const alertContainer = document.getElementById('alertContainer');
  alertContainer.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
  setTimeout(() => (alertContainer.innerHTML = ''), 4000);
}

const user = getUser();
if (!user) {
  window.location.href = 'login.html';
}

document.addEventListener('DOMContentLoaded', () => {
  const user = JSON.parse(localStorage.getItem('user')||'{}');
  if(user.role === 'admin') { window.location.href = 'index.html'; return; }
  window.loadWishlist = loadWishlist;
  window.loadCart = loadCart;
  loadProfile();
  document.getElementById('additionalInfoForm').addEventListener('submit', onSave);
  initPhotoUploader();
  setupBioTextarea();
});

let currentPhoto = '';


function setupBioTextarea(){
  const bio = document.getElementById('bio');
  const counter = document.getElementById('bioCounter');
  if(!bio) return;
  const update=()=>{
    bio.style.height='auto';
    bio.style.height=bio.scrollHeight+'px';
    if(counter) counter.textContent = `${bio.value.length}/250`;
  };
  bio.addEventListener('input',update);
  update();
}


async function loadProfile() {
  try {
    const res = await authFetch('/api/users/profile');
    const data = await res.json();
    if (!data.success) throw new Error(data.message || 'Failed to load profile');
    const { user: u } = data;
    document.getElementById('userName').value = u.name;
    document.getElementById('userEmail').value = u.email;
    const additional = u.additional || {};
    document.getElementById('phone').value = additional.phone || '';
    document.getElementById('address').value = additional.address || '';
    document.getElementById('bio').value = additional.bio || '';
    if(additional.dob){
      document.getElementById('dob').value = additional.dob.split('T')[0];
    }
    if(additional.gender){
      const gId = additional.gender === 'M' ? 'genderMale' : 'genderFemale';
      const gRadio = document.getElementById(gId);
      if(gRadio) gRadio.checked = true;
    }
    if(additional.photo_base64){
      document.getElementById('profilePhoto').src = additional.photo_base64;
      currentPhoto = additional.photo_base64;
    }
    // stats side panel
    if(data.stats){
      document.getElementById('statOrders').textContent = data.stats.orders || 0;
      let wishCount = data.stats.wishlist;
      // fallback to localStorage if API returns 0
      if(!wishCount){
        try{
          const list = JSON.parse(localStorage.getItem('wishlist')||'[]');
          wishCount = list.length;
        }catch{}
      }
      document.getElementById('statWishlist').textContent = wishCount || 0;
      document.getElementById('statMemberSince').textContent = data.stats.memberSince || '';
    }
  } catch (err) {
    showToast(err.message, 'danger');
  }
}


function initPhotoUploader(){
  const drop = document.getElementById('photoDrop');
  const overlay = document.getElementById('photoOverlay');
  const fileInput = document.getElementById('photoFile');
  drop.addEventListener('click',()=>fileInput.click());
  ['dragenter','dragover'].forEach(evt=>drop.addEventListener(evt,e=>{e.preventDefault();overlay.style.opacity=1;}));
  ['dragleave','dragend','drop'].forEach(evt=>drop.addEventListener(evt,e=>{overlay.style.opacity=0;}));
  drop.addEventListener('drop',e=>{e.preventDefault();handleFiles(e.dataTransfer.files);});
  fileInput.addEventListener('change',()=>handleFiles(fileInput.files));
  const fab=document.querySelector('.avatar-fab');
  if(fab){
    fab.addEventListener('click',e=>{e.stopPropagation();fileInput.click();});
  }
  function handleFiles(files){
    if(!files.length) return;
    const file = files[0];
    const reader = new FileReader();
    reader.onload = () => {
      currentPhoto = reader.result;
      document.getElementById('profilePhoto').src = currentPhoto;
    };
    reader.readAsDataURL(file);
  }
}


async function onSave(e) {
  e.preventDefault();
  const body = {
    phone: document.getElementById('phone').value.trim(),
    address: document.getElementById('address').value.trim(),
    bio: document.getElementById('bio').value.trim(),
    photo_base64: currentPhoto,
    dob: document.getElementById('dob').value,
    gender: document.querySelector('input[name="gender"]:checked')?.value
  };
  try {
    const res = await authFetch('/api/users/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.message || 'Failed to save');
    showToast('Profile updated', 'success');
  } catch (err) {
    showToast(err.message, 'danger');
  }
}
