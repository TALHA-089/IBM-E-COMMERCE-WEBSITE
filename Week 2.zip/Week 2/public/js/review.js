import { authFetch, getUser, isLoggedIn } from './auth.js';

export async function loadReviews(productId) {
  const res = await fetch(`/api/reviews/product/${productId}`);
  const data = await res.json();
  if (data.success) {
    renderReviews(data.reviews, productId);
  }
}

export async function loadAverageRating(productId) {
  const res = await fetch(`/api/reviews/product/${productId}/average`);
  const data = await res.json();
  if (data.success) {
    renderAverageRating(data.avg);
  }
}

export async function submitReview(productId, rating, comment) {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
    return;
  }
  const res = await authFetch('/api/reviews/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ product_id: productId, rating, comment })
  });
  const data = await res.json();
  if (data.success) {
    showToast('Review submitted!', 'success');
    loadReviews(productId);
    loadAverageRating(productId);
  } else {
    showToast(data.message || 'Failed to submit review.', 'danger');
  }
}

export async function deleteReview(productId) {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
    return;
  }
  const res = await authFetch('/api/reviews/delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ product_id: productId })
  });
  const data = await res.json();
  if (data.success) {
    showToast('Review deleted.', 'success');
    loadReviews(productId);
    loadAverageRating(productId);
  } else {
    showToast(data.message || 'Failed to delete review.', 'danger');
  }
}

function renderReviews(reviews, productId) {
  const container = document.getElementById('reviewsContainer');
  if (!container) return;
  if (!reviews.length) {
    container.innerHTML = '<div class="alert alert-info">No reviews yet.</div>';
    return;
  }
  const user = getUser();
  container.innerHTML = reviews.map(r => `
    <div class="card mb-2">
      <div class="card-body d-flex justify-content-between align-items-center">
        <div>
          <strong>${r.user_name}</strong>
          <span class="ms-2 text-warning">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
          <p class="mb-0 small text-muted">${new Date(r.created_at).toLocaleString()}</p>
          <p class="mb-0">${r.comment || ''}</p>
        </div>
        ${user && user.id === r.user_id ? `<button class="btn btn-danger btn-sm" onclick="deleteReview(${productId})">Delete</button>` : ''}
      </div>
    </div>
  `).join('');
}

function renderAverageRating(avg) {
  const container = document.getElementById('averageRating');
  if (!container) return;
  const rating = avg.avg_rating ? parseFloat(avg.avg_rating).toFixed(1) : '0.0';
  const count = avg.review_count || 0;
  container.innerHTML = `<span class="text-warning">${'★'.repeat(Math.round(rating))}${'☆'.repeat(5 - Math.round(rating))}</span> <span class="ms-2">${rating} (${count} reviews)</span>`;
}

function showToast(message, type) {
  const toastContainer = document.getElementById('toastContainer');
  if (!toastContainer) return;
  toastContainer.innerHTML = `<div class="alert alert-${type} alert-dismissible fade show mt-3" role="alert">${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>`;
  setTimeout(() => { toastContainer.innerHTML = ''; }, 4000);
}

window.deleteReview = deleteReview; 