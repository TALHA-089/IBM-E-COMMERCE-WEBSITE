// track.js - customer order tracking page
const form = document.getElementById('trackForm');
const input = document.getElementById('trackingInput');
const resultDiv = document.getElementById('trackResult');

const STATUS_BADGE = {
  order_confirmed: 'secondary',
  processing: 'warning',
  shipped: 'info',
  out_for_delivery: 'primary',
  delivered: 'success',
  failed_delivery: 'danger',
  returned: 'dark'
};

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const code = input.value.trim();
  if (!code) return;
  showLoading();
  try {
    const res = await fetch(`/api/deliveries/track/${encodeURIComponent(code)}`);
    const data = await res.json();
    if (!data.success) throw new Error(data.message || 'Not found');
    renderTracking(data.data);
  } catch (err) {
    resultDiv.innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
});

function showLoading() {
  resultDiv.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
}

function renderTracking(info) {
  const { delivery, tracking_history, current_status } = info;
  let timeline = tracking_history.map(ev => `
    <li class="list-group-item d-flex justify-content-between align-items-start">
      <div>
        <h6 class="mb-1">${ev.description || ev.status}</h6>
        <small class="text-muted">${ev.location || '—'} • ${new Date(ev.event_timestamp).toLocaleString()}</small>
        ${ev.notes ? `<p class="mb-0 small">${ev.notes}</p>` : ''}
      </div>
      <span class="badge bg-${STATUS_BADGE[ev.status] || 'secondary'}">${ev.status.replace(/_/g,' ')}</span>
    </li>`).join('');
  if (!timeline) timeline = '<li class="list-group-item">No tracking updates yet.</li>';
  resultDiv.innerHTML = `
    <div class="card shadow-sm">
      <div class="card-header bg-white">
        <strong>Tracking #: </strong>${delivery.tracking_number}
        <span class="badge bg-${STATUS_BADGE[current_status?.status] || 'secondary'} ms-2 text-uppercase">${current_status?.status.replace(/_/g,' ')}</span>
      </div>
      <ul class="list-group list-group-flush">${timeline}</ul>
    </div>`;
}
