// Track Order JavaScript
const API_BASE = '/api';

// DOM Elements
const trackingForm = document.getElementById('trackingForm');
const trackingInput = document.getElementById('trackingInput');
const loadingState = document.getElementById('loadingState');
const trackingResults = document.getElementById('trackingResults');
const noResults = document.getElementById('noResults');
const orderInfo = document.getElementById('orderInfo');
const progressTimeline = document.getElementById('progressTimeline');
const trackingHistory = document.getElementById('trackingHistory');

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
    // Load user info in navbar
    await loadUserInfo();
    
    // Set current year in footer
    document.getElementById('yearCopy').textContent = new Date().getFullYear();
    
    // Check URL parameters for auto-tracking
    const urlParams = new URLSearchParams(window.location.search);
    const trackingNumber = urlParams.get('tracking');
    const orderId = urlParams.get('order');
    
    if (trackingNumber) {
        trackingInput.value = trackingNumber;
        trackOrder();
    } else if (orderId) {
        trackingInput.value = orderId;
        trackOrder();
    }

    // Listen for real-time delivery updates
    window.addEventListener('deliveryUpdate', (event) => {
        const notification = event.detail;
        if (trackingInput.value === notification.tracking_number || 
            trackingInput.value === notification.order_id.toString()) {
            // Refresh tracking information
            setTimeout(() => trackOrder(), 1000);
            
            // Show update notification
            showAlert(`Status Updated: ${notification.status_description}`, 'success');
        }
    });
});

// Load user info for navbar
async function loadUserInfo() {
    try {
        const { isLoggedIn, getUser } = await import('./auth.js');
        const navbarUser = document.getElementById('navbarUser');
        
        if (isLoggedIn()) {
            const userInfo = getUser();
            navbarUser.innerHTML = `
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i>${userInfo?.name || 'User'}
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="profile.html">Profile</a></li>
                        <li><a class="dropdown-item" href="#" onclick="logout()">Logout</a></li>
                    </ul>
                </li>
            `;
        } else {
            navbarUser.innerHTML = `
                <li class="nav-item">
                    <a class="nav-link" href="login.html">Login</a>
                </li>
            `;
        }
    } catch (error) {
        console.error('Error loading user info:', error);
    }
}

// Handle form submission
trackingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    trackOrder();
});

// Main tracking function
async function trackOrder() {
    const input = trackingInput.value.trim();
    if (!input) {
        showAlert('Please enter a tracking number or order ID', 'warning');
        return;
    }

    showLoading(true);
    hideAllSections();

    try {
        let trackingData = null;
        
        // Determine if input is tracking number or order ID
        if (input.startsWith('TRK') || input.length > 10) {
            // Tracking number
            trackingData = await fetchTrackingByNumber(input);
        } else {
            // Order ID
            trackingData = await fetchTrackingByOrderId(input);
        }

        if (trackingData) {
            displayTrackingResults(trackingData);
        } else {
            showNoResults();
        }
    } catch (error) {
        console.error('Tracking error:', error);
        showAlert('Failed to fetch tracking information. Please try again.', 'danger');
        showNoResults();
    } finally {
        showLoading(false);
    }
}

// Fetch tracking by tracking number
async function fetchTrackingByNumber(trackingNumber) {
    const response = await fetch(`${API_BASE}/deliveries/track/${trackingNumber}`);
    const data = await response.json();
    
    if (data.success) {
        return data.data;
    }
    return null;
}

// Fetch tracking by order ID
async function fetchTrackingByOrderId(orderId) {
    try {
        const { getAccessToken } = await import('./auth.js');
        const token = getAccessToken();
        
        if (!token) {
            showAlert('Please login to track orders by Order ID', 'warning');
            return null;
        }

        const response = await fetch(`${API_BASE}/deliveries/order/${orderId}/tracking`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            return {
                delivery: {
                    order_id: data.data.order_id,
                    tracking_number: data.data.tracking_number,
                    delivery_method: data.data.delivery_method,
                    estimated_delivery_date: data.data.estimated_delivery,
                    actual_delivery_date: data.data.actual_delivery
                },
                tracking_history: data.data.tracking_history,
                current_status: data.data.current_status
            };
        }
        return null;
    } catch (error) {
        console.error('Order tracking error:', error);
        return null;
    }
}

// Display tracking results
function displayTrackingResults(data) {
    const { delivery, tracking_history, current_status } = data;
    
    // Display order information
    displayOrderInfo(delivery);
    
    // Display progress timeline
    displayProgressTimeline(tracking_history, current_status);
    
    // Display tracking history
    displayTrackingHistory(tracking_history);
    
    trackingResults.classList.remove('d-none');
}

// Display order information
function displayOrderInfo(delivery) {
    const estimatedDate = delivery.estimated_delivery_date ? 
        new Date(delivery.estimated_delivery_date).toLocaleDateString() : 'TBD';
    const actualDate = delivery.actual_delivery_date ? 
        new Date(delivery.actual_delivery_date).toLocaleDateString() : null;

    orderInfo.innerHTML = `
        <div class="col-md-6">
            <div class="mb-3">
                <strong class="text-muted">Order ID:</strong>
                <div class="fs-5">#${delivery.order_id}</div>
            </div>
            <div class="mb-3">
                <strong class="text-muted">Tracking Number:</strong>
                <div class="fs-5 font-monospace">${delivery.tracking_number || 'Not assigned'}</div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <strong class="text-muted">Delivery Method:</strong>
                <div class="fs-5 text-capitalize">${delivery.delivery_method || 'Standard'}</div>
            </div>
            <div class="mb-3">
                <strong class="text-muted">${actualDate ? 'Delivered On:' : 'Estimated Delivery:'}</strong>
                <div class="fs-5 ${actualDate ? 'text-success' : ''}">${actualDate || estimatedDate}</div>
            </div>
        </div>
    `;
}

// Display progress timeline
function displayProgressTimeline(history, currentStatus) {
    const statuses = [
        { key: 'order_confirmed', label: 'Order Confirmed', icon: 'check-circle' },
        { key: 'processing', label: 'Processing', icon: 'gear' },
        { key: 'shipped', label: 'Shipped', icon: 'truck' },
        { key: 'out_for_delivery', label: 'Out for Delivery', icon: 'geo-alt' },
        { key: 'delivered', label: 'Delivered', icon: 'house-check' }
    ];

    const completedStatuses = history.map(h => h.status);
    const currentStatusKey = currentStatus?.status || 'order_confirmed';

    let timelineHTML = '<div class="row">';
    
    statuses.forEach((status, index) => {
        const isCompleted = completedStatuses.includes(status.key);
        const isCurrent = status.key === currentStatusKey;
        const statusClass = isCompleted ? 'text-success' : isCurrent ? 'text-primary' : 'text-muted';
        const bgClass = isCompleted ? 'bg-success' : isCurrent ? 'bg-primary' : 'bg-light';
        
        timelineHTML += `
            <div class="col text-center">
                <div class="position-relative">
                    <div class="rounded-circle ${bgClass} text-white d-inline-flex align-items-center justify-content-center" 
                         style="width: 50px; height: 50px;">
                        <i class="bi bi-${status.icon} fs-5"></i>
                    </div>
                    ${index < statuses.length - 1 ? `
                        <div class="position-absolute top-50 start-100 translate-middle-y ${isCompleted ? 'bg-success' : 'bg-light'}" 
                             style="height: 3px; width: calc(100% - 25px); z-index: -1;"></div>
                    ` : ''}
                </div>
                <div class="mt-2">
                    <small class="fw-semibold ${statusClass}">${status.label}</small>
                </div>
            </div>
        `;
    });
    
    timelineHTML += '</div>';
    
    if (currentStatus) {
        timelineHTML += `
            <div class="mt-4 p-3 bg-light rounded">
                <div class="d-flex align-items-center">
                    <i class="bi bi-info-circle text-primary me-2"></i>
                    <strong>Current Status:</strong>
                    <span class="ms-2">${currentStatus.description}</span>
                </div>
                ${currentStatus.location ? `
                    <div class="mt-2 text-muted">
                        <i class="bi bi-geo-alt me-1"></i>Location: ${currentStatus.location}
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    progressTimeline.innerHTML = timelineHTML;
}

// Display tracking history
function displayTrackingHistory(history) {
    if (!history || history.length === 0) {
        trackingHistory.innerHTML = `
            <div class="text-center text-muted py-4">
                <i class="bi bi-clock-history display-4"></i>
                <p class="mt-2">No tracking events yet</p>
            </div>
        `;
        return;
    }

    let historyHTML = '<div class="timeline">';
    
    history.reverse().forEach((event, index) => {
        const eventDate = new Date(event.event_timestamp);
        const isLatest = index === 0;
        
        historyHTML += `
            <div class="d-flex mb-4 ${isLatest ? 'border-start border-primary border-3 ps-3' : 'border-start border-light border-2 ps-3'}">
                <div class="flex-shrink-0 me-3">
                    <div class="rounded-circle ${isLatest ? 'bg-primary' : 'bg-secondary'} text-white d-flex align-items-center justify-content-center" 
                         style="width: 40px; height: 40px;">
                        <i class="bi bi-${getStatusIcon(event.status)}"></i>
                    </div>
                </div>
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="mb-1 ${isLatest ? 'text-primary' : ''}">${event.description}</h6>
                            ${event.location ? `<p class="text-muted small mb-1"><i class="bi bi-geo-alt me-1"></i>${event.location}</p>` : ''}
                            ${event.notes ? `<p class="text-muted small mb-0">${event.notes}</p>` : ''}
                        </div>
                        <small class="text-muted">${eventDate.toLocaleString()}</small>
                    </div>
                </div>
            </div>
        `;
    });
    
    historyHTML += '</div>';
    trackingHistory.innerHTML = historyHTML;
}

// Get icon for status
function getStatusIcon(status) {
    const icons = {
        'order_confirmed': 'check-circle',
        'processing': 'gear',
        'shipped': 'truck',
        'out_for_delivery': 'geo-alt',
        'delivered': 'house-check',
        'failed_delivery': 'exclamation-triangle',
        'returned': 'arrow-return-left'
    };
    return icons[status] || 'circle';
}

// Utility functions
function showLoading(show) {
    loadingState.classList.toggle('d-none', !show);
}

function hideAllSections() {
    trackingResults.classList.add('d-none');
    noResults.classList.add('d-none');
}

function showNoResults() {
    noResults.classList.remove('d-none');
}

function resetForm() {
    trackingInput.value = '';
    hideAllSections();
    trackingInput.focus();
}

function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alertContainer');
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    alertContainer.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Logout function
async function logout() {
    try {
        const { logout: authLogout } = await import('./auth.js');
        authLogout();
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Logout error:', error);
    }
}
