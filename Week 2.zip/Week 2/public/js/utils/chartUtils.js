// Utility for safely managing Chart.js instances

/**
 * Safely destroys a Chart.js instance if it exists and has a destroy method
 * @param {Chart | null} chartInstance - The Chart.js instance to destroy
 * @returns {null}
 */
function safeDestroyChart(chartInstance) {
    if (chartInstance && typeof chartInstance.destroy === 'function') {
        chartInstance.destroy();
    }
    return null;
}

/**
 * Creates a new Chart.js instance with error handling
 * @param {HTMLCanvasElement | string} ctx - Canvas element or its selector
 * @param {Object} config - Chart configuration object
 * @returns {Chart | null} - New chart instance or null if creation fails
 */
function createChart(ctx, config) {
    try {
        const canvas = typeof ctx === 'string' ? document.querySelector(ctx) : ctx;
        if (!canvas) {
            console.error('Canvas element not found');
            return null;
        }
        
        // Destroy any existing chart instances on this canvas
        const existingChart = window.Chart.getChart(canvas);
        if (existingChart) {
            existingChart.destroy();
        }
        
        return new window.Chart(canvas.getContext('2d'), config);
    } catch (error) {
        console.error('Failed to create chart:', error);
        return null;
    }
}

export { safeDestroyChart, createChart };
