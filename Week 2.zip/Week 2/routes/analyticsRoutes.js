const express = require('express');
const router = express.Router();
const analyticsController = require('../controllers/analyticsController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// All analytics routes require admin authentication
router.use(auth);
router.use(roleCheck(['admin']));

// Delivery analytics routes
router.get('/delivery', analyticsController.getDeliveryAnalytics);
router.get('/carrier-performance', analyticsController.getCarrierPerformance);
router.get('/customer-satisfaction', analyticsController.getCustomerSatisfaction);
router.get('/cost-analysis', analyticsController.getCostAnalysis);

module.exports = router;
