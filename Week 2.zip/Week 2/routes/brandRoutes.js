const express = require('express');
const router = express.Router();
const {
  getAllBrands,
  getBrandById,
  getBrandsByCategory,
  createBrand,
  updateBrand,
  deleteBrand,
  getBrandsWithProductCount
} = require('../controllers/brandController');

const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// GET /api/brands - Get all brands
router.get('/', getAllBrands);

// GET /api/brands/stats - Get brands with product count
router.get('/stats', getBrandsWithProductCount);

// GET /api/brands/category/:categoryId - Get brands by category
router.get('/category/:categoryId', getBrandsByCategory);

// GET /api/brands/:id - Get brand by ID
router.get('/:id', getBrandById);

// POST /api/brands - Create new brand
router.post('/', auth, roleCheck('admin'), createBrand);

// PUT /api/brands/:id - Update brand
router.put('/:id', auth, roleCheck('admin'), updateBrand);

// DELETE /api/brands/:id - Delete brand
router.delete('/:id', auth, roleCheck('admin'), deleteBrand);

module.exports = router; 