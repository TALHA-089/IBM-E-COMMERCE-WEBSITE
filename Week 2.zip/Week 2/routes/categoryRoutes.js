const express = require('express');
const router = express.Router();
const {
  getAllCategories,
  getCategoryById,
  createCategory,
  updateCategory,
  deleteCategory,
  getCategoriesWithBrandCount
} = require('../controllers/categoryController');

const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// GET /api/categories - Get all categories
router.get('/', getAllCategories);

// GET /api/categories/stats - Get categories with brand count
router.get('/stats', getCategoriesWithBrandCount);

// GET /api/categories/:id - Get category by ID
router.get('/:id', getCategoryById);

// POST /api/categories - Create new category
router.post('/', auth, roleCheck('admin'), createCategory);

// PUT /api/categories/:id - Update category
router.put('/:id', auth, roleCheck('admin'), updateCategory);

// DELETE /api/categories/:id - Delete category
router.delete('/:id', auth, roleCheck('admin'), deleteCategory);

module.exports = router; 