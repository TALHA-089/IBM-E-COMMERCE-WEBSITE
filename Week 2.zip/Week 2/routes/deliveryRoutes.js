const express = require('express');
const router = express.Router();
const deliveryController = require('../controllers/deliveryController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// Public route - track by tracking number
router.get('/track/:tracking_number', deliveryController.getTracking);

// Protected routes - require authentication
router.use(auth);

// Customer routes
router.get('/my-deliveries', deliveryController.getUserDeliveries);
router.get('/order/:order_id/tracking', deliveryController.getOrderTracking);

// Admin routes - require admin role
router.post('/order/:order_id/create', roleCheck(['admin']), deliveryController.createDelivery);
router.put('/:delivery_id/status', roleCheck(['admin']), deliveryController.updateDeliveryStatus);
router.get('/statuses', roleCheck(['admin']), deliveryController.getDeliveryStatuses);

module.exports = router;
