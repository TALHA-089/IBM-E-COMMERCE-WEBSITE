const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

router.post('/place', auth, orderController.placeOrder);
router.get('/my-orders', auth, orderController.getMyOrders);
router.get('/my', auth, orderController.getMyOrders);
router.get('/all', auth, roleCheck('admin'), orderController.getAllOrders);
router.get('/stats', auth, roleCheck('admin'), orderController.getStats);
router.get('/:id', auth, orderController.getOrderById);
router.patch('/:id/cancel', auth, orderController.cancelOrder);

module.exports = router; 