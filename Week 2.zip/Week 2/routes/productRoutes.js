const express = require('express');
const router = express.Router();
const {
  getAllProducts,
  getProductById,
  getProductsByBrand,
  getProductsByCategory,
  createProduct,
  updateProduct,
  deleteProduct,
  searchProducts,
  getProductStats
} = require('../controllers/productController');

const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// GET /api/products - Get all products
router.get('/', getAllProducts);

// GET /api/products/search - Search products
router.get('/search', searchProducts);

// GET /api/products/stats - Get product statistics
router.get('/stats', getProductStats);

// GET /api/products/brand/:brandId - Get products by brand
router.get('/brand/:brandId', getProductsByBrand);

// GET /api/products/category/:categoryId - Get products by category
router.get('/category/:categoryId', getProductsByCategory);

// GET /api/products/:id - Get product by ID
router.get('/:id', getProductById);

// POST /api/products - Create new product
router.post('/', auth, roleCheck('admin'), createProduct);

// PUT /api/products/:id - Update product
router.put('/:id', auth, roleCheck('admin'), updateProduct);

// DELETE /api/products/:id - Delete product
router.delete('/:id', auth, roleCheck('admin'), deleteProduct);

module.exports = router; 