const express = require('express');
const router = express.Router();
const reviewController = require('../controllers/reviewController');
const auth = require('../middleware/auth');

router.get('/product/:product_id', reviewController.getByProduct);
router.get('/product/:product_id/average', reviewController.getAverageRating);
router.get('/my', auth, reviewController.getByUser);
router.post('/add', auth, reviewController.addOrUpdate);
router.post('/delete', auth, reviewController.delete);

module.exports = router; 