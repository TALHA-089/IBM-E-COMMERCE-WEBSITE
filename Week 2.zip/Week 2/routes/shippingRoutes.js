const express = require('express');
const router = express.Router();
const shippingController = require('../controllers/shippingController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// Public routes
router.get('/carriers', shippingController.getCarriers);

// Protected routes - require authentication
router.use(auth);

// Customer routes
router.post('/rates', shippingController.getShippingRates);
router.get('/track-external/:tracking_number', shippingController.trackExternalShipment);

// Admin routes - require admin role
router.post('/order/:order_id/create-shipment', roleCheck(['admin']), shippingController.createShipment);

module.exports = router;
