const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// Public
router.post('/register', userController.register);
router.post('/login', userController.login);
router.post('/logout', userController.logout);
router.get('/verify-email', userController.verifyEmail);

// Authenticated
router.get('/profile', auth, userController.getProfile);
router.put('/profile', auth, userController.updateAdditionalInfo);

// Admin only
router.get('/all', auth, roleCheck('admin'), userController.getAllUsers);
router.get('/stats', auth, roleCheck('admin'), userController.getStats);

module.exports = router; 