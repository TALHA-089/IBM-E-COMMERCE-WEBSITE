#!/bin/bash

echo "🏪 Imarat Builders Mall CRUD System Setup"
echo "=========================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if PostgreSQL is running
if ! pg_isready -q; then
    echo "❌ PostgreSQL is not running. Please start PostgreSQL first."
    exit 1
fi

echo "✅ Node.js and PostgreSQL are available"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if config.env exists
if [ ! -f "config.env" ]; then
    echo "❌ config.env file not found. Please create it with your database credentials."
    echo "Example config.env:"
    echo "DB_HOST=localhost"
    echo "DB_PORT=5432"
    echo "DB_NAME=imarat_mall"
    echo "DB_USER=your_username"
    echo "DB_PASSWORD=your_password"
    echo "PORT=3000"
    echo "NODE_ENV=development"
    exit 1
fi

echo "✅ Configuration file found"

# Initialize database
echo "🗄️  Initializing database..."
npm run init-db

if [ $? -eq 0 ]; then
    echo "✅ Database initialized successfully"
else
    echo "❌ Database initialization failed. Please check your database credentials."
    exit 1
fi

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "To start the application:"
echo "  npm run dev    # Development mode with auto-reload"
echo "  npm start      # Production mode"
echo ""
echo "Access the application at: http://localhost:3000"
echo "API health check at: http://localhost:3000/api/health" 