const nodemailer = require('nodemailer');
const pool = require('../database/connection');

class NotificationService {
    constructor() {
        // Email transporter setup
        this.emailTransporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });

        // WebSocket instance (will be set by server)
        this.io = null;
    }

    // Set WebSocket instance
    setSocketIO(io) {
        this.io = io;
    }

    // Send email notification
    async sendEmailNotification(userEmail, subject, htmlContent) {
        try {
            const mailOptions = {
                from: process.env.EMAIL_USER,
                to: userEmail,
                subject: subject,
                html: htmlContent
            };

            await this.emailTransporter.sendMail(mailOptions);
            console.log(`Email sent to ${userEmail}: ${subject}`);
            return true;
        } catch (error) {
            console.error('Email notification error:', error);
            return false;
        }
    }

    // Send real-time notification via WebSocket
    sendRealTimeNotification(userId, notification) {
        if (this.io) {
            this.io.to(`user_${userId}`).emit('delivery_update', notification);
            console.log(`Real-time notification sent to user ${userId}`);
        }
    }

    // Send delivery status notification
    async sendDeliveryStatusNotification(orderId, status, location, notes) {
        try {
            // Get order and user details
            const orderQuery = 'SELECT o.*, u.name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = $1';
            const orderResult = await pool.query(orderQuery, [orderId]);
            
            if (orderResult.rows.length === 0) {
                console.warn(`Order ${orderId} not found for notification`);
                return;
            }
            
            const order = orderResult.rows[0];
            
            // Get delivery info
            const deliveryQuery = 'SELECT tracking_number FROM deliveries WHERE order_id = $1';
            const deliveryResult = await pool.query(deliveryQuery, [orderId]);
            const trackingNumber = deliveryResult.rows[0]?.tracking_number || 'N/A';
            
            // Status descriptions
            const statusDescriptions = {
                'order_confirmed': 'Order Confirmed',
                'processing': 'Processing',
                'shipped': 'Shipped',
                'out_for_delivery': 'Out for Delivery',
                'delivered': 'Delivered',
                'failed_delivery': 'Delivery Failed',
                'returned': 'Returned'
            };
            
            const statusDescription = statusDescriptions[status] || status;
            
            // Create notification
            const notification = {
                user_id: order.user_id,
                type: 'delivery_update',
                title: `Order #${orderId} - ${statusDescription}`,
                message: `Your order status has been updated to: ${statusDescription}`,
                data: {
                    order_id: orderId,
                    status,
                    status_description: statusDescription,
                    tracking_number: trackingNumber,
                    location,
                    notes
                }
            };
            
            // Save to database
            await this.saveNotification(notification);
            
            // Send real-time notification via WebSocket
            if (this.io) {
                // Notify customer
                this.io.to(`user_${order.user_id}`).emit('deliveryUpdate', {
                    order_id: orderId,
                    status,
                    status_description: statusDescription,
                    tracking_number: trackingNumber,
                    location,
                    notes,
                    timestamp: new Date().toISOString()
                });
                
                // Notify all admins
                this.io.emit('orderStatusUpdate', {
                    order_id: orderId,
                    customer_name: order.name,
                    status: statusDescription,
                    tracking_number: trackingNumber,
                    location,
                    notes,
                    timestamp: new Date().toISOString()
                });
            }
            
            // Send email notification
            if (order.email) {
                const emailSubject = `Order Update - ${statusDescription}`;
                const emailBody = `
                    <h2>Order Status Update</h2>
                    <p>Hello ${order.name},</p>
                    <p>Your order #${orderId} status has been updated:</p>
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
                        <strong>Status:</strong> ${statusDescription}<br>
                        <strong>Tracking Number:</strong> ${trackingNumber}<br>
                        ${location ? `<strong>Location:</strong> ${location}<br>` : ''}
                        ${notes ? `<strong>Notes:</strong> ${notes}<br>` : ''}
                    </div>
                    <p>You can track your order at: <a href="${process.env.BASE_URL || 'http://localhost:3000'}/track-order.html?tracking=${trackingNumber}">Track Order</a></p>
                    <p>Thank you for shopping with Imarat Builders Mall!</p>
                `;
                
                await this.sendEmailNotification(order.email, emailSubject, emailBody);
            }
            
            console.log(`Delivery notification sent for order ${orderId}: ${statusDescription}`);
            
        } catch (error) {
            console.error('Error sending delivery status notification:', error);
        }
    }

    // Send order confirmation email
    async sendOrderConfirmationEmail(orderId, user) {
        try {
            // Get order details with items
            const orderQuery = `
                SELECT o.*, o.tracking_number
                FROM orders o
                WHERE o.id = $1
            `;
            
            const [orderResult] = await pool.query(orderQuery, [orderId]);
            if (!orderResult.rows || !orderResult.rows.length) {
                throw new Error('Order not found');
            }
            
            const order = orderResult.rows[0];
            
            // Get order items with product details
            const itemsQuery = `
                SELECT oi.*, p.name as product_name, p.image_url, b.name as brand_name
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                LEFT JOIN brands b ON p.brand_id = b.id
                WHERE oi.order_id = $1
            `;
            
            const [itemsResult] = await pool.query(itemsQuery, [orderId]);
            const items = itemsResult.rows || [];
            
            // Generate professional email template
            const emailSubject = `Order Confirmation #${orderId} - Imarat Builders Mall`;
            const emailBody = this.generateOrderConfirmationTemplate(order, items, user);
            
            // Send email
            await this.sendEmailNotification(user.email, emailSubject, emailBody);
            
            console.log(`Order confirmation email sent to ${user.email} for order ${orderId}`);
            return true;
            
        } catch (error) {
            console.error('Error sending order confirmation email:', error);
            throw error;
        }
    }

    // Generate professional order confirmation email template
    generateOrderConfirmationTemplate(order, items, user) {
        const orderDate = new Date(order.created_at).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const itemsHtml = items.map(item => `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding: 15px; vertical-align: top;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 60px; height: 60px; background: #f8f9fa; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                            ${item.image_url ? 
                                `<img src="${item.image_url}" alt="${item.product_name}" style="width: 100%; height: 100%; object-fit: cover; border-radius: 6px;">` : 
                                `<span style="color: #6c757d; font-size: 24px;">📦</span>`
                            }
                        </div>
                        <div>
                            <h4 style="margin: 0 0 5px 0; color: #2c3e50; font-size: 16px;">${item.product_name}</h4>
                            <p style="margin: 0; color: #6c757d; font-size: 14px;">Brand: ${item.brand_name || 'N/A'}</p>
                            <p style="margin: 5px 0 0 0; color: #6c757d; font-size: 14px;">Quantity: ${item.quantity}</p>
                        </div>
                    </div>
                </td>
                <td style="padding: 15px; text-align: right; vertical-align: top;">
                    <strong style="color: #2c3e50; font-size: 16px;">$${parseFloat(item.price * item.quantity).toFixed(2)}</strong>
                </td>
            </tr>
        `).join('');

        return `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Order Confirmation</title>
            <style>
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f8f9fa; }
                .container { max-width: 600px; margin: 0 auto; background: white; }
                .header { background: linear-gradient(135deg, #6C63FF 0%, #5A52E8 100%); color: white; padding: 40px 30px; text-align: center; }
                .header h1 { margin: 0; font-size: 28px; font-weight: 300; }
                .header p { margin: 10px 0 0 0; opacity: 0.9; font-size: 16px; }
                .content { padding: 30px; }
                .order-summary { background: #f8f9fa; border-radius: 12px; padding: 25px; margin: 25px 0; }
                .order-details { display: flex; justify-content: space-between; margin-bottom: 20px; }
                .order-details div { text-align: center; }
                .order-details h3 { margin: 0; color: #6C63FF; font-size: 18px; }
                .order-details p { margin: 5px 0 0 0; color: #6c757d; font-size: 14px; }
                .items-table { width: 100%; border-collapse: collapse; margin: 25px 0; }
                .total-section { background: #6C63FF; color: white; padding: 20px; border-radius: 8px; text-align: center; margin: 25px 0; }
                .total-section h3 { margin: 0; font-size: 24px; }
                .tracking-section { background: #e8f5e8; border-radius: 8px; padding: 20px; margin: 25px 0; text-align: center; }
                .btn { display: inline-block; background: #6C63FF; color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; font-weight: 500; margin: 10px 0; }
                .btn:hover { background: #5A52E8; }
                .footer { background: #2c3e50; color: white; padding: 30px; text-align: center; font-size: 14px; }
                .footer a { color: #6C63FF; text-decoration: none; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎉 Order Confirmed!</h1>
                    <p>Thank you for shopping with Imarat Builders Mall</p>
                </div>
                
                <div class="content">
                    <p>Hi <strong>${user.first_name || user.name}</strong>,</p>
                    
                    <p>Great news! Your order has been successfully placed and confirmed. We're excited to get your items ready for delivery.</p>
                    
                    <div class="order-summary">
                        <div class="order-details">
                            <div>
                                <h3>#${order.id}</h3>
                                <p>Order Number</p>
                            </div>
                            <div>
                                <h3>${orderDate}</h3>
                                <p>Order Date</p>
                            </div>
                            <div>
                                <h3>${order.payment_method ? order.payment_method.toUpperCase() : 'CASH'}</h3>
                                <p>Payment Method</p>
                            </div>
                        </div>
                    </div>

                    <h3 style="color: #2c3e50; border-bottom: 2px solid #6C63FF; padding-bottom: 10px;">Order Items</h3>
                    <table class="items-table">
                        ${itemsHtml}
                    </table>

                    <div class="total-section">
                        <h3>Total Amount: $${parseFloat(order.total_amount).toFixed(2)}</h3>
                        ${order.subtotal ? `<p style="margin: 5px 0; opacity: 0.9;">Subtotal: $${parseFloat(order.subtotal).toFixed(2)} | Shipping: $${parseFloat(order.shipping_cost || 0).toFixed(2)} | Tax: $${parseFloat(order.tax_amount || 0).toFixed(2)}</p>` : ''}
                    </div>

                    ${order.tracking_number ? `
                    <div class="tracking-section">
                        <h4 style="margin: 0 0 10px 0; color: #2c3e50;">📦 Track Your Order</h4>
                        <p style="margin: 0 0 15px 0; color: #6c757d;">Tracking Number: <strong>${order.tracking_number}</strong></p>
                        <a href="${process.env.BASE_URL || 'http://localhost:3000'}/track-order.html?tracking=${order.tracking_number}" class="btn">Track Order</a>
                    </div>
                    ` : ''}

                    <h3 style="color: #2c3e50; margin-top: 30px;">What happens next?</h3>
                    <ul style="color: #6c757d; padding-left: 20px;">
                        <li>We'll process your order within 1-2 business days</li>
                        <li>You'll receive shipping confirmation with tracking details</li>
                        <li>Your order will be delivered to your specified address</li>
                        <li>You can track your order status anytime using the link above</li>
                    </ul>

                    <p style="margin-top: 30px;">If you have any questions about your order, please don't hesitate to contact our customer support team.</p>
                    
                    <p>Thank you for choosing Imarat Builders Mall!</p>
                    
                    <p style="color: #6c757d; font-size: 14px; margin-top: 30px;">
                        <strong>Need help?</strong><br>
                        Visit our <a href="${process.env.BASE_URL || 'http://localhost:3000'}" style="color: #6C63FF;">website</a> or contact support.
                    </p>
                </div>
                
                <div class="footer">
                    <p><strong>Imarat Builders Mall</strong></p>
                    <p>Your trusted partner for quality building materials and home improvement solutions.</p>
                    <p style="margin-top: 20px; opacity: 0.8;">
                        © ${new Date().getFullYear()} Imarat Builders Mall. All rights reserved.<br>
                        This is an automated message. Please do not reply to this email.
                    </p>
                </div>
            </div>
        </body>
        </html>
        `;
    }

    // Save notification to database
    async saveNotification(notification) {
        try {
            const query = `
                INSERT INTO notifications (user_id, type, title, message, data, created_at)
                VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP)
            `;
            
            await pool.query(query, [
                notification.user_id,
                notification.type,
                notification.title,
                notification.message,
                JSON.stringify(notification.data)
            ]);
        } catch (error) {
            console.error('Save notification error:', error);
        }
    }
}

module.exports = new NotificationService();
