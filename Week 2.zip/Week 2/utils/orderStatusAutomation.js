// Automated Order Status Progression System
const pool = require('../database/connection');
const Delivery = require('../models/Delivery');
const notificationService = require('./notificationService');

class OrderStatusAutomation {
    constructor() {
        this.isRunning = false;
        this.intervalId = null;
    }

    // Start the automation service
    start() {
        if (this.isRunning) {
            console.log('Order status automation is already running');
            return;
        }

        console.log('Starting order status automation service...');
        this.isRunning = true;
        
        // Run immediately
        this.processOrderProgression();
        
        // Run every 5 minutes
        this.intervalId = setInterval(() => {
            this.processOrderProgression();
        }, 5 * 60 * 1000);
        
        console.log('Order status automation service started');
    }

    // Stop the automation service
    stop() {
        if (!this.isRunning) {
            return;
        }

        console.log('Stopping order status automation service...');
        this.isRunning = false;
        
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
        
        console.log('Order status automation service stopped');
    }

    // Main processing function
    async processOrderProgression() {
        try {
            console.log('Processing order status progression...');
            
            await this.progressConfirmedToProcessing();
            await this.progressProcessingToShipped();
            await this.progressShippedToOutForDelivery();
            await this.progressOutForDeliveryToDelivered();
            
            console.log('Order status progression completed');
        } catch (error) {
            console.error('Error in order status progression:', error);
        }
    }

    // Progress orders from confirmed to processing (after 2 hours)
    async progressConfirmedToProcessing() {
        const query = `
            SELECT d.id as delivery_id, d.order_id, d.tracking_number
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE o.delivery_status = 'pending'
            AND o.created_at <= NOW() - INTERVAL '2 hours'
            AND NOT EXISTS (
                SELECT 1 FROM tracking_events te 
                WHERE te.delivery_id = d.id 
                AND te.status_id = 2
            )
            LIMIT 10
        `;

        try {
            const result = await pool.query(query);
            
            for (const order of result.rows) {
                await Delivery.updateStatus(
                    order.delivery_id,
                    2, // processing status
                    'Processing Center',
                    'Order is being processed and prepared for shipment',
                    'system'
                );
                
                console.log(`Order #${order.order_id} progressed to processing`);
            }
        } catch (error) {
            console.error('Error progressing orders to processing:', error);
        }
    }

    // Progress orders from processing to shipped (after 1 day)
    async progressProcessingToShipped() {
        const query = `
            SELECT d.id as delivery_id, d.order_id, d.tracking_number
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE o.delivery_status = 'processing'
            AND o.created_at <= NOW() - INTERVAL '1 day'
            AND NOT EXISTS (
                SELECT 1 FROM tracking_events te 
                WHERE te.delivery_id = d.id 
                AND te.status_id = 3
            )
            LIMIT 10
        `;

        try {
            const result = await pool.query(query);
            
            for (const order of result.rows) {
                await Delivery.updateStatus(
                    order.delivery_id,
                    3, // shipped status
                    'Distribution Center',
                    'Package has been shipped and is in transit',
                    'system'
                );
                
                console.log(`Order #${order.order_id} progressed to shipped`);
            }
        } catch (error) {
            console.error('Error progressing orders to shipped:', error);
        }
    }

    // Progress orders from shipped to out for delivery (after 3 days)
    async progressShippedToOutForDelivery() {
        const query = `
            SELECT d.id as delivery_id, d.order_id, d.tracking_number
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE o.delivery_status = 'shipped'
            AND o.created_at <= NOW() - INTERVAL '3 days'
            AND NOT EXISTS (
                SELECT 1 FROM tracking_events te 
                WHERE te.delivery_id = d.id 
                AND te.status_id = 4
            )
            LIMIT 10
        `;

        try {
            const result = await pool.query(query);
            
            for (const order of result.rows) {
                await Delivery.updateStatus(
                    order.delivery_id,
                    4, // out for delivery status
                    'Local Delivery Hub',
                    'Package is out for delivery and will arrive soon',
                    'system'
                );
                
                console.log(`Order #${order.order_id} progressed to out for delivery`);
            }
        } catch (error) {
            console.error('Error progressing orders to out for delivery:', error);
        }
    }

    // Progress orders from out for delivery to delivered (after 5 days)
    async progressOutForDeliveryToDelivered() {
        const query = `
            SELECT d.id as delivery_id, d.order_id, d.tracking_number
            FROM deliveries d
            JOIN orders o ON d.order_id = o.id
            WHERE o.delivery_status = 'out_for_delivery'
            AND o.created_at <= NOW() - INTERVAL '5 days'
            AND NOT EXISTS (
                SELECT 1 FROM tracking_events te 
                WHERE te.delivery_id = d.id 
                AND te.status_id = 5
            )
            LIMIT 10
        `;

        try {
            const result = await pool.query(query);
            
            for (const order of result.rows) {
                await Delivery.updateStatus(
                    order.delivery_id,
                    5, // delivered status
                    'Customer Address',
                    'Package has been successfully delivered',
                    'system'
                );
                
                console.log(`Order #${order.order_id} progressed to delivered`);
            }
        } catch (error) {
            console.error('Error progressing orders to delivered:', error);
        }
    }

    // Manual progression for specific order
    async progressOrderManually(orderId, targetStatusId, location = '', notes = '') {
        try {
            const delivery = await Delivery.getByOrderId(orderId);
            if (!delivery) {
                throw new Error('Delivery not found for order');
            }

            await Delivery.updateStatus(
                delivery.id,
                targetStatusId,
                location,
                notes,
                'admin'
            );

            console.log(`Order #${orderId} manually progressed to status ${targetStatusId}`);
            return true;
        } catch (error) {
            console.error('Error in manual order progression:', error);
            throw error;
        }
    }

    // Get progression statistics
    async getProgressionStats() {
        try {
            const query = `
                SELECT 
                    o.delivery_status,
                    COUNT(*) as count,
                    AVG(EXTRACT(EPOCH FROM (NOW() - o.created_at))/3600) as avg_hours_since_creation
                FROM orders o
                WHERE o.created_at >= NOW() - INTERVAL '30 days'
                GROUP BY o.delivery_status
                ORDER BY 
                    CASE o.delivery_status
                        WHEN 'pending' THEN 1
                        WHEN 'processing' THEN 2
                        WHEN 'shipped' THEN 3
                        WHEN 'out_for_delivery' THEN 4
                        WHEN 'delivered' THEN 5
                        ELSE 6
                    END
            `;

            const result = await pool.query(query);
            return result.rows;
        } catch (error) {
            console.error('Error getting progression stats:', error);
            return [];
        }
    }
}

// Create singleton instance
const orderStatusAutomation = new OrderStatusAutomation();

module.exports = orderStatusAutomation;
