const fetch = require('node-fetch');

class ShippingService {
    constructor() {
        // ShipEngine API configuration
        this.shipengineConfig = {
            baseUrl: 'https://api.shipengine.com/v1',
            apiKey: process.env.SHIPENGINE_API_KEY,
            carriers: {
                usps: process.env.SHIPENGINE_USPS_CARRIER_ID,
                ups: process.env.SHIPENGINE_UPS_CARRIER_ID,
                fedex: process.env.SHIPENGINE_FEDEX_CARRIER_ID
            }
        };

        // Legacy configurations
        this.shipstationConfig = {
            baseUrl: 'https://ssapi.shipstation.com',
            apiKey: process.env.SHIPSTATION_API_KEY,
            apiSecret: process.env.SHIPSTATION_API_SECRET,
            storeId: process.env.SHIPSTATION_STORE_ID
        };

        this.fedexConfig = {
            baseUrl: 'https://apis.fedex.com',
            clientId: process.env.FEDEX_CLIENT_ID,
            clientSecret: process.env.FEDEX_CLIENT_SECRET,
            accountNumber: process.env.FEDEX_ACCOUNT_NUMBER
        };

        this.activeProvider = process.env.SHIPPING_PROVIDER || 'internal';
    }

    // Get shipping rates from multiple carriers
    async getShippingRates(shipment) {
        const { origin, destination, packages, serviceType = 'ground' } = shipment;
        
        try {
            switch (this.activeProvider) {
                case 'shipengine':
                    return await this.getShipEngineRates(origin, destination, packages, serviceType);
                case 'shipstation':
                    return await this.getShipStationRates(origin, destination, packages, serviceType);
                case 'fedex':
                    return await this.getFedExRates(origin, destination, packages, serviceType);
                default:
                    return this.getStandardRates(packages);
            }
        } catch (error) {
            console.error('Shipping rates error:', error);
            return this.getStandardRates(packages);
        }
    }

    // ShipEngine integration
    async getShipEngineRates(origin, destination, packages, serviceType) {
        if (!this.shipengineConfig.apiKey) {
            return this.getStandardRates(packages);
        }

        const rateRequest = {
            rate_options: {
                carrier_ids: [
                    this.shipengineConfig.carriers.usps,
                    this.shipengineConfig.carriers.ups,
                    this.shipengineConfig.carriers.fedex
                ].filter(Boolean)
            },
            shipment: {
                ship_to: {
                    name: "Customer",
                    address_line1: destination.address || "123 Main St",
                    city_locality: destination.city || "New York",
                    state_province: destination.state || "NY",
                    postal_code: destination.postalCode,
                    country_code: destination.country || "US"
                },
                ship_from: {
                    name: "Imarat Builders Mall",
                    address_line1: origin.address || "456 Business Ave",
                    city_locality: origin.city || "New York",
                    state_province: origin.state || "NY",
                    postal_code: origin.postalCode || "10001",
                    country_code: origin.country || "US"
                },
                packages: packages.map(pkg => ({
                    weight: {
                        value: pkg.weight || 1,
                        unit: "pound"
                    },
                    dimensions: {
                        unit: "inch",
                        length: pkg.length || 12,
                        width: pkg.width || 12,
                        height: pkg.height || 6
                    }
                }))
            }
        };

        try {
            const response = await fetch(`${this.shipengineConfig.baseUrl}/rates`, {
                method: 'POST',
                headers: {
                    'API-Key': this.shipengineConfig.apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(rateRequest)
            });

            if (!response.ok) {
                throw new Error(`ShipEngine API error: ${response.status}`);
            }

            const data = await response.json();
            return this.formatShipEngineRates(data.rate_response?.rates || []);
        } catch (error) {
            console.error('ShipEngine rates error:', error);
            return this.getStandardRates(packages);
        }
    }

    // ShipStation integration
    async getShipStationRates(origin, destination, packages, serviceType) {
        if (!this.shipstationConfig.apiKey) {
            return this.getStandardRates(packages);
        }

        const auth = Buffer.from(`${this.shipstationConfig.apiKey}:${this.shipstationConfig.apiSecret}`).toString('base64');
        
        const shipment = {
            carrierCode: 'fedex',
            serviceCode: this.mapServiceType(serviceType),
            packageCode: 'package',
            fromPostalCode: origin.postalCode,
            toState: destination.state,
            toPostalCode: destination.postalCode,
            toCountry: destination.country || 'US',
            weight: {
                value: packages.reduce((sum, pkg) => sum + pkg.weight, 0),
                units: 'pounds'
            },
            dimensions: packages[0] ? {
                units: 'inches',
                length: packages[0].length || 12,
                width: packages[0].width || 12,
                height: packages[0].height || 6
            } : null
        };

        try {
            const response = await fetch(`${this.shipstationConfig.baseUrl}/shipments/getrates`, {
                method: 'POST',
                headers: {
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(shipment)
            });

            if (!response.ok) {
                throw new Error(`ShipStation API error: ${response.status}`);
            }

            const data = await response.json();
            return this.formatShipStationRates(data);
        } catch (error) {
            console.error('ShipStation rates error:', error);
            return this.getStandardRates(packages);
        }
    }

    // FedEx integration
    async getFedExRates(origin, destination, packages, serviceType) {
        if (!this.fedexConfig.clientId) {
            return this.getStandardRates(packages);
        }

        try {
            // Get OAuth token first
            const token = await this.getFedExToken();
            
            const rateRequest = {
                accountNumber: {
                    value: this.fedexConfig.accountNumber
                },
                requestedShipment: {
                    shipper: {
                        address: {
                            postalCode: origin.postalCode,
                            countryCode: origin.country || 'US'
                        }
                    },
                    recipient: {
                        address: {
                            postalCode: destination.postalCode,
                            countryCode: destination.country || 'US'
                        }
                    },
                    serviceType: this.mapFedExServiceType(serviceType),
                    packagingType: 'YOUR_PACKAGING',
                    requestedPackageLineItems: packages.map(pkg => ({
                        weight: {
                            units: 'LB',
                            value: pkg.weight || 1
                        },
                        dimensions: {
                            length: pkg.length || 12,
                            width: pkg.width || 12,
                            height: pkg.height || 6,
                            units: 'IN'
                        }
                    }))
                }
            };

            const response = await fetch(`${this.fedexConfig.baseUrl}/rate/v1/rates/quotes`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(rateRequest)
            });

            if (!response.ok) {
                throw new Error(`FedEx API error: ${response.status}`);
            }

            const data = await response.json();
            return this.formatFedExRates(data);
        } catch (error) {
            console.error('FedEx rates error:', error);
            return this.getStandardRates(packages);
        }
    }

    // Get FedEx OAuth token
    async getFedExToken() {
        const response = await fetch(`${this.fedexConfig.baseUrl}/oauth/token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                grant_type: 'client_credentials',
                client_id: this.fedexConfig.clientId,
                client_secret: this.fedexConfig.clientSecret
            })
        });

        const data = await response.json();
        return data.access_token;
    }

    // Create shipment with tracking
    async createShipment(orderData, deliveryMethod = 'standard') {
        try {
            switch (this.activeProvider) {
                case 'shipengine':
                    return await this.createShipEngineShipment(orderData, deliveryMethod);
                case 'shipstation':
                    return await this.createShipStationShipment(orderData, deliveryMethod);
                case 'fedex':
                    return await this.createFedExShipment(orderData, deliveryMethod);
                default:
                    return this.createInternalShipment(orderData, deliveryMethod);
            }
        } catch (error) {
            console.error('Create shipment error:', error);
            return this.createInternalShipment(orderData, deliveryMethod);
        }
    }

    // Track shipment status
    async trackShipment(trackingNumber, carrier = 'internal') {
        try {
            switch (carrier) {
                case 'shipstation':
                case 'fedex':
                    return await this.trackExternalShipment(trackingNumber, carrier);
                default:
                    return null; // Use internal tracking
            }
        } catch (error) {
            console.error('Track shipment error:', error);
            return null;
        }
    }

    // Helper methods
    mapShipEngineServiceCode(deliveryMethod) {
        const mapping = {
            'standard': 'usps_ground_advantage',
            'express': 'ups_2nd_day_air',
            'overnight': 'fedex_standard_overnight',
            'pickup': 'pickup'
        };
        return mapping[deliveryMethod] || 'usps_ground_advantage';
    }

    mapServiceType(serviceType) {
        const mapping = {
            'standard': 'fedex_ground',
            'express': 'fedex_2_day',
            'overnight': 'fedex_standard_overnight',
            'pickup': 'pickup'
        };
        return mapping[serviceType] || 'fedex_ground';
    }

    mapFedExServiceType(serviceType) {
        const mapping = {
            'standard': 'FEDEX_GROUND',
            'express': 'FEDEX_2_DAY',
            'overnight': 'STANDARD_OVERNIGHT',
            'pickup': 'PICKUP'
        };
        return mapping[serviceType] || 'FEDEX_GROUND';
    }

    formatShipEngineRates(rates) {
        if (!rates || !Array.isArray(rates)) return this.getStandardRates([]);
        
        return rates.map(rate => ({
            carrier: rate.carrier_friendly_name || rate.carrier_code,
            service: rate.service_type,
            cost: parseFloat(rate.shipping_amount?.amount || 0),
            deliveryDays: rate.estimated_delivery_date ? 
                Math.ceil((new Date(rate.estimated_delivery_date) - new Date()) / (1000 * 60 * 60 * 24)) : 3,
            currency: rate.shipping_amount?.currency || 'USD',
            rate_id: rate.rate_id
        })).filter(rate => rate.cost > 0);
    }

    formatShipStationRates(data) {
        if (!data || !Array.isArray(data)) return this.getStandardRates([]);
        
        return data.map(rate => ({
            carrier: rate.carrierCode,
            service: rate.serviceName,
            cost: parseFloat(rate.shipmentCost),
            deliveryDays: rate.deliveryDays,
            currency: 'USD'
        }));
    }

    formatFedExRates(data) {
        if (!data?.output?.rateReplyDetails) return this.getStandardRates([]);
        
        return data.output.rateReplyDetails.map(rate => ({
            carrier: 'fedex',
            service: rate.serviceType,
            cost: parseFloat(rate.ratedShipmentDetails[0]?.totalNetCharge || 0),
            deliveryDays: rate.commit?.dateDetail?.dayOfWeek ? 1 : 3,
            currency: 'USD'
        }));
    }

    // Fallback standard rates
    getStandardRates(packages) {
        const totalWeight = packages.reduce((sum, pkg) => sum + (pkg.weight || 1), 0);
        const baseRate = Math.max(5.99, totalWeight * 0.5);
        
        return [
            { carrier: 'standard', service: 'Ground', cost: baseRate, deliveryDays: 5, currency: 'USD' },
            { carrier: 'express', service: 'Express', cost: baseRate * 1.5, deliveryDays: 3, currency: 'USD' },
            { carrier: 'overnight', service: 'Overnight', cost: baseRate * 3, deliveryDays: 1, currency: 'USD' }
        ];
    }

    createInternalShipment(orderData, deliveryMethod) {
        return {
            trackingNumber: `TRK${Date.now()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`,
            carrier: 'internal',
            service: deliveryMethod,
            estimatedDelivery: this.calculateDeliveryDate(deliveryMethod)
        };
    }

    calculateDeliveryDate(deliveryMethod) {
        const days = { standard: 5, express: 3, overnight: 1, pickup: 0 }[deliveryMethod] || 5;
        const date = new Date();
        date.setDate(date.getDate() + days);
        return date.toISOString().split('T')[0];
    }

    async createShipEngineShipment(orderData, deliveryMethod) {
        if (!this.shipengineConfig.apiKey) {
            return this.createInternalShipment(orderData, deliveryMethod);
        }

        const shipment = {
            service_code: this.mapShipEngineServiceCode(deliveryMethod),
            ship_to: {
                name: orderData.customer?.name || "Customer",
                address_line1: orderData.shipping_address?.street || "123 Main St",
                city_locality: orderData.shipping_address?.city || "New York",
                state_province: orderData.shipping_address?.state || "NY",
                postal_code: orderData.shipping_address?.postalCode || "10001",
                country_code: "US"
            },
            ship_from: {
                name: "Imarat Builders Mall",
                address_line1: "456 Business Ave",
                city_locality: "New York",
                state_province: "NY",
                postal_code: "10001",
                country_code: "US"
            },
            packages: [{
                weight: {
                    value: 1,
                    unit: "pound"
                },
                dimensions: {
                    unit: "inch",
                    length: 12,
                    width: 12,
                    height: 6
                }
            }]
        };

        try {
            const response = await fetch(`${this.shipengineConfig.baseUrl}/labels`, {
                method: 'POST',
                headers: {
                    'API-Key': this.shipengineConfig.apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(shipment)
            });

            if (!response.ok) {
                throw new Error(`ShipEngine create shipment error: ${response.status}`);
            }

            const data = await response.json();
            return {
                trackingNumber: data.tracking_number,
                carrier: data.carrier_code,
                service: data.service_code,
                estimatedDelivery: data.ship_date,
                labelUrl: data.label_download?.pdf
            };
        } catch (error) {
            console.error('ShipEngine create shipment error:', error);
            return this.createInternalShipment(orderData, deliveryMethod);
        }
    }

    async createShipStationShipment(orderData, deliveryMethod) {
        // Implementation for ShipStation shipment creation
        return this.createInternalShipment(orderData, deliveryMethod);
    }

    async createFedExShipment(orderData, deliveryMethod) {
        // Implementation for FedEx shipment creation
        return this.createInternalShipment(orderData, deliveryMethod);
    }

    async trackExternalShipment(trackingNumber, carrier) {
        // Implementation for external tracking
        return null;
    }
}

module.exports = new ShippingService();
